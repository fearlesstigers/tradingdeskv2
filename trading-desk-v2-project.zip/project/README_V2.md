# Trading Desk V2 — paper research release

This is the original Bolt React/Supabase project with a targeted trading-engine patch and a new research dashboard. **No claim of profitability is made.** Do not use this release for live trading or funded accounts.

## Modified files
- `supabase/functions/trading-engine/index.ts`: prior targeted patch adding stricter trade geometry checks, intentional-reversal handling, chronological completed-candle processing and paginated data retrieval. This is not an audited production execution engine.
- `src/components/ResearchConsole.tsx`: new performance and execution diagnostic panel.
- `src/App.tsx`: adds research panel and paper-mode branding.
- `src/index.css`: styling for new panel.

## Start locally
1. `npm install`
2. Copy `.env.example` to `.env` and set your own **public** Supabase URL and anon key. Do not put privileged keys in Vite environment variables.
3. `npm run typecheck && npm run build`
4. `npm run dev`

## Deployment
Existing Supabase migrations/config are preserved. The patched edge function must be deployed separately to your Supabase project using your normal trusted release workflow. Stop scheduling the paper engine while deploying and validate on a disposable paper dataset first. The frontend does not activate trading automatically.

## Remaining work before real-money use
- Authenticate and authorize privileged edge functions and all trading configuration writes. Check RLS policies.
- Reconcile fee/slippage/funding assumptions to real testnet fills.
- Add executable integration tests for chronological fills, gaps, duplicate runs and reversals. Confirm partial fills and price precision.
- Audit account-level maximum risk and emergency stop controls.
- Run long forward-paper tests and out-of-sample research. A high win rate alone does not prove positive expectancy.

## Verification status
Source files were assembled and the dashboard uses the existing PaperTrade type. A full npm install/build was attempted but the local npm cache lacked required packages; **the project is not claimed to have passed compilation or integration tests**. Run checks in a connected development environment before deployment.
