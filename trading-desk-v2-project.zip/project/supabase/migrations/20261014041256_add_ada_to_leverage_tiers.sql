-- Add ADAUSDT to leverage tiers (it's in the watchlist but missing from tiers)
UPDATE system_config 
SET leverage_tiers = jsonb_set(
  leverage_tiers, 
  '{ADAUSDT}', 
  '15'
)
WHERE id = 1;

-- Verify
SELECT leverage_tiers FROM system_config WHERE id = 1;
