/*
# Add MIRAGE — the mirror bot (10th agent)

1. Purpose
MIRAGE is a controlled experiment bot. It watches the same volatile coins as
REKT and APEX but takes the OPPOSITE side of every signal (a REKT long becomes
a MIRAGE short and vice versa), with identical entry/stop/target geometry and
holding rules. This lets us see live whether reversing the losing strategies
would have made money, without touching REKT or APEX at all.

2. Modified tables
- `agents`: new row `MIRAGE` (role: experiment mirror bot).
- `system_config`:
  - `mirage_balance numeric NOT NULL DEFAULT 100` — MIRAGE's own fund,
    separate from paper_balance (like apex_compound_balance).
  - `mirage_risk_pct numeric NOT NULL DEFAULT 15` — percent of mirage_balance
    MIRAGE may have at risk across open trades.

3. Security
- No new tables; RLS unchanged (service role writes, anon reads as before).

4. Notes
- MIRAGE's P&L updates mirage_balance only — never paper_balance or team P&L.
*/

INSERT INTO agents (id, role, description, enabled)
VALUES (
  'MIRAGE',
  'experiment',
  'Mirror bot — takes the exact opposite side of REKT and APEX signals on the same coins, same stops/targets/holds. Own $100 fund. Pure experiment: if MIRAGE outperforms REKT/APEX, the reversal hypothesis is confirmed live.',
  true
)
ON CONFLICT (id) DO NOTHING;

ALTER TABLE system_config
  ADD COLUMN IF NOT EXISTS mirage_balance numeric NOT NULL DEFAULT 100,
  ADD COLUMN IF NOT EXISTS mirage_risk_pct numeric NOT NULL DEFAULT 15;
