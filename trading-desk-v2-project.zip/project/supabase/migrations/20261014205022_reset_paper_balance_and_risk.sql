-- Reset paper balance to $10,000 (was -$196 from live losses)
UPDATE system_config SET paper_balance = 10000 WHERE id = 1;

-- Reduce risk per trade from 8% to 2% (sane for leveraged trading)
UPDATE system_config SET max_risk_per_trade_pct = 2.0 WHERE id = 1;