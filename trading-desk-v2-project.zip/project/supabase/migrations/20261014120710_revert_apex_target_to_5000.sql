-- Revert APEX target back to $5000
-- Expected trajectory at 100% daily: $50→$100→$200→$400→$800→$1600→$3200→$6400
-- Target hit around day 7, then preserve gains
UPDATE system_config
SET apex_target_balance = 5000
WHERE id = 1;