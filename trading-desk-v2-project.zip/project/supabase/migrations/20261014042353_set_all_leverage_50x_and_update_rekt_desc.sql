-- Set all leverage tiers to 50x
UPDATE system_config 
SET leverage_tiers = '{
  "BTCUSDT": 50,
  "ETHUSDT": 50,
  "SOLUSDT": 50,
  "XRPUSDT": 50,
  "ADAUSDT": 50,
  "DOGEUSDT": 50,
  "AVAXUSDT": 50,
  "LINKUSDT": 50,
  "PEPEUSDT": 50,
  "WIFUSDT": 50,
  "BNBUSDT": 50
}'::jsonb
WHERE id = 1;

-- Update REKT agent description
UPDATE agents SET 
  description = 'High-frequency momentum scalper. Trades 5-minute candles with tight 0.5-1% stops and quick 1.5:1 targets. Rides short-term momentum on any trending coin. Hundreds of trades per day, small wins compound fast.'
WHERE id = 'REKT';
