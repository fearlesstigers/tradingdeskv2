/*
# Create agent_genomes table for evolutionary parameter optimization

1. New Tables
- `agent_genomes` — stores evolving strategy parameters (the "genome") for each trading agent
  - `id` (uuid, primary key)
  - `agent_id` (text, e.g. "KIBO", "YUZU", "MATTY")
  - `generation` (int, starts at 1, increments each evolution cycle)
  - `genome` (jsonb, the tunable parameters for that agent)
  - `fitness_score` (numeric, total PnL from the backtest that evaluated this genome)
  - `total_pnl` (numeric, total PnL across all symbols)
  - `total_trades` (int)
  - `win_rate` (numeric)
  - `profit_factor` (numeric)
  - `is_champion` (boolean, true if this is the current best genome for the agent)
  - `parent_id` (uuid, nullable, points to the genome this was mutated from)
  - `mutation_notes` (text, describes what changed from parent)
  - `backtest_run_id` (text, nullable, groups genomes evaluated in the same backtest run)
  - `created_at` (timestamptz)

2. Security
- Enable RLS on `agent_genomes`.
- Allow anon + authenticated CRUD (single-tenant app, no sign-in).
*/

CREATE TABLE IF NOT EXISTS agent_genomes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  agent_id text NOT NULL,
  generation int NOT NULL DEFAULT 1,
  genome jsonb NOT NULL,
  fitness_score numeric DEFAULT 0,
  total_pnl numeric DEFAULT 0,
  total_trades int DEFAULT 0,
  win_rate numeric DEFAULT 0,
  profit_factor numeric DEFAULT 0,
  is_champion boolean DEFAULT false,
  parent_id uuid,
  mutation_notes text,
  backtest_run_id text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE agent_genomes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_genomes" ON agent_genomes;
CREATE POLICY "anon_select_genomes" ON agent_genomes FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_genomes" ON agent_genomes;
CREATE POLICY "anon_insert_genomes" ON agent_genomes FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_genomes" ON agent_genomes;
CREATE POLICY "anon_update_genomes" ON agent_genomes FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_genomes" ON agent_genomes;
CREATE POLICY "anon_delete_genomes" ON agent_genomes FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_genomes_agent_champion ON agent_genomes(agent_id, is_champion);
CREATE INDEX IF NOT EXISTS idx_genomes_created ON agent_genomes(created_at DESC);

-- Seed initial champion genomes with the current hardcoded parameters
INSERT INTO agent_genomes (agent_id, generation, genome, is_champion, mutation_notes)
VALUES
  ('KIBO', 1, jsonb_build_object(
    'trend_threshold', 0.002,
    'long_stop_sma50_mult', 0.995,
    'long_stop_low_mult', 0.99,
    'long_target_rr', 2.5,
    'short_rsi_max', 45,
    'short_stop_pct', 0.97,
    'short_target_rr', 2.0,
    'min_rr', 2.0,
    'max_hold_bars', 12,
    'min_gap', 3
  ), true, 'Initial baseline parameters'),
  ('YUZU', 1, jsonb_build_object(
    'trend_threshold', 0.002,
    'long_stop_low_mult', 0.995,
    'long_target_rr', 1.8,
    'short_rsi_max', 50,
    'short_stop_pct', 0.98,
    'short_target_rr', 1.5,
    'min_rr', 1.5,
    'max_hold_bars', 3,
    'min_gap', 2
  ), true, 'Initial baseline parameters'),
  ('MATTY', 1, jsonb_build_object(
    'ema_fast', 27,
    'ema_slow', 63,
    'trend_strength_max', 0.004,
    'bb_period', 20,
    'bb_std_dev', 2.0,
    'rsi_oversold', 35,
    'rsi_overbought', 65,
    'vol_ratio_min', 1.2,
    'stop_band_buffer', 0.1,
    'min_rr', 1.5,
    'max_hold_bars', 24,
    'min_gap', 3
  ), true, 'Initial baseline parameters')
ON CONFLICT DO NOTHING;
