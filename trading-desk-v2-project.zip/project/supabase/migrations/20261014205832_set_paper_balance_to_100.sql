-- Set paper balance to $100 (not $10,000)
UPDATE system_config SET paper_balance = 100 WHERE id = 1;

-- Adjust risk to 3% per trade = $3 risk on $100 account
UPDATE system_config SET max_risk_per_trade_pct = 3.0 WHERE id = 1;