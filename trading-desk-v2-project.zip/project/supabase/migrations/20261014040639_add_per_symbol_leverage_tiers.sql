-- Add per-symbol leverage tiers to system_config
ALTER TABLE system_config ADD COLUMN IF NOT EXISTS leverage_tiers jsonb DEFAULT '{"BTCUSDT": 50, "ETHUSDT": 50, "SOLUSDT": 50, "DOGEUSDT": 25, "AVAXUSDT": 25, "LINKUSDT": 25, "PEPEUSDT": 10, "WIFUSDT": 10, "BNBUSDT": 25, "XRPUSDT": 25}';

-- Update config with the tiers
UPDATE system_config SET leverage_tiers = '{"BTCUSDT": 50, "ETHUSDT": 50, "SOLUSDT": 50, "DOGEUSDT": 25, "AVAXUSDT": 25, "LINKUSDT": 25, "PEPEUSDT": 10, "WIFUSDT": 10, "BNBUSDT": 25, "XRPUSDT": 25}' WHERE id = 1;
