UPDATE system_config
SET leverage_tiers = '{
  "BTCUSDT": 100,
  "ETHUSDT": 100,
  "BNBUSDT": 100,
  "SOLUSDT": 100,
  "XRPUSDT": 25,
  "LINKUSDT": 25,
  "AVAXUSDT": 25,
  "DOGEUSDT": 25,
  "ADAUSDT": 25,
  "WIFUSDT": 10,
  "PEPEUSDT": 10
}'::jsonb
WHERE id = 1;