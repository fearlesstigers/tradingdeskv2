/*
# Create agent_symbol_stats table for per-symbol learning

1. New Tables
- `agent_symbol_stats`
  - `id` (uuid, primary key)
  - `agent_id` (text, which agent: KIBO, YUZU)
  - `symbol` (text, trading symbol)
  - `total_trades` (integer, total closed trades for this agent+symbol)
  - `wins` (integer, profitable trades)
  - `losses` (integer, losing trades)
  - `consecutive_losses` (integer, current losing streak)
  - `max_consecutive_losses` (integer, worst losing streak ever)
  - `win_rate` (numeric, percentage win rate)
  - `total_pnl` (numeric, cumulative P&L for this agent+symbol)
  - `bayesian_alpha` (numeric, Bayesian alpha for win probability)
  - `bayesian_beta` (numeric, Bayesian beta for win probability)
  - `should_trade` (boolean, whether this agent should trade this symbol)
  - `last_trade_at` (timestamptz, when last trade closed)
  - `cooldown_until` (timestamptz, if on cooldown, when it expires)
  - `updated_at` (timestamptz)
- Unique constraint on (agent_id, symbol)
2. Security
  - Enable RLS on agent_symbol_stats.
  - Allow anon + authenticated CRUD (single-tenant, no auth).
3. Notes
  - This table lets each agent learn which symbols it's profitable on
    and automatically stop trading symbols where it keeps losing.
  - After 5 consecutive losses on a symbol, the agent enters a 6-hour cooldown.
  - After 10+ trades with <35% win rate, the agent stops trading that symbol entirely.
*/

CREATE TABLE IF NOT EXISTS agent_symbol_stats (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  agent_id text NOT NULL,
  symbol text NOT NULL,
  total_trades integer NOT NULL DEFAULT 0,
  wins integer NOT NULL DEFAULT 0,
  losses integer NOT NULL DEFAULT 0,
  consecutive_losses integer NOT NULL DEFAULT 0,
  max_consecutive_losses integer NOT NULL DEFAULT 0,
  win_rate numeric NOT NULL DEFAULT 0,
  total_pnl numeric NOT NULL DEFAULT 0,
  bayesian_alpha numeric NOT NULL DEFAULT 2,
  bayesian_beta numeric NOT NULL DEFAULT 2,
  should_trade boolean NOT NULL DEFAULT true,
  last_trade_at timestamptz,
  cooldown_until timestamptz,
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(agent_id, symbol)
);

ALTER TABLE agent_symbol_stats ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_agent_symbol" ON agent_symbol_stats;
CREATE POLICY "anon_select_agent_symbol" ON agent_symbol_stats FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_agent_symbol" ON agent_symbol_stats;
CREATE POLICY "anon_insert_agent_symbol" ON agent_symbol_stats FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_agent_symbol" ON agent_symbol_stats;
CREATE POLICY "anon_update_agent_symbol" ON agent_symbol_stats FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_agent_symbol" ON agent_symbol_stats;
CREATE POLICY "anon_delete_agent_symbol" ON agent_symbol_stats FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_agent_symbol ON agent_symbol_stats(agent_id, symbol);
