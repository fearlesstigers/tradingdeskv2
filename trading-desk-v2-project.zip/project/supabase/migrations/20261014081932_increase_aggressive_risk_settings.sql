/*
# Increase risk settings for aggressive small-capital growth

1. Modified tables
- `system_config`: raise max_total_risk_pct to 40, max_risk_per_trade_pct to 8,
  max_positions_per_agent to 5, rekt_risk_pct to 15.

2. Notes
- With ~$49 paper balance, conservative settings produce tiny positions.
- Aggressive risk early helps grow the account; can dial back as balance grows.
- Worst-case single-cycle loss is now ~40% of balance (~$19.47).
- REKT gets 15% dedicated, KIBO/YUZU/MATTY share remaining 25%.
*/

UPDATE system_config
SET
  max_total_risk_pct = 40.0,
  max_risk_per_trade_pct = 8.0,
  max_positions_per_agent = 5,
  rekt_risk_pct = 15.0
WHERE id = 1;
