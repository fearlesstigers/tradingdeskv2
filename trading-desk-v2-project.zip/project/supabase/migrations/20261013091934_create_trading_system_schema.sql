/*
# Paper Trading System — 6-Agent Architecture

## Overview
Creates the complete schema for a paper-trading simulation system with 6 specialized agents
(MOMO, RIN, SORA, KIBO, YUZU, AKI) that analyze market data and log simulated trades.
This is PAPER MODE ONLY — no real trades are placed.

## Tables

### agents
Stores configuration and identity for each of the 6 agents.
- id: text PK (agent name: MOMO, RIN, SORA, KIBO, YUZU, AKI)
- role: text — what the agent does
- description: text — longer description
- enabled: boolean — whether agent is active
- created_at: timestamptz

### paper_trades
Every simulated trade or blocked setup attempt.
- id: uuid PK
- agent_id: text FK → agents(id) — which agent proposed the trade
- symbol: text — trading pair (e.g. BTCUSDT)
- status: text — OPEN, CLOSED, BLOCKED
- entry_price: numeric — simulated entry
- exit_price: numeric — simulated exit (null if open)
- stop_price: numeric — stop loss level
- target_price: numeric — profit target
- simulated_size: numeric — position size in USD
- max_dollar_risk: numeric — max risk in USD
- pnl: numeric — profit/loss when closed
- pnl_pct: numeric — percentage return
- momo_pass: boolean — launch quality check result
- rin_pass: boolean — whale activity check result (null if not applicable)
- sora_decision: text — APPROVE / BLOCK
- kibo_decision: text — APPROVE / SKIP (null if YUZU proposed)
- yuzu_decision: text — APPROVE / SKIP (null if KIBO proposed)
- block_reason: text — why it was blocked (if blocked)
- opened_at: timestamptz
- closed_at: timestamptz — when trade was closed/blocked
- close_reason: text — STOP_HIT, TARGET_HIT, TIMEOUT, BLOCKED
- market_data: jsonb — snapshot of market conditions at decision time
- notes: text

### agent_stats
Rolling statistics per agent, updated by AKI logger.
- agent_id: text PK FK → agents(id)
- total_trades: int
- wins: int
- losses: int
- blocked: int
- win_rate: numeric
- avg_win: numeric
- avg_loss: numeric
- biggest_win: numeric
- biggest_loss: numeric
- total_pnl: numeric
- max_drawdown: numeric
- current_drawdown: numeric
- updated_at: timestamptz

### system_config
Global configuration: paper account balance, risk limits, trading pairs, intervals.
- id: int PK (always 1 — singleton)
- paper_balance: numeric — starting/running paper balance
- max_risk_per_trade_pct: numeric — 0.5
- max_total_risk_pct: numeric — 2.0
- trade_interval_minutes: int — how often to run the pipeline
- watchlist: text[] — list of symbols to monitor
- total_team_pnl: numeric
- total_trades: int
- total_blocked: int
- is_running: boolean — master switch
- updated_at: timestamptz

### run_log
Every execution cycle of the trading engine.
- id: uuid PK
- started_at: timestamptz
- completed_at: timestamptz
- status: text — SUCCESS, ERROR, RUNNING
- cycles_completed: int
- trades_opened: int
- trades_closed: int
- trades_blocked: int
- error_message: text
- summary: jsonb — structured summary of what happened

## Security
- Single-tenant app (no sign-in). All policies TO anon, authenticated.
- RLS enabled on all tables.
- Full CRUD for anon + authenticated on all tables (data is intentionally shared/public).
*/