-- Add apex_decision column to paper_trades
ALTER TABLE paper_trades ADD COLUMN IF NOT EXISTS apex_decision text;

-- Add APEX agent
INSERT INTO agents (id, role, description, enabled)
VALUES (
  'APEX',
  'Autonomous Alpha Hunter',
  'Mission: turn $50 into $5K by month-end. Scans spot + perp markets autonomously, fuses momentum/trend/RSI signals, and ramps risk as the deadline approaches. No gates, no committee — just pure alpha-seeking.',
  true
)
ON CONFLICT (id) DO NOTHING;

-- Dedicated risk budget for APEX (separate from KIBO/YUZU/REKT/MATTY)
ALTER TABLE system_config ADD COLUMN IF NOT EXISTS apex_risk_pct numeric DEFAULT 8.0;
UPDATE system_config SET apex_risk_pct = 8.0 WHERE id = 1;

-- APEX daily target tracking: stores the mission start date and starting balance
-- so each cycle can compute how much time is left and how aggressive to be
ALTER TABLE system_config ADD COLUMN IF NOT EXISTS apex_start_date date;
ALTER TABLE system_config ADD COLUMN IF NOT EXISTS apex_start_balance numeric DEFAULT 50.0;
ALTER TABLE system_config ADD COLUMN IF NOT EXISTS apex_target_balance numeric DEFAULT 5000.0;
ALTER TABLE system_config ADD COLUMN IF NOT EXISTS apex_end_date date;

-- Initialize: mission starts today, ends end of month
UPDATE system_config
SET apex_start_date = CURRENT_DATE,
    apex_start_balance = 50.0,
    apex_target_balance = 5000.0,
    apex_end_date = DATE_TRUNC('month', CURRENT_DATE + INTERVAL '1 month') - INTERVAL '1 day'
WHERE id = 1;
