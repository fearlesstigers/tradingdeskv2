-- APEX strategy registry: tracks performance of each strategy APEX can deploy
-- APEX cycles through strategies, learns which ones produce wins, and weights
-- future capital allocation toward winning strategies (adaptive selection).
CREATE TABLE IF NOT EXISTS apex_strategy_stats (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  strategy text NOT NULL,
  total_trades int DEFAULT 0,
  wins int DEFAULT 0,
  losses int DEFAULT 0,
  total_pnl numeric DEFAULT 0,
  avg_win numeric DEFAULT 0,
  avg_loss numeric DEFAULT 0,
  win_rate numeric DEFAULT 0,
  bayesian_alpha numeric DEFAULT 2,
  bayesian_beta numeric DEFAULT 2,
  weight numeric DEFAULT 1.0,         -- adaptive weight: higher = more capital allocated
  enabled boolean DEFAULT true,
  last_used_at timestamptz,
  cooldown_until timestamptz,
  updated_at timestamptz DEFAULT now(),
  UNIQUE(strategy)
);

ALTER TABLE apex_strategy_stats ENABLE ROW LEVEL SECURITY;
CREATE POLICY "select_apex_strategies" ON apex_strategy_stats FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "insert_apex_strategies" ON apex_strategy_stats FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "update_apex_strategies" ON apex_strategy_stats FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_apex_strategies" ON apex_strategy_stats FOR DELETE TO anon, authenticated USING (true);

-- Seed the initial strategy registry with all strategies APEX can deploy
INSERT INTO apex_strategy_stats (strategy, weight, enabled) VALUES
  ('MACD_CROSSOVER', 1.0, true),
  ('BOLLINGER_REVERSION', 1.0, true),
  ('EMA_CROSSOVER', 1.0, true),
  ('STOCHASTIC reversal', 1.0, true),
  ('ADX_TREND_RIDER', 1.0, true),
  ('RSI_DIVergence', 1.0, true),
  ('MOMENTUM_BREAKOUT', 1.0, true),
  ('VWAP_REVERSION', 1.0, true)
ON CONFLICT (strategy) DO NOTHING;

-- Update APEX description to reflect its new autonomous nature
UPDATE agents
SET description = 'Mission: turn $50 into $5K by month-end. Cycles through 8+ technical strategies (MACD, Bollinger, EMA cross, Stochastic, ADX, RSI divergence, momentum breakout, VWAP). Learns which strategies win and allocates more capital to them. All profits reinvested. No gates, no committee — pure autonomous alpha-seeking.'
WHERE id = 'APEX';

-- Enable compounding for APEX: its profits get added back to its trading balance
ALTER TABLE system_config ADD COLUMN IF NOT EXISTS apex_compound_balance numeric DEFAULT 50.0;
UPDATE system_config SET apex_compound_balance = 50.0 WHERE id = 1;
