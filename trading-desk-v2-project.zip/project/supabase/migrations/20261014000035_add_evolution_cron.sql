
-- Add automatic evolution cron job — runs every 6 hours
-- Calls the backtest edge function with mode: "evolve"

SELECT cron.schedule(
  'evolution-schedule',
  '0 */6 * * *',
  $$
  SELECT net.http_post(
    url := '${SUPABASE_URL}/functions/v1/backtest',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', 'Bearer ${SUPABASE_SERVICE_ROLE_KEY}'
    ),
    body := jsonb_build_object('mode', 'evolve')
  );
  $$
);
