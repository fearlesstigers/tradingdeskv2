-- Add leverage and aggressive settings to system_config
ALTER TABLE system_config ADD COLUMN IF NOT EXISTS leverage integer DEFAULT 10;
ALTER TABLE system_config ADD COLUMN IF NOT EXISTS compounding_mode boolean DEFAULT true;

-- Set paper balance to $50 and increase risk to 5% for aggressive compounding
UPDATE system_config
SET paper_balance = 50,
    max_risk_per_trade_pct = 5.0,
    max_total_risk_pct = 25.0,
    leverage = 10,
    compounding_mode = true
WHERE id = 1;

-- Add liquidation price column to paper_trades
ALTER TABLE paper_trades ADD COLUMN IF NOT EXISTS liquidation_price numeric;
