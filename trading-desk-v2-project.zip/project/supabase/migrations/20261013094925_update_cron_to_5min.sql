/*
# Update cron schedule from 15 minutes to 5 minutes

Changes the trading engine cron job to fire every 5 minutes instead of every 15 minutes.
This gives the agents faster reaction time for scalping-style strategies and tighter
stop-loss monitoring.
*/

SELECT cron.unschedule('trading-engine-schedule');

SELECT cron.schedule(
  'trading-engine-schedule',
  '*/5 * * * *',
  $$SELECT net.http_post(
    url := '{{SUPABASE_URL}}/functions/v1/scheduler',
    headers := '{"Content-Type": "application/json", "Authorization": "Bearer {{SUPABASE_SERVICE_ROLE_KEY}}"}'::jsonb,
    body := '{"triggered": "cron"}'::jsonb
  )$$
);