
-- Fix the broken cron schedule that used {{SUPABASE_URL}} template variables
-- which Supabase does NOT substitute in pg_cron commands.
-- Restores a working 2-minute schedule calling the scheduler edge function
-- with the real project URL and anon key (verify_jwt=false on both functions).

SELECT cron.schedule(
  'trading-engine-schedule',
  '*/2 * * * *',
  $$SELECT net.http_post(
    url := 'https://cdopkcjcuvmwoxmwisjo.supabase.co/functions/v1/scheduler',
    headers := '{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNkb3BrY2pjdXZtd294bXdpc2pvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTE4NzgzMzgsImV4cCI6MjEwNzQ1NDMzOH0.gvQCkmtR3aq0gDLrA5U6RMPV0TL6XFweaaxofDXVGIs"}'::jsonb,
    body := '{"triggered": "cron"}'::jsonb
  )$$
);
