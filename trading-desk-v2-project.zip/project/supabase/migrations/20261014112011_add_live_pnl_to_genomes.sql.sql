-- Add live_pnl and composite_score columns to agent_genomes
ALTER TABLE agent_genomes ADD COLUMN IF NOT EXISTS live_pnl numeric DEFAULT 0;
ALTER TABLE agent_genomes ADD COLUMN IF NOT EXISTS composite_score numeric DEFAULT 0;
