/* # Create tables for paper trading system */

CREATE TABLE IF NOT EXISTS agents (
  id text PRIMARY KEY,
  role text NOT NULL,
  description text NOT NULL DEFAULT '',
  enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE agents ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_agents" ON agents;
CREATE POLICY "anon_select_agents" ON agents FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_agents" ON agents;
CREATE POLICY "anon_insert_agents" ON agents FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_agents" ON agents;
CREATE POLICY "anon_update_agents" ON agents FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_agents" ON agents;
CREATE POLICY "anon_delete_agents" ON agents FOR DELETE TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS paper_trades (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  agent_id text REFERENCES agents(id) ON DELETE CASCADE,
  symbol text NOT NULL,
  status text NOT NULL DEFAULT 'BLOCKED',
  entry_price numeric,
  exit_price numeric,
  stop_price numeric,
  target_price numeric,
  simulated_size numeric,
  max_dollar_risk numeric,
  pnl numeric DEFAULT 0,
  pnl_pct numeric DEFAULT 0,
  momo_pass boolean DEFAULT false,
  rin_pass boolean,
  sora_decision text,
  kibo_decision text,
  yuzu_decision text,
  block_reason text,
  opened_at timestamptz DEFAULT now(),
  closed_at timestamptz,
  close_reason text,
  market_data jsonb DEFAULT '{}'::jsonb,
  notes text
);

ALTER TABLE paper_trades ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_trades" ON paper_trades;
CREATE POLICY "anon_select_trades" ON paper_trades FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_trades" ON paper_trades;
CREATE POLICY "anon_insert_trades" ON paper_trades FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_trades" ON paper_trades;
CREATE POLICY "anon_update_trades" ON paper_trades FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_trades" ON paper_trades;
CREATE POLICY "anon_delete_trades" ON paper_trades FOR DELETE TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_paper_trades_status ON paper_trades(status);
CREATE INDEX IF NOT EXISTS idx_paper_trades_agent ON paper_trades(agent_id);
CREATE INDEX IF NOT EXISTS idx_paper_trades_opened ON paper_trades(opened_at DESC);

CREATE TABLE IF NOT EXISTS agent_stats (
  agent_id text PRIMARY KEY REFERENCES agents(id) ON DELETE CASCADE,
  total_trades int NOT NULL DEFAULT 0,
  wins int NOT NULL DEFAULT 0,
  losses int NOT NULL DEFAULT 0,
  blocked int NOT NULL DEFAULT 0,
  win_rate numeric NOT NULL DEFAULT 0,
  avg_win numeric NOT NULL DEFAULT 0,
  avg_loss numeric NOT NULL DEFAULT 0,
  biggest_win numeric NOT NULL DEFAULT 0,
  biggest_loss numeric NOT NULL DEFAULT 0,
  total_pnl numeric NOT NULL DEFAULT 0,
  max_drawdown numeric NOT NULL DEFAULT 0,
  current_drawdown numeric NOT NULL DEFAULT 0,
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE agent_stats ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_agent_stats" ON agent_stats;
CREATE POLICY "anon_select_agent_stats" ON agent_stats FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_agent_stats" ON agent_stats;
CREATE POLICY "anon_insert_agent_stats" ON agent_stats FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_agent_stats" ON agent_stats;
CREATE POLICY "anon_update_agent_stats" ON agent_stats FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_agent_stats" ON agent_stats;
CREATE POLICY "anon_delete_agent_stats" ON agent_stats FOR DELETE TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS system_config (
  id int PRIMARY KEY DEFAULT 1,
  paper_balance numeric NOT NULL DEFAULT 10000,
  max_risk_per_trade_pct numeric NOT NULL DEFAULT 0.5,
  max_total_risk_pct numeric NOT NULL DEFAULT 2.0,
  trade_interval_minutes int NOT NULL DEFAULT 15,
  watchlist text[] NOT NULL DEFAULT ARRAY['BTCUSDT','ETHUSDT','SOLUSDT','BNBUSDT','XRPUSDT','DOGEUSDT','ADAUSDT','AVAXUSDT'],
  total_team_pnl numeric NOT NULL DEFAULT 0,
  total_trades int NOT NULL DEFAULT 0,
  total_blocked int NOT NULL DEFAULT 0,
  is_running boolean NOT NULL DEFAULT true,
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT single_row CHECK (id = 1)
);

ALTER TABLE system_config ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_config" ON system_config;
CREATE POLICY "anon_select_config" ON system_config FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_config" ON system_config;
CREATE POLICY "anon_insert_config" ON system_config FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_config" ON system_config;
CREATE POLICY "anon_update_config" ON system_config FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_config" ON system_config;
CREATE POLICY "anon_delete_config" ON system_config FOR DELETE TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS run_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  started_at timestamptz DEFAULT now(),
  completed_at timestamptz,
  status text NOT NULL DEFAULT 'RUNNING',
  cycles_completed int NOT NULL DEFAULT 0,
  trades_opened int NOT NULL DEFAULT 0,
  trades_closed int NOT NULL DEFAULT 0,
  trades_blocked int NOT NULL DEFAULT 0,
  error_message text,
  summary jsonb DEFAULT '{}'::jsonb
);

ALTER TABLE run_log ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_run_log" ON run_log;
CREATE POLICY "anon_select_run_log" ON run_log FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_run_log" ON run_log;
CREATE POLICY "anon_insert_run_log" ON run_log FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_run_log" ON run_log;
CREATE POLICY "anon_update_run_log" ON run_log FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_run_log" ON run_log;
CREATE POLICY "anon_delete_run_log" ON run_log FOR DELETE TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_run_log_started ON run_log(started_at DESC);