/*
# Update cron schedule from 5 minutes to 2 minutes

Faster cycle for tighter stop-loss monitoring on scalping-style trades.
Uses ~43,200 invocations/month (8.6% of free tier 500K limit).
*/

SELECT cron.unschedule('trading-engine-schedule');

SELECT cron.schedule(
  'trading-engine-schedule',
  '*/2 * * * *',
  $$SELECT net.http_post(
    url := '{{SUPABASE_URL}}/functions/v1/scheduler',
    headers := '{"Content-Type": "application/json", "Authorization": "Bearer {{SUPABASE_SERVICE_ROLE_KEY}}"}'::jsonb,
    body := '{"triggered": "cron"}'::jsonb
  )$$
);