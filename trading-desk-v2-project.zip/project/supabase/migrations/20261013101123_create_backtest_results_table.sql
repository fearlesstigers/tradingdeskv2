/*
# Create backtest_results table for strategy backtesting

1. New Tables
- `backtest_results`
  - `id` (uuid, primary key)
  - `agent_id` (text, which agent was backtested: RIN, KIBO, YUZU, or ALL)
  - `symbol` (text, trading symbol or 'ALL' for multi-symbol)
  - `period_days` (integer, how many days of history were backtested)
  - `total_trades` (integer, number of simulated trades)
  - `wins` (integer, profitable trades)
  - `losses` (integer, losing trades)
  - `blocked` (integer, blocked setups)
  - `win_rate` (numeric, percentage win rate)
  - `total_pnl` (numeric, total profit/loss in dollars)
  - `avg_win` (numeric, average profit per winning trade)
  - `avg_loss` (numeric, average loss per losing trade)
  - `biggest_win` (numeric, largest single win)
  - `biggest_loss` (numeric, largest single loss)
  - `max_drawdown` (numeric, peak-to-trough drawdown)
  - `profit_factor` (numeric, gross profit / gross loss)
  - `sharpe_ratio` (numeric, risk-adjusted return)
  - `trades_json` (jsonb, array of individual trade details for display)
  - `created_at` (timestamptz, when backtest was run)
2. Security
  - Enable RLS on backtest_results.
  - Allow anon + authenticated CRUD (single-tenant, no auth).
3. Notes
  - This stores results of historical strategy backtesting.
  - Each row is one backtest run (e.g. RIN on BTCUSDT over 30 days).
  - trades_json stores up to 100 individual simulated trades for the UI to display.
*/

CREATE TABLE IF NOT EXISTS backtest_results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  agent_id text NOT NULL,
  symbol text NOT NULL,
  period_days integer NOT NULL,
  total_trades integer NOT NULL DEFAULT 0,
  wins integer NOT NULL DEFAULT 0,
  losses integer NOT NULL DEFAULT 0,
  blocked integer NOT NULL DEFAULT 0,
  win_rate numeric NOT NULL DEFAULT 0,
  total_pnl numeric NOT NULL DEFAULT 0,
  avg_win numeric NOT NULL DEFAULT 0,
  avg_loss numeric NOT NULL DEFAULT 0,
  biggest_win numeric NOT NULL DEFAULT 0,
  biggest_loss numeric NOT NULL DEFAULT 0,
  max_drawdown numeric NOT NULL DEFAULT 0,
  profit_factor numeric NOT NULL DEFAULT 0,
  sharpe_ratio numeric NOT NULL DEFAULT 0,
  trades_json jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE backtest_results ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_backtest" ON backtest_results;
CREATE POLICY "anon_select_backtest" ON backtest_results FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_backtest" ON backtest_results;
CREATE POLICY "anon_insert_backtest" ON backtest_results FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_backtest" ON backtest_results;
CREATE POLICY "anon_delete_backtest" ON backtest_results FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_backtest_created ON backtest_results(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_backtest_agent ON backtest_results(agent_id);
