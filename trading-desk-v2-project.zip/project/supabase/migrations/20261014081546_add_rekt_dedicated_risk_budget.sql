/*
# Add dedicated REKT risk budget

1. Modified tables
- `system_config`: add `rekt_risk_pct` column (numeric, default 10.0)
  This reserves a portion of the total risk budget specifically for REKT,
  so KIBO and YUZU can't consume it all before REKT gets a chance to trade.

2. Notes
- The existing `max_total_risk_pct` (25%) is the overall cap.
- `rekt_risk_pct` (10%) is carved out from that total — REKT can use up to
  this amount regardless of how much KIBO/YUZU are using.
- KIBO and YUZU share the remaining 15% of the team risk budget.
*/

ALTER TABLE system_config
  ADD COLUMN IF NOT EXISTS rekt_risk_pct numeric DEFAULT 10.0;

UPDATE system_config SET rekt_risk_pct = 10.0 WHERE id = 1;
