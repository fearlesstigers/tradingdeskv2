-- Insert default APEX champion genome
INSERT INTO agent_genomes (agent_id, generation, genome, fitness_score, total_pnl, is_champion, mutation_notes, composite_score, live_pnl)
VALUES (
  'APEX',
  1,
  '{"min_momentum":0.15,"min_rsi_long":40,"max_rsi_long":72,"min_rsi_short":28,"max_rsi_short":60,"trend_threshold":0.0008,"min_stop_pct":0.4,"max_stop_pct":1.2,"target_rr":2.0,"min_rr":1.5,"max_hold_bars":8,"min_gap":2}'::jsonb,
  0,
  0,
  true,
  'Initial baseline parameters',
  0,
  0
);