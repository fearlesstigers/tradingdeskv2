
UPDATE agents
SET role = 'Reversal Bot',
    description = 'Mean-reversion trader. Fades Bollinger Band extremes with RSI confirmation in range-bound markets. Targets the mid-band snap-back.'
WHERE id = 'MATTY';
