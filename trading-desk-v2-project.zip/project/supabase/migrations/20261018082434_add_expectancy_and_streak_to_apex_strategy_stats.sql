/*
# Add expectancy scoring and loss-streak tracking to APEX strategy scorecards

1. Modified Tables
- `apex_strategy_stats`
  - `expectancy` (numeric): expectancy per trade = (win rate x average win) - (loss rate x average loss). Positive = strategy makes money per trade over time. Computed automatically on every closed trade.
  - `consecutive_losses` (int): running loss streak per strategy, used to trigger cooldowns after 3 losses and disable after 5.
2. Security
- No changes; existing RLS policies remain in effect.
3. Notes
- Both columns are nullable with defaults so existing rows keep working.
- New strategies APEX invents automatically get a scorecard (created on first closed trade) and therefore inherit expectancy scoring with no extra setup.
*/

ALTER TABLE apex_strategy_stats ADD COLUMN IF NOT EXISTS expectancy numeric DEFAULT 0;
ALTER TABLE apex_strategy_stats ADD COLUMN IF NOT EXISTS consecutive_losses int DEFAULT 0;