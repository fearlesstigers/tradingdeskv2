/*
# Clean reset: archive old trades, restore balance, dial back risk

1. Purpose
   Wipe the slate clean after the broken-leverage era while preserving
   everything the bots have learned:

2. What this does
   - Creates `paper_trades_archive` (same shape as paper_trades) and moves
     all closed/blocked trades there. Keeps the scoreboard history without
     polluting the live tables.
   - Keeps the 16 OPEN trades in place so they can settle naturally.
   - Restores paper_balance to 100.00 and resets total_team_pnl so the
     team starts fresh from $100.
   - Resets total_trades/total_blocked counters in system_config.
   - Dials MATTY risk from 15% -> 5%, APEX risk from 20% -> 8% (they caused
     most of the -$55 loss). REKT keeps its dedicated 15% budget (net
     positive, self-funded from its own sub-budget).
   - Resets apex_compound_balance to apex_start_balance (50) so APEX's
     compounding tracker matches the fresh start.

3. What is deliberately NOT touched
   - agent_genomes (230 rows) - the evolved strategy parameters the engine
     loads before every trade. Learning preserved.
   - agent_symbol_stats / agent_stats - per-symbol Bayesian memory of which
     coins treated each bot well. Learning preserved.
   - apex_strategy_stats - APEX strategy weights/expectancy. Learning
     preserved.
   - backtest_results - research history preserved.

4. Security
   - paper_trades_archive: RLS enabled, anon+authenticated read-only policy
     mirroring the existing paper_trades pattern (single-tenant, no-auth app).
   - No changes to existing policies.

5. Notes
   - Archive table has no FK constraints (agents may be modified later
     without blocking archives).
   - Idempotent: re-running moves any newly closed rows to the archive.
*/

CREATE TABLE IF NOT EXISTS paper_trades_archive (LIKE paper_trades INCLUDING ALL);

ALTER TABLE paper_trades_archive ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "archive_read" ON paper_trades_archive;
CREATE POLICY "archive_read" ON paper_trades_archive FOR SELECT
TO anon, authenticated USING (true);

INSERT INTO paper_trades_archive SELECT * FROM paper_trades WHERE status IN ('CLOSED','BLOCKED');
DELETE FROM paper_trades WHERE status IN ('CLOSED','BLOCKED');

UPDATE system_config SET
  paper_balance = 100.00,
  total_team_pnl = 0,
  total_trades = 0,
  total_blocked = 0,
  matty_risk_pct = 5.0,
  apex_risk_pct = 8.0,
  apex_compound_balance = apex_start_balance,
  updated_at = now()
WHERE id = 1;
