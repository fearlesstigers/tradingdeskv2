-- Add rekt_decision column to paper_trades
ALTER TABLE paper_trades ADD COLUMN IF NOT EXISTS rekt_decision text;

-- Add REKT agent
INSERT INTO agents (id, role, description, enabled)
VALUES ('REKT', 'Volatile Coin Chaser', 'Hunts high-volatility pump coins that other agents reject. Surfs momentum bursts with wide stops and aggressive 3:1 targets. Bypasses MOMO/RIN/SORA gates — it wants the chaos.', true)
ON CONFLICT (id) DO NOTHING;

-- Add volatile coins to the watchlist
UPDATE system_config
SET watchlist = ARRAY['BTCUSDT','ETHUSDT','SOLUSDT','XRPUSDT','ADAUSDT','DOGEUSDT','AVAXUSDT','LINKUSDT','PEPEUSDT','WIFUSDT']
WHERE id = 1;
