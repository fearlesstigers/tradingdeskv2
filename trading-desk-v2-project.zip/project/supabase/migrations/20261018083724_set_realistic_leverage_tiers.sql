UPDATE system_config
SET leverage_tiers = '{
  "BTCUSDT": 50,
  "ETHUSDT": 50,
  "BNBUSDT": 50,
  "SOLUSDT": 25,
  "XRPUSDT": 25,
  "LINKUSDT": 25,
  "AVAXUSDT": 25,
  "DOGEUSDT": 25,
  "ADAUSDT": 25,
  "WIFUSDT": 10,
  "PEPEUSDT": 10
}'::jsonb
WHERE id = 1;