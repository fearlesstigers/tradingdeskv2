-- Add MATTY agent
INSERT INTO agents (id, role, description, enabled) VALUES
  ('MATTY', 'Reversal Bot', 'BB + EMA 9/14/20 + RSI divergence reversal trader. Enters at order blocks, targets escalating timeframe mid-Bollinger Bands (1m → 5m → 15m).', true)
ON CONFLICT (id) DO NOTHING;

-- Add agent_stats row for MATTY
INSERT INTO agent_stats (agent_id, total_trades, wins, losses, blocked, win_rate, avg_win, avg_loss, biggest_win, biggest_loss, total_pnl, max_drawdown, current_drawdown, bayesian_alpha, bayesian_beta, edge_confidence, should_trade)
SELECT 'MATTY', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 0, true
WHERE NOT EXISTS (SELECT 1 FROM agent_stats WHERE agent_id = 'MATTY');

-- Add matty_decision column to paper_trades
ALTER TABLE paper_trades ADD COLUMN IF NOT EXISTS matty_decision text;