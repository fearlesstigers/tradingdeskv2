/* # Seed agents and initial config */

INSERT INTO agents (id, role, description, enabled) VALUES
  ('MOMO', 'Launch Quality Filter', 'Checks liquidity depth, holder concentration, volume, token age, and liquidity removal risk. Returns QUALITY assessment and PASS/NO.', true),
  ('RIN', 'Whale Activity Tracker', 'Monitors unusually large wallet entries relative to normal activity. Reports clustered activity and wallet behavior patterns.', true),
  ('SORA', 'Anti-FOMO Risk Gate', 'Blocks setups with extreme short-term moves, thin liquidity, dangerous holder concentration, unclear stops, or hype-driven entries. Defaults to BLOCK when uncertain.', true),
  ('KIBO', 'Big-Setup Agent', 'Identifies asymmetric setups where upside is meaningfully larger than predefined risk. Max 0.5% paper-account risk per trade.', true),
  ('YUZU', 'Small-Win Agent', 'Looks for modest, repeatable setups with clear exits and small predefined targets. Prioritizes clean invalidation levels. Max 0.5% risk per trade.', true),
  ('AKI', 'Logger + Leaderboard', 'Records every simulated trade and blocked setup. Tracks per-agent stats: trades, wins, losses, win rate, avg win/loss, P&L, drawdown.', true)
ON CONFLICT (id) DO NOTHING;

INSERT INTO agent_stats (agent_id, total_trades, wins, losses, blocked, win_rate, avg_win, avg_loss, biggest_win, biggest_loss, total_pnl, max_drawdown, current_drawdown)
SELECT id, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
FROM agents
WHERE NOT EXISTS (SELECT 1 FROM agent_stats WHERE agent_stats.agent_id = agents.id);

INSERT INTO system_config (id, paper_balance, max_risk_per_trade_pct, max_total_risk_pct, trade_interval_minutes, is_running)
VALUES (1, 10000, 0.5, 2.0, 15, true)
ON CONFLICT (id) DO NOTHING;