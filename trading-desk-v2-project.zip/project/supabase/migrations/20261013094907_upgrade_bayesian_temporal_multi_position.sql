/*
# Upgrade: Bayesian Updating, Temporal Bias Cache, Multi-Position Support

## What this does
1. Adds Bayesian confidence columns to agent_stats so agents can learn from their win/loss history
2. Creates a temporal_bias_cache table to store per-hour trending scores for each symbol
3. Adds max_positions_per_agent to system_config (default 3, up from 1)
4. Changes trade_interval_minutes from 15 to 5

## New Tables
- temporal_bias_cache: stores hourly trend scores per symbol (updated periodically by the engine)
  - symbol: the trading pair (e.g. BTCUSDT)
  - hour: 0-23 UTC hour
  - avg_move: average % move during that hour
  - trending_score: -1.0 to 1.0 (negative = choppy, positive = trending)
  - sample_size: number of data points used
  - updated_at: when the cache was last refreshed

## Modified Tables
- agent_stats: adds 4 new columns
  - bayesian_alpha: Beta distribution alpha parameter (starts at 2 = slight optimism)
  - bayesian_beta: Beta distribution beta parameter (starts at 2)
  - edge_confidence: 0-100, how confident the agent is in its edge
  - should_trade: boolean, whether the agent should keep trading (false after sustained losses)
- system_config: adds max_positions_per_agent column (default 3), updates interval to 5 min

## Security
- temporal_bias_cache uses same anon/authenticated RLS pattern as other tables (no-auth app)
- No changes to existing RLS policies

## Notes
- The Bayesian prior (alpha=2, beta=2) gives a starting win probability estimate of 50%
  with low confidence. After ~10 trades the posterior starts to dominate the prior.
  After 20+ trades the agent's own track record controls its confidence.
- should_trade flips to false when the agent's win probability drops below 35% with
  reasonable confidence (20+ trades). This is a circuit breaker, not a permanent ban.
*/

-- Add Bayesian columns to agent_stats
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'agent_stats' AND column_name = 'bayesian_alpha') THEN
    ALTER TABLE agent_stats ADD COLUMN bayesian_alpha numeric NOT NULL DEFAULT 2;
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'agent_stats' AND column_name = 'bayesian_beta') THEN
    ALTER TABLE agent_stats ADD COLUMN bayesian_beta numeric NOT NULL DEFAULT 2;
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'agent_stats' AND column_name = 'edge_confidence') THEN
    ALTER TABLE agent_stats ADD COLUMN edge_confidence numeric NOT NULL DEFAULT 0;
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'agent_stats' AND column_name = 'should_trade') THEN
    ALTER TABLE agent_stats ADD COLUMN should_trade boolean NOT NULL DEFAULT true;
  END IF;
END $$;

-- Add max_positions_per_agent to system_config
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'system_config' AND column_name = 'max_positions_per_agent') THEN
    ALTER TABLE system_config ADD COLUMN max_positions_per_agent int NOT NULL DEFAULT 3;
  END IF;
END $$;

-- Update interval from 15 to 5 minutes
UPDATE system_config SET trade_interval_minutes = 5 WHERE id = 1 AND trade_interval_minutes = 15;

-- Create temporal bias cache table
CREATE TABLE IF NOT EXISTS temporal_bias_cache (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  symbol text NOT NULL,
  hour int NOT NULL CHECK (hour >= 0 AND hour <= 23),
  avg_move numeric NOT NULL DEFAULT 0,
  trending_score numeric NOT NULL DEFAULT 0,
  sample_size int NOT NULL DEFAULT 0,
  updated_at timestamptz DEFAULT now(),
  UNIQUE(symbol, hour)
);

ALTER TABLE temporal_bias_cache ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_temporal_bias" ON temporal_bias_cache;
CREATE POLICY "anon_select_temporal_bias" ON temporal_bias_cache FOR SELECT
TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_temporal_bias" ON temporal_bias_cache;
CREATE POLICY "anon_insert_temporal_bias" ON temporal_bias_cache FOR INSERT
TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_temporal_bias" ON temporal_bias_cache;
CREATE POLICY "anon_update_temporal_bias" ON temporal_bias_cache FOR UPDATE
TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_temporal_bias" ON temporal_bias_cache;
CREATE POLICY "anon_delete_temporal_bias" ON temporal_bias_cache FOR DELETE
TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_temporal_bias_symbol_hour ON temporal_bias_cache(symbol, hour);