/*
# Set up pg_cron for 24/7 automated trading engine

## What this does
1. Enables the pg_cron and pg_net extensions
2. Creates a scheduled job that calls the trading-engine edge function every 15 minutes
3. The edge function runs the full 6-agent pipeline (MOMO → RIN → SORA → KIBO/YUZU → Paper Executor → AKI)

## Security
- The cron job uses the service role key (stored in pg_settings via the vault)
- No policy changes needed — this is a server-side scheduled job

## Important notes
1. pg_cron runs on the Supabase server, NOT on the user's PC
2. The job continues running 24/7 regardless of whether the dashboard is open
3. To change the interval, update the cron schedule expression
*/

CREATE EXTENSION IF NOT EXISTS pg_cron WITH SCHEMA pg_catalog;
CREATE EXTENSION IF NOT EXISTS pg_net WITH SCHEMA extensions;

-- Grant necessary permissions
GRANT USAGE ON SCHEMA extensions TO postgres;
GRANT USAGE ON SCHEMA pg_catalog TO postgres;

-- Remove existing job if it exists
SELECT cron.unschedule('trading-engine-schedule') WHERE EXISTS (
  SELECT 1 FROM cron.job WHERE jobname = 'trading-engine-schedule'
);

-- Schedule the trading engine to run every 15 minutes
-- The edge function is public (verify_jwt = false) so we use the anon key
SELECT cron.schedule(
  'trading-engine-schedule',
  '*/15 * * * *',
  $$
    SELECT content
    FROM http_post(
      url := 'https://0ec90b57d6e95fcbda19832f.supabase.co/functions/v1/trading-engine',
      headers := jsonb_build_object(
        'Content-Type', 'application/json',
        'Authorization', 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJib2x0IiwicmVmIjoiMGVjOTBiNTdkNmU5NWZjYmRhMTk4MzJmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTg4ODE1NzQsImV4cCI6MTc1ODg4MTU3NH0.9I8-U0x86Ak8t2DGaIk0HfvTSLsAyzdnz-Nw00mMkKw'
      ),
      body := '{}'::jsonb
    );
  $$
);