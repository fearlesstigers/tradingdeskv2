-- Dethrone all KIBO champions (fitness was -6670, genome was bleeding)
UPDATE agent_genomes SET is_champion = false WHERE agent_id = 'KIBO' AND is_champion = true;

-- Crown a fresh default genome as KIBO champion
INSERT INTO agent_genomes (agent_id, generation, genome, fitness_score, total_pnl, is_champion, mutation_notes, composite_score, live_pnl)
VALUES (
  'KIBO',
  1,
  '{"min_rr":2.0,"min_gap":3,"max_hold_bars":12,"short_rsi_max":45,"long_target_rr":2.5,"short_stop_pct":0.97,"short_target_rr":2.0,"trend_threshold":0.002,"long_stop_low_mult":0.99,"long_stop_sma50_mult":0.995}'::jsonb,
  0,
  0,
  true,
  'Reset to defaults (champion was -6670)',
  0,
  0
);