-- Fix inflated paper_balance: should be starting (100) + realized PnL from non-APEX agents only
UPDATE system_config
SET paper_balance = 100 + (
  SELECT COALESCE(SUM(pnl), 0) FROM paper_trades
  WHERE status = 'CLOSED' AND agent_id != 'APEX'
),
total_team_pnl = (
  SELECT COALESCE(SUM(pnl), 0) FROM paper_trades
  WHERE status = 'CLOSED' AND agent_id != 'APEX'
)
WHERE id = 1;