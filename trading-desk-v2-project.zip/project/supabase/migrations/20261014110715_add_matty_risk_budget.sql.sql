-- Add matty_risk_pct column to system_config
ALTER TABLE system_config ADD COLUMN IF NOT EXISTS matty_risk_pct numeric DEFAULT 15;

-- Increase total risk to 60% so KIBO/YUZU (30%), REKT (15%), and MATTY (15%) all fit
UPDATE system_config SET max_total_risk_pct = 60.0;

-- Set matty_risk_pct to 15%
UPDATE system_config SET matty_risk_pct = 15.0;
