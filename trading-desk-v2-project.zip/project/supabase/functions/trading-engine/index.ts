import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY, {
  auth: { persistSession: false },
});

// ──────────────────────────────────────────────
// Types
// ──────────────────────────────────────────────

interface MarketTicker {
  symbol: string;
  lastPrice: number;
  high24h: number;
  low24h: number;
  priceChangePercent: number;
  volume24h: number;
  quoteVolume24h: number;
}

interface Kline {
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  time: number;
}

interface MarketData {
  ticker: MarketTicker;
  klines: Kline[];
  volatility: number;
  shortTermMove: number;
  volumeSpike: boolean;
  rsi: number;
  sma20: number;
  sma50: number;
  trendDirection: "UP" | "DOWN" | "SIDEWAYS";
  temporalScore: number;
  hourUtc: number;
}

interface AgentDecision {
  pass: boolean;
  approve: boolean;
  reason: string;
  details: Record<string, unknown>;
}

interface TradeProposal {
  agentId: string;
  symbol: string;
  entry: number;
  stop: number;
  target: number;
  riskReward: number;
  simulatedSize: number;
  maxDollarRisk: number;
  marketData: MarketData;
  temporalScore: number;
  direction?: "LONG" | "SHORT";
  liquidationPrice: number;
}

interface BayesianState {
  alpha: number;
  beta: number;
  edgeConfidence: number;
  shouldTrade: boolean;
  winProbability: number;
}

interface Genome {
  [key: string]: number;
}

// ──────────────────────────────────────────────
// Market Data — Bybit v5 public API (no key needed)
// ──────────────────────────────────────────────

// Taker fee per side, charged on notional (Bybit linear perps)
const TAKER_PREM = 0.00055;
const TAKER_FEE_RATE = 0.00055;

// Apply the live-loss-reduction gene: scope the stop loss tighter per agent
// (reduces average loss by exiting before the full stop distance).
const STOP_SCOPE_MULTS: Record<string, number> = { MOMO: 1, RIN: 1, SORA: 1, KIBO: 1, YUZU: 1, MATTY: 1, REKT: 1, APEX: 1, MIRAGE: 1 };

function scopeStopInPlace(p: TradeProposal): void {
  const mult = STOP_SCOPE_MULTS[p.agentId] ?? 1;
  if (mult === 1 || !p.entry) return;
  p.stop = p.entry + (p.stop - p.entry) * mult;
  p.maxDollarRisk = p.simulatedSize * Math.abs(p.entry - p.stop) / p.entry;
}

async function fetchTicker(symbol: string, category: string = "spot"): Promise<MarketTicker | null> {
  // 1) Bybit (primary)
  const urls = [
    `https://api.bybit.com/v5/market/tickers?category=${category}&symbol=${symbol}`,
    `https://api.bytick.com/v5/market/tickers?category=${category}&symbol=${symbol}`,
  ];
  for (const url of urls) {
    try {
      const res = await fetch(url);
      if (!res.ok) continue;
      const json = await res.json();
      const t = json?.result?.list?.[0];
      if (!t) continue;
      return {
        symbol,
        lastPrice: parseFloat(t.lastPrice),
        high24h: parseFloat(t.highPrice24h),
        low24h: parseFloat(t.lowPrice24h),
        priceChangePercent: parseFloat(t.price24hPcnt) * 100,
        volume24h: parseFloat(t.volume24h),
        quoteVolume24h: parseFloat(t.turnover24h),
      };
    } catch {
      continue;
    }
  }

  // 2) Binance Vision fallback (same USDT symbol names)
  try {
    const res = await fetch(`https://data-api.binance.vision/api/v3/ticker/24hr?symbol=${symbol}`);
    if (res.ok) {
      const t = await res.json();
      if (t?.lastPrice) {
        return {
          symbol,
          lastPrice: parseFloat(t.lastPrice),
          high24h: parseFloat(t.highPrice),
          low24h: parseFloat(t.lowPrice),
          priceChangePercent: parseFloat(t.priceChangePercent),
          volume24h: parseFloat(t.volume),
          quoteVolume24h: parseFloat(t.quoteVolume),
        };
      }
    }
  } catch {
    // fall through
  }

  // 3) OKX fallback (BTCUSDT -> BTC-USDT)
  const okxInst = symbol.replace(/USDT$/, "-USDT");
  try {
    const res = await fetch(`https://www.okx.com/api/v5/market/ticker?instId=${okxInst}-SWAP`);
    if (res.ok) {
      const json = await res.json();
      const t = json?.data?.[0];
      if (t?.last) {
        return {
          symbol,
          lastPrice: parseFloat(t.last),
          high24h: parseFloat(t.high24h),
          low24h: parseFloat(t.low24h),
          priceChangePercent: parseFloat(t.open24h) > 0 ? ((parseFloat(t.last) - parseFloat(t.open24h)) / parseFloat(t.open24h)) * 100 : 0,
          volume24h: parseFloat(t.vol24h),
          quoteVolume24h: parseFloat(t.volCcy24h),
        };
      }
    }
  } catch {
    // fall through
  }
  return null;
}

async function fetchKlines(symbol: string, interval: string = "60", limit: number = 100, category: string = "spot"): Promise<Kline[]> {
  const cacheKey = `${category}:${symbol}:${interval}:${limit}`;
  const cached = klineCache.get(cacheKey);
  if (cached && Date.now() - cached.fetchedAt < KLINE_CACHE_TTL_MS) return cached.klines;

  const toOkxBar = (i: string) => ({ "60": "1H", "5": "5m", "1": "1m" } as Record<string, string>)[i] || "1H";
  const toOkxInst = (s: string) => s.replace(/USDT$/, "-USDT-SWAP");
  const toBinanceInterval = (i: string) => ({ "60": "1h", "5": "5m", "1": "1m" } as Record<string, string>)[i] || "1h";

  const tryBinanceVision = async (): Promise<Kline[]> => {
    try {
      const res = await fetch(`https://data-api.binance.vision/api/v3/klines?symbol=${symbol}&interval=${toBinanceInterval(interval)}&limit=${limit}`);
      if (!res.ok) return [];
      const json = await res.json();
      if (!Array.isArray(json)) return [];
      return json.map((k: (string | number)[]) => ({
        time: Number(k[0]),
        open: parseFloat(String(k[1])),
        high: parseFloat(String(k[2])),
        low: parseFloat(String(k[3])),
        close: parseFloat(String(k[4])),
        volume: parseFloat(String(k[5])),
      }));
    } catch {
      return [];
    }
  };

  const tryOkx = async (): Promise<Kline[]> => {
    try {
      const res = await fetch(`https://www.okx.com/api/v5/market/candles?instId=${toOkxInst(symbol)}&bar=${toOkxBar(interval)}&limit=${Math.min(limit, 300)}`);
      if (!res.ok) return [];
      const json = await res.json();
      const list = json?.data;
      if (!Array.isArray(list)) return [];
      return list
        .map((k: string[]) => ({
          time: parseInt(k[0]),
          open: parseFloat(k[1]),
          high: parseFloat(k[2]),
          low: parseFloat(k[3]),
          close: parseFloat(k[4]),
          volume: parseFloat(k[5]),
        }))
        .sort((a: Kline, b: Kline) => a.time - b.time);
    } catch {
      return [];
    }
  };

  // 1) Bybit (primary)
  const urls = [
    `https://api.bybit.com/v5/market/kline?category=${category}&symbol=${symbol}&interval=${interval}&limit=${limit}`,
    `https://api.bytick.com/v5/market/kline?category=${category}&symbol=${symbol}&interval=${interval}&limit=${limit}`,
  ];
  for (const url of urls) {
    try {
      const res = await fetch(url);
      if (!res.ok) continue;
      const json = await res.json();
      const list = json?.result?.list;
      if (!Array.isArray(list)) continue;
      const parsed = list
        .map((k: string[]) => ({
          time: parseInt(k[0]),
          open: parseFloat(k[1]),
          high: parseFloat(k[2]),
          low: parseFloat(k[3]),
          close: parseFloat(k[4]),
          volume: parseFloat(k[5]),
        }))
        .sort((a: Kline, b: Kline) => a.time - b.time);
      klineCache.set(cacheKey, { klines: parsed, fetchedAt: Date.now() });
      return parsed;
    } catch {
      continue;
    }
  }

  // 2-3) Fallbacks
  const binanceKlines = await tryBinanceVision();
  if (binanceKlines.length > 0) {
    klineCache.set(cacheKey, { klines: binanceKlines, fetchedAt: Date.now() });
    return binanceKlines;
  }
  const okxKlines = await tryOkx();
  if (okxKlines.length > 0) {
    klineCache.set(cacheKey, { klines: okxKlines, fetchedAt: Date.now() });
    return okxKlines;
  }
  return [];
}

// Fetch COMPLETE historical 1m candles since entry. Never silently truncate
// a trade to the last 1,000 candles or substitute another exchange's prices.
async function fetchTradeCandles(symbol: string, category: string, openedAt: number): Promise<Kline[] | null> {
  const minute = 60_000;
  const lastCompleteStart = Math.floor(Date.now() / minute) * minute - minute;
  const start = Math.floor(openedAt / minute) * minute;
  if (start > lastCompleteStart) return [];
  const candles: Kline[] = [];
  let cursor = start;
  for (let page = 0; page < 30 && cursor <= lastCompleteStart; page++) {
    const end = Math.min(lastCompleteStart, cursor + 999 * minute);
    let pageRows: Kline[] | null = null;
    for (const host of ["api.bybit.com", "api.bytick.com"]) {
      try {
        const url = `https://${host}/v5/market/kline?category=${category}&symbol=${encodeURIComponent(symbol)}&interval=1&start=${cursor}&end=${end}&limit=1000`;
        const response = await fetch(url);
        if (!response.ok) continue;
        const payload = await response.json();
        if (payload.retCode !== 0 || !Array.isArray(payload.result?.list)) continue;
        pageRows = payload.result.list.map((k: string[]) => ({
          time: Number(k[0]), open: Number(k[1]), high: Number(k[2]),
          low: Number(k[3]), close: Number(k[4]), volume: Number(k[5]),
        })).filter((k: Kline) => Number.isFinite(k.time) && [k.open,k.high,k.low,k.close].every(Number.isFinite))
          .sort((a: Kline,b: Kline) => a.time - b.time);
        break;
      } catch { /* Retry secondary Bybit hostname. */ }
    }
    if (!pageRows || pageRows.length === 0) return null;
    const unique = new Map(pageRows.map(k => [k.time, k]));
    const sorted = [...unique.values()].sort((a,b) => a.time - b.time);
    // Refuse to invent candle data if the price feed has a gap.
    for (let expected = cursor; expected <= end; expected += minute) {
      const candle = unique.get(expected);
      if (!candle) return null;
      candles.push(candle);
    }
    cursor = end + minute;
  }
  return cursor > lastCompleteStart ? candles : null;
}

// Pure performance cache — a reset just means re-downloading candles, never a correctness issue
const klineCache = new Map<string, { klines: Kline[]; fetchedAt: number }>();
const KLINE_CACHE_TTL_MS = 10 * 60 * 1000;

// Scan Bybit linear perps for the most volatile coins by absolute 24h price
// change, filtered by minimum volume. Bybit is blocked in some regions
// (CloudFront 403), so fall back to OKX swaps tickers — same USDT symbol
// naming after stripping the suffix.
async function fetchTopMoversPerp(minVolumeUsd: number = 50_000_000, maxResults: number = 15): Promise<string[]> {
  const urls = [
    "https://api.bybit.com/v5/market/tickers?category=linear",
    "https://api.bytick.com/v5/market/tickers?category=linear",
  ];
  for (const url of urls) {
    try {
      const res = await fetch(url);
      if (!res.ok) continue;
      const json = await res.json();
      const list = json?.result?.list;
      if (!Array.isArray(list)) continue;

      const movers = list
        .map((t: Record<string, string>) => ({
          symbol: t.symbol,
          turnover24h: parseFloat(t.turnover24h),
          priceChangePct: Math.abs(parseFloat(t.price24hPcnt) * 100),
        }))
        .filter((t: { symbol: string; turnover24h: number; priceChangePct: number }) =>
          t.symbol.endsWith("USDT") &&
          !t.symbol.includes("PERP") &&
          t.turnover24h >= minVolumeUsd &&
          t.priceChangePct > 0
        )
        .sort((a: { priceChangePct: number }, b: { priceChangePct: number }) => b.priceChangePct - a.priceChangePct)
        .slice(0, maxResults)
        .map((t: { symbol: string }) => t.symbol);
      if (movers.length > 0) return movers;
    } catch {
      continue;
    }
  }

  // OKX fallback
  try {
    const res = await fetch("https://www.okx.com/api/v5/market/tickers?instType=SWAP");
    if (res.ok) {
      const json = await res.json();
      const list = json?.data;
      if (Array.isArray(list)) {
        return list
          .map((t: Record<string, string>) => ({
            symbol: String(t.instId || "").replace(/-USDT-SWAP$/, "USDT"),
            quoteVolume24h: parseFloat(t.volCcy24h || "0"),
            last: parseFloat(t.last || "0"),
            open24h: parseFloat(t.open24h || "0"),
          }))
          .filter((t: { symbol: string; quoteVolume24h: number; last: number; open24h: number }) =>
            t.symbol.endsWith("USDT") &&
            !t.symbol.includes("PERP") &&
            t.quoteVolume24h >= minVolumeUsd &&
            t.last > 0 && t.open24h > 0
          )
          .map((t: { last: number; open24h: number; symbol: string }) => ({
            symbol: t.symbol,
            priceChangePct: Math.abs(((t.last - t.open24h) / t.open24h) * 100),
          }))
          .filter((t: { priceChangePct: number }) => t.priceChangePct > 0)
          .sort((a: { priceChangePct: number }, b: { priceChangePct: number }) => b.priceChangePct - a.priceChangePct)
          .slice(0, maxResults)
          .map((t: { symbol: string }) => t.symbol);
      }
    }
  } catch {
    // fall through
  }
  return [];
}

function calcRSI(klines: Kline[], period: number = 14): number {
  if (klines.length < period + 1) return 50;
  let gains = 0;
  let losses = 0;
  for (let i = klines.length - period; i < klines.length; i++) {
    const change = klines[i].close - klines[i - 1].close;
    if (change >= 0) gains += change;
    else losses -= change;
  }
  const avgGain = gains / period;
  const avgLoss = losses / period;
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - 100 / (1 + rs);
}

function calcSMA(klines: Kline[], period: number): number {
  if (klines.length < period) return klines[klines.length - 1]?.close ?? 0;
  let sum = 0;
  for (let i = klines.length - period; i < klines.length; i++) {
    sum += klines[i].close;
  }
  return sum / period;
}

function calcATR(klines: Kline[], period: number = 14): number {
  if (klines.length < period + 1) return 0;
  const trs: number[] = [];
  for (let i = klines.length - period; i < klines.length; i++) {
    const tr = Math.max(
      klines[i].high - klines[i].low,
      Math.abs(klines[i].high - klines[i - 1].close),
      Math.abs(klines[i].low - klines[i - 1].close)
    );
    trs.push(tr);
  }
  return trs.reduce((a, b) => a + b, 0) / trs.length;
}

// Per-symbol leverage caps for APEX — volatile coins get lower max leverage
// to prevent liquidation before the stop loss triggers
const APEX_LEVERAGE_CAPS: Record<string, number> = {
  BTCUSDT: 100, ETHUSDT: 100, BNBUSDT: 100, SOLUSDT: 100,
  XRPUSDT: 25, LINKUSDT: 25, AVAXUSDT: 25, DOGEUSDT: 25, ADAUSDT: 25,
  WIFUSDT: 10, PEPEUSDT: 10,
};
const APEX_DEFAULT_PERP_LEVERAGE = 20;

function apexLeverageForSymbol(symbol: string, isPerp: boolean): number {
  if (!isPerp) {
    return (APEX_LEVERAGE_CAPS as Record<string, number>)[symbol] || 10;
  }
  return (APEX_LEVERAGE_CAPS as Record<string, number>)[symbol] || APEX_DEFAULT_PERP_LEVERAGE;
}

function calcVolatility(klines: Kline[], period: number = 20): number {
  if (klines.length < period + 1) return 0;
  const returns: number[] = [];
  for (let i = klines.length - period; i < klines.length; i++) {
    if (klines[i - 1].close > 0) {
      returns.push((klines[i].close - klines[i - 1].close) / klines[i - 1].close);
    }
  }
  const mean = returns.reduce((a, b) => a + b, 0) / returns.length;
  const variance = returns.reduce((a, b) => a + (b - mean) ** 2, 0) / returns.length;
  return Math.sqrt(variance) * 100;
}

// ──────────────────────────────────────────────
// Stop clamping — ensure stop loss triggers before liquidation
// With high leverage, the liquidation price can be closer to entry
// than the stop loss. This would cause a full-position-loss liquidation
// instead of a controlled stop-out. We clamp the stop to sit safely
// inside the liquidation price (90% of the distance to liquidation).
// ──────────────────────────────────────────────

function clampStopToLiquidation(
  entry: number,
  stop: number,
  leverage: number
): { stop: number; liquidationPrice: number } {
  const liqDistance = (entry / leverage) * 0.9;
  const isShort = stop > entry;
  const liquidationPrice = isShort ? entry + liqDistance : entry - liqDistance;

  if (isShort) {
    const maxStop = entry + liqDistance * 0.9;
    if (stop > maxStop) return { stop: maxStop, liquidationPrice };
  } else {
    const minStop = entry - liqDistance * 0.9;
    if (stop < minStop) return { stop: minStop, liquidationPrice };
  }

  return { stop, liquidationPrice };
}

// Mirror a proposal around its entry price: a LONG becomes an equivalent
// SHORT (and vice versa) with identical geometry. Used by the trade_direction
// gene — a champion that evolved trade_direction = -1 runs every signal
// mirrored, exactly like the backtests that crowned it.
function mirrorProposalGeometry(
  proposal: TradeProposal,
  leverage: number
): TradeProposal {
  const entry = proposal.entry;
  const stop = 2 * entry - proposal.stop;
  const target = 2 * entry - proposal.target;
  const { stop: clampedStop, liquidationPrice } = clampStopToLiquidation(entry, stop, leverage);
  const risk = Math.abs(entry - clampedStop);
  const reward = Math.abs(target - entry);
  const rr = risk > 0 ? reward / risk : 0;
  const simulatedSize = proposal.simulatedSize;
  return {
    ...proposal,
    stop: clampedStop,
    target,
    riskReward: rr,
    simulatedSize,
    maxDollarRisk: simulatedSize * (risk / entry),
    direction: proposal.direction === "LONG" ? "SHORT" : proposal.direction === "SHORT" ? "LONG" : proposal.direction,
    liquidationPrice,
  };
}

// Reject direction/stop/target inconsistencies before paper trade creation.
function validTradeGeometry(p: TradeProposal): boolean {
  if (![p.entry, p.stop, p.target, p.simulatedSize].every(Number.isFinite)) return false;
  if (p.entry <= 0 || p.stop <= 0 || p.target <= 0 || p.simulatedSize <= 0) return false;
  return p.direction === "LONG"
    ? p.stop < p.entry && p.entry < p.target
    : p.direction === "SHORT" && p.target < p.entry && p.entry < p.stop;
}

// ──────────────────────────────────────────────
// Temporal Bias — analyze which hours trend vs chop
// ──────────────────────────────────────────────

async function refreshTemporalBias(symbols: string[]): Promise<void> {
  for (const symbol of symbols) {
    try {
      // Fetch 30 days of 1-hour candles (720 candles)
      const klines = await fetchKlines(symbol, "60", 720);
      if (klines.length < 100) continue;

      // Group by UTC hour and compute average absolute move
      const hourData: Record<number, number[]> = {};
      for (let i = 1; i < klines.length; i++) {
        const hour = new Date(klines[i].time).getUTCHours();
        const pctMove = Math.abs(
          ((klines[i].close - klines[i - 1].close) / klines[i - 1].close) * 100
        );
        const directionalMove =
          ((klines[i].close - klines[i - 1].close) / klines[i - 1].close) * 100;

        if (!hourData[hour]) hourData[hour] = [];
        // Store directional move for trending score
        hourData[hour].push(directionalMove);
      }

      const overallAvgMove =
        Object.values(hourData).flat().reduce((a, b) => a + Math.abs(b), 0) /
        Object.values(hourData).flat().length || 1;

      const rows: { symbol: string; hour: number; avg_move: number; trending_score: number; sample_size: number }[] = [];

      for (let h = 0; h < 24; h++) {
        const moves = hourData[h] || [];
        if (moves.length < 3) {
          rows.push({ symbol, hour: h, avg_move: 0, trending_score: 0, sample_size: moves.length });
          continue;
        }

        const avgMove = moves.reduce((a, b) => a + Math.abs(b), 0) / moves.length;
        // Trending score: ratio of directional bias to overall volatility
        // If moves are consistently in one direction, score approaches 1 or -1
        // If moves are random (choppy), score approaches 0
        const avgDirectional = moves.reduce((a, b) => a + b, 0) / moves.length;
        const trendingScore = avgMove > 0
          ? Math.max(-1, Math.min(1, (avgDirectional / overallAvgMove) * 0.5))
          : 0;

        rows.push({
          symbol,
          hour: h,
          avg_move: Math.round(avgMove * 100) / 100,
          trending_score: Math.round(trendingScore * 1000) / 1000,
          sample_size: moves.length,
        });
      }

      // Upsert into temporal_bias_cache
      for (const row of rows) {
        await supabase
          .from("temporal_bias_cache")
          .upsert({
            symbol: row.symbol,
            hour: row.hour,
            avg_move: row.avg_move,
            trending_score: row.trending_score,
            sample_size: row.sample_size,
            updated_at: new Date().toISOString(),
          }, { onConflict: "symbol,hour" });
      }
    } catch {
      // skip symbol on error
    }
  }
}

async function getTemporalScore(symbol: string, hourUtc: number): Promise<{ score: number; avgMove: number; sampleSize: number }> {
  const { data } = await supabase
    .from("temporal_bias_cache")
    .select("trending_score, avg_move, sample_size, updated_at")
    .eq("symbol", symbol)
    .eq("hour", hourUtc)
    .maybeSingle();

  if (!data) return { score: 0, avgMove: 0, sampleSize: 0 };

  // Check if cache is stale (> 24 hours old)
  const cacheAge = (Date.now() - new Date(data.updated_at).getTime()) / (1000 * 60 * 60);
  if (cacheAge > 24) return { score: 0, avgMove: 0, sampleSize: 0 };

  return {
    score: data.trending_score,
    avgMove: data.avg_move,
    sampleSize: data.sample_size,
  };
}

// ──────────────────────────────────────────────
// Bayesian Updating — agents learn from their track record
// ──────────────────────────────────────────────

async function getBayesianState(agentId: string): Promise<BayesianState> {
  const { data: stats } = await supabase
    .from("agent_stats")
    .select("wins, losses, bayesian_alpha, bayesian_beta, edge_confidence, should_trade")
    .eq("agent_id", agentId)
    .maybeSingle();

  if (!stats) {
    return { alpha: 2, beta: 2, edgeConfidence: 0, shouldTrade: true, winProbability: 0.5 };
  }

  const alpha = stats.bayesian_alpha ?? 2;
  const beta = stats.bayesian_beta ?? 2;
  const totalTrades = stats.wins + stats.losses;
  const winProbability = alpha / (alpha + beta);

  // Confidence: how much the data dominates the prior
  // Prior is alpha=2, beta=2 (weight of 4 pseudo-observations)
  // After 20 real trades, data dominates. After 50, we're very confident.
  const confidence = Math.min(100, (totalTrades / (totalTrades + 4)) * 100);

  // Circuit breaker: if we have enough data and win rate is bad, stop trading.
  // APEX is exempt: it's a mission bot — its per-strategy cooldowns and adaptive
  // weights already cut capital to losing strategies, so an agent-level halt
  // would just freeze the whole mission even after strategy changes.
  let shouldTrade = stats.should_trade ?? true;
  if (agentId === "APEX") {
    shouldTrade = true;
  } else if (totalTrades >= 20 && winProbability < 0.35) {
    shouldTrade = false;
  } else if (totalTrades >= 20 && winProbability >= 0.40) {
    shouldTrade = true;
  }

  return {
    alpha,
    beta,
    edgeConfidence: confidence,
    shouldTrade,
    winProbability,
  };
}

async function updateBayesianState(agentId: string, isWin: boolean): Promise<void> {
  const { data: stats } = await supabase
    .from("agent_stats")
    .select("bayesian_alpha, bayesian_beta, wins, losses")
    .eq("agent_id", agentId)
    .maybeSingle();

  if (!stats) return;

  const newAlpha = (stats.bayesian_alpha ?? 2) + (isWin ? 1 : 0);
  const newBeta = (stats.bayesian_beta ?? 2) + (isWin ? 0 : 1);
  const totalTrades = (stats.wins ?? 0) + (stats.losses ?? 0) + 1;
  const winProb = newAlpha / (newAlpha + newBeta);
  const confidence = Math.min(100, (totalTrades / (totalTrades + 4)) * 100);

  let shouldTrade = true;
  if (agentId !== "APEX" && totalTrades >= 20 && winProb < 0.35) shouldTrade = false;

  await supabase
    .from("agent_stats")
    .update({
      bayesian_alpha: newAlpha,
      bayesian_beta: newBeta,
      edge_confidence: confidence,
      should_trade: shouldTrade,
    })
    .eq("agent_id", agentId);
}

// ──────────────────────────────────────────────
// Per-symbol learning — agents learn which symbols they're profitable on
// ──────────────────────────────────────────────

async function shouldTradeSymbol(agentId: string, symbol: string): Promise<{ allowed: boolean; reason: string }> {
  const { data } = await supabase
    .from("agent_symbol_stats")
    .select("*")
    .eq("agent_id", agentId)
    .eq("symbol", symbol)
    .maybeSingle();

  if (!data) return { allowed: true, reason: "No history for this symbol" };

  if (!data.should_trade) {
    return { allowed: false, reason: `Symbol disabled: ${data.wins}W/${data.losses}L over ${data.total_trades} trades` };
  }

  if (data.cooldown_until && new Date(data.cooldown_until) > new Date()) {
    const remaining = Math.ceil((new Date(data.cooldown_until).getTime() - Date.now()) / (1000 * 60 * 60));
    return { allowed: false, reason: `Cooldown: ${data.consecutive_losses} consecutive losses, ${remaining}h remaining` };
  }

  return { allowed: true, reason: `${data.wins}W/${data.losses}L (${data.win_rate.toFixed(0)}% win rate)` };
}

async function updateSymbolStats(agentId: string, symbol: string, isWin: boolean, pnl: number): Promise<void> {
  const { data: existing } = await supabase
    .from("agent_symbol_stats")
    .select("*")
    .eq("agent_id", agentId)
    .eq("symbol", symbol)
    .maybeSingle();

  const now = new Date().toISOString();

  if (!existing) {
    const consecLosses = isWin ? 0 : 1;
    const cooldownUntil = !isWin && consecLosses >= 3
      ? new Date(Date.now() + 4 * 60 * 60 * 1000).toISOString()
      : null;

    await supabase.from("agent_symbol_stats").insert({
      agent_id: agentId,
      symbol,
      total_trades: 1,
      wins: isWin ? 1 : 0,
      losses: isWin ? 0 : 1,
      consecutive_losses: consecLosses,
      max_consecutive_losses: consecLosses,
      win_rate: isWin ? 100 : 0,
      total_pnl: pnl,
      bayesian_alpha: 2 + (isWin ? 1 : 0),
      bayesian_beta: 2 + (isWin ? 0 : 1),
      should_trade: true,
      last_trade_at: now,
      cooldown_until: cooldownUntil,
      updated_at: now,
    });
    return;
  }

  const totalTrades = existing.total_trades + 1;
  const wins = existing.wins + (isWin ? 1 : 0);
  const losses = existing.losses + (isWin ? 0 : 1);
  const consecLosses = isWin ? 0 : existing.consecutive_losses + 1;
  const maxConsecLosses = Math.max(existing.max_consecutive_losses, consecLosses);
  const closedTrades = wins + losses;
  const winRate = closedTrades > 0 ? (wins / closedTrades) * 100 : 0;
  const totalPnl = existing.total_pnl + pnl;

  const newAlpha = existing.bayesian_alpha + (isWin ? 1 : 0);
  const newBeta = existing.bayesian_beta + (isWin ? 0 : 1);
  const winProb = newAlpha / (newAlpha + newBeta);

  let shouldTrade = existing.should_trade;
  if (closedTrades >= 10 && winProb < 0.35) shouldTrade = false;
  else if (closedTrades >= 15 && winProb >= 0.45) shouldTrade = true;

  const cooldownUntil = !isWin && consecLosses >= 3
    ? new Date(Date.now() + 4 * 60 * 60 * 1000).toISOString()
    : isWin ? null : existing.cooldown_until;

  await supabase
    .from("agent_symbol_stats")
    .update({
      total_trades: totalTrades,
      wins,
      losses,
      consecutive_losses: consecLosses,
      max_consecutive_losses: maxConsecLosses,
      win_rate: winRate,
      total_pnl: totalPnl,
      bayesian_alpha: newAlpha,
      bayesian_beta: newBeta,
      should_trade: shouldTrade,
      last_trade_at: now,
      cooldown_until: cooldownUntil,
      updated_at: now,
    })
    .eq("id", existing.id);
}

// ──────────────────────────────────────────────
// Market data gathering with temporal bias
// ──────────────────────────────────────────────

async function gatherMarketData(symbol: string): Promise<MarketData | null> {
  const ticker = await fetchTicker(symbol);
  if (!ticker) return null;
  const klines = await fetchKlines(symbol, "60", 100);
  if (klines.length < 20) return null;

  const recentCloses = klines.slice(-10).map((k) => k.close);
  const firstClose = recentCloses[0];
  const lastClose = recentCloses[recentCloses.length - 1];
  const shortTermMove = firstClose > 0 ? ((lastClose - firstClose) / firstClose) * 100 : 0;

  const avgVolume = klines.slice(-20, -5).reduce((a, b) => a + b.volume, 0) / 15;
  const recentVolume = klines[klines.length - 1].volume;
  const volumeSpike = avgVolume > 0 && recentVolume > avgVolume * 2;

  const rsi = calcRSI(klines, 14);
  const sma20 = calcSMA(klines, 20);
  const sma50 = calcSMA(klines, Math.min(50, klines.length));
  const volatility = calcVolatility(klines, 20);

  let trendDirection: "UP" | "DOWN" | "SIDEWAYS" = "SIDEWAYS";
  if (sma20 > sma50 * 1.002) trendDirection = "UP";
  else if (sma20 < sma50 * 0.998) trendDirection = "DOWN";

  const hourUtc = new Date().getUTCHours();
  const temporal = await getTemporalScore(symbol, hourUtc);

  return {
    ticker,
    klines,
    volatility,
    shortTermMove,
    volumeSpike,
    rsi,
    sma20,
    sma50,
    trendDirection,
    temporalScore: temporal.score,
    hourUtc,
  };
}

const DEFAULT_GENOMES: Record<string, Genome> = {
  KIBO: {
    trend_threshold: 0.002,
    long_stop_sma50_mult: 0.995,
    long_stop_low_mult: 0.99,
    long_target_rr: 2.5,
    short_rsi_max: 45,
    short_stop_pct: 0.97,
    short_target_rr: 2.0,
    min_rr: 2.0,
    max_hold_bars: 12,
    min_gap: 3,
    trade_direction: 1,
  },
  YUZU: {
    trend_threshold: 0.002,
    long_stop_low_mult: 0.995,
    long_target_rr: 1.8,
    short_rsi_max: 50,
    short_stop_pct: 0.98,
    short_target_rr: 1.5,
    min_rr: 1.5,
    max_hold_bars: 3,
    min_gap: 2,
    trade_direction: 1,
  },
  MATTY: {
    pattern_lookback: 40,
    pattern_tolerance: 1.5,
    stop_buffer_pct: 0.3,
    target_rr: 1.8,
    min_rr: 1.2,
    max_hold_bars: 36,
    min_gap: 3,
    trade_direction: 1,
  },
  REKT: {
    min_momentum: 0.3,
    min_rsi_long: 45,
    max_rsi_long: 78,
    min_rsi_short: 22,
    max_rsi_short: 55,
    trend_threshold: 0.001,
    min_stop_pct: 0.5,
    max_stop_pct: 1.0,
    target_rr: 1.5,
    min_rr: 1.2,
    max_hold_bars: 6,
    min_gap: 1,
    trade_direction: 1,
  },
  APEX: {
    min_momentum: 0.15,
    min_rsi_long: 40,
    max_rsi_long: 72,
    min_rsi_short: 28,
    max_rsi_short: 60,
    trend_threshold: 0.0008,
    min_stop_pct: 0.4,
    max_stop_pct: 1.2,
    target_rr: 2.0,
    min_rr: 1.5,
    max_hold_bars: 8,
    min_gap: 2,
    trade_direction: 1,
  },
};

async function loadChampionGenomes(): Promise<Record<string, Genome>> {
  const { data } = await supabase
    .from("agent_genomes")
    .select("agent_id, genome")
    .eq("is_champion", true);

  const genomes: Record<string, Genome> = {};
  for (const row of data || []) {
    if (row.agent_id && row.genome) {
      genomes[row.agent_id] = { ...DEFAULT_GENOMES[row.agent_id], ...row.genome };
    }
  }

  for (const agent of ["KIBO", "YUZU", "MATTY", "REKT", "APEX"]) {
    if (!genomes[agent]) genomes[agent] = DEFAULT_GENOMES[agent];
  }

  return genomes;
}

// ──────────────────────────────────────────────
// Agent 1: MOMO — Launch Quality Filter
// ──────────────────────────────────────────────

function momoAgent(data: MarketData): AgentDecision {
  const t = data.ticker;
  const details: Record<string, unknown> = {};

  const liquidityScore = Math.min(100, Math.log10(t.quoteVolume24h + 1) * 12);
  details.liquidityScore = Math.round(liquidityScore);
  details.quoteVolume24h = t.quoteVolume24h;

  const volumeHealthy = t.quoteVolume24h > 100000;
  details.volumeHealthy = volumeHealthy;

  const volatilityOk = data.volatility < 8;
  details.volatility = data.volatility.toFixed(2);

  const notPumped = Math.abs(t.priceChangePercent) < 15;
  details.priceChange24h = t.priceChangePercent.toFixed(2);

  const quality =
    liquidityScore > 40 && volumeHealthy && volatilityOk && notPumped
      ? "STRONG"
      : liquidityScore > 25 && volumeHealthy
      ? "MIXED"
      : "WEAK";

  details.quality = quality;
  const pass = quality !== "WEAK";

  let mainRisk = "";
  if (!volumeHealthy) mainRisk = "Insufficient 24h volume";
  else if (!volatilityOk) mainRisk = "Extreme volatility";
  else if (!notPumped) mainRisk = "Already pumped significantly in 24h";
  else if (liquidityScore <= 25) mainRisk = "Low liquidity depth";
  else mainRisk = "None identified";

  details.mainRisk = mainRisk;

  return {
    pass,
    approve: pass,
    reason: `QUALITY: ${quality} | PASS: ${pass ? "YES" : "NO"} | MAIN RISK: ${mainRisk}`,
    details,
  };
}

// ──────────────────────────────────────────────
// Agent 2: RIN — Whale Activity Tracker
// ──────────────────────────────────────────────

function rinAgent(data: MarketData): AgentDecision {
  const details: Record<string, unknown> = {};

  const recentKlines = data.klines.slice(-10);
  const recentVolumes = recentKlines.map((k) => k.volume);
  const avgVol = recentVolumes.reduce((a, b) => a + b, 0) / recentVolumes.length;
  const lastVol = recentVolumes[recentVolumes.length - 1];
  const volRatio = avgVol > 0 ? lastVol / avgVol : 1;

  details.volumeSpike = data.volumeSpike;
  details.recentVolumeRatio = volRatio.toFixed(2);
  details.avgVolume = avgVol.toFixed(0);

  const candleRanges = recentKlines.map((k) => k.high - k.low);
  const avgCandleRange = candleRanges.reduce((a, b) => a + b, 0) / candleRanges.length;
  const lastCandleRange = candleRanges[candleRanges.length - 1];
  const largeCandle = avgCandleRange > 0 && lastCandleRange > avgCandleRange * 2.5;
  details.largeCandleDetected = largeCandle;

  const aboveAvgCount = recentVolumes.filter((v) => v > avgVol * 1.5).length;
  const activityClustered = aboveAvgCount >= 3;
  details.activityClustered = activityClustered;

  const extremeVolumeSpike = volRatio > 5;
  const dangerousOverbought = data.rsi > 80 && extremeVolumeSpike;
  const dangerousOversold = data.rsi < 20 && extremeVolumeSpike;
  const manipulationRisk = extremeVolumeSpike && data.trendDirection === "SIDEWAYS";

  const passSignal = !dangerousOverbought && !dangerousOversold && !manipulationRisk;

  details.rsi = data.rsi.toFixed(1);
  details.passSignal = passSignal;
  details.whaleActivity = data.volumeSpike || activityClustered;

  let walletsOfInterest = "Normal activity";
  if (extremeVolumeSpike) walletsOfInterest = "Extreme volume spike — whale likely";
  else if (data.volumeSpike) walletsOfInterest = "Volume spike detected";
  else if (activityClustered) walletsOfInterest = "Clustered volume above average";

  return {
    pass: passSignal,
    approve: passSignal,
    reason: `WALLETS OF INTEREST: ${walletsOfInterest} | VOL RATIO: ${volRatio.toFixed(2)}x | CLUSTERED: ${activityClustered} | PASS SIGNAL: ${passSignal ? "YES" : "NO"}`,
    details,
  };
}

// ──────────────────────────────────────────────
// Agent 3: SORA — Anti-FOMO Risk Gate
// ──────────────────────────────────────────────

function soraAgent(data: MarketData, proposedEntry: number, proposedStop: number): AgentDecision {
  const details: Record<string, unknown> = {};

  const isLong = proposedStop < proposedEntry;

  const extremeMove = Math.abs(data.shortTermMove) > 15;
  details.shortTermMove = data.shortTermMove.toFixed(2);
  details.extremeMove = extremeMove;

  const overbought = data.rsi > 82;
  const oversold = data.rsi < 18;
  details.rsi = data.rsi.toFixed(1);
  details.direction = isLong ? "LONG" : "SHORT";

  const tooVolatile = data.volatility > 12;
  details.volatility = data.volatility.toFixed(2);

  const stopDistance = Math.abs(proposedEntry - proposedStop);
  const stopPct = proposedEntry > 0 ? (stopDistance / proposedEntry) * 100 : 0;
  const stopClear = stopPct > 0.5 && stopPct < 8;
  details.stopPct = stopPct.toFixed(2);

  const hypeDriven = data.volumeSpike && extremeMove;
  details.hypeDriven = hypeDriven;

  let block = false;
  let reason = "";

  if (extremeMove) {
    block = true;
    reason = "Extreme short-term move detected — avoid chasing";
  } else if (overbought && isLong) {
    block = true;
    reason = "RSI extremely overbought — long entry too late (FOMO)";
  } else if (oversold && isLong) {
    block = true;
    reason = "RSI extremely oversold — potential falling knife for longs";
  } else if (tooVolatile) {
    block = true;
    reason = "Volatility too high for safe entry";
  } else if (!stopClear) {
    block = true;
    reason = `Stop level unclear (${stopPct.toFixed(2)}% from entry)`;
  } else if (hypeDriven) {
    block = true;
    reason = "Setup appears hype-driven";
  } else {
    reason = "All risk checks passed";
  }

  details.blocked = block;

  return {
    pass: !block,
    approve: !block,
    reason: `${block ? "BLOCK" : "APPROVE"} | REASON: ${reason}`,
    details,
  };
}

// ──────────────────────────────────────────────
// Agent 4: KIBO — Big-Setup Agent (with temporal bias + Bayesian)
// ──────────────────────────────────────────────

function kiboAgent(data: MarketData, bayes: BayesianState, maxDollarRisk: number, paperBalance: number, leverage: number, genome: Genome): TradeProposal | null {
  const t = data.ticker;
  const price = t.lastPrice;

  // Recompute trend with genome threshold (may differ from the rough gatherMarketData threshold)
  let trendDirection: "UP" | "DOWN" | "SIDEWAYS" = "SIDEWAYS";
  if (data.sma20 > data.sma50 * (1 + genome.trend_threshold)) trendDirection = "UP";
  else if (data.sma20 < data.sma50 * (1 - genome.trend_threshold)) trendDirection = "DOWN";

  if (trendDirection === "SIDEWAYS") return null;

  if (!bayes.shouldTrade) return null;

  const temporalBoost = data.temporalScore;
  if (temporalBoost < -0.3 && trendDirection === "UP") return null;

  let entry: number, stop: number, target: number;

  if (trendDirection === "UP") {
    entry = price;
    stop = Math.min(data.sma50 * genome.long_stop_sma50_mult, data.klines[data.klines.length - 1].low * genome.long_stop_low_mult);
    const risk = entry - stop;
    if (risk <= 0) return null;
    const rrMultiplier = 1 + (bayes.winProbability - 0.5) * 0.2;
    target = entry + risk * Math.max(1.8, genome.long_target_rr * rrMultiplier);
  } else {
    if (data.rsi > genome.short_rsi_max) return null;
    entry = price;
    stop = price * genome.short_stop_pct;
    const risk = stop - entry;
    if (risk <= 0) return null;
    const rrMultiplier = 1 + (bayes.winProbability - 0.5) * 0.3;
    target = entry - risk * Math.max(1.5, genome.short_target_rr * rrMultiplier);
  }

  const { stop: _clampedStop, liquidationPrice } = clampStopToLiquidation(entry, stop, leverage);
  stop = _clampedStop;

  const risk = Math.abs(entry - stop);
  const reward = Math.abs(target - entry);
  const rr = risk > 0 ? reward / risk : 0;

  const minRR = bayes.edgeConfidence > 50
    ? Math.max(1.5, genome.min_rr - (bayes.winProbability - 0.5))
    : genome.min_rr;

  if (rr < minRR) return null;

  if (paperBalance <= 0 || maxDollarRisk <= 0) return null;
  const maxNotional = paperBalance * leverage;
  const rawSize = (maxDollarRisk / risk) * entry;
  const simulatedSize = Math.min(rawSize, maxNotional);
  const actualRisk = simulatedSize * (risk / entry);

  let proposal: TradeProposal = {
    agentId: "KIBO",
    symbol: t.symbol,
    entry,
    stop,
    target,
    riskReward: rr,
    simulatedSize,
    maxDollarRisk: actualRisk,
    marketData: data,
    temporalScore: data.temporalScore,
    liquidationPrice,
  };
  if ((genome.trade_direction ?? 1) < 0) proposal = mirrorProposalGeometry(proposal, leverage);
  return proposal;
}

// ──────────────────────────────────────────────
// Agent 5: YUZU — Small-Win Agent (with temporal bias + Bayesian)
// ──────────────────────────────────────────────

function yuzuAgent(data: MarketData, bayes: BayesianState, maxDollarRisk: number, paperBalance: number, leverage: number, genome: Genome): TradeProposal | null {
  const t = data.ticker;
  const price = t.lastPrice;

  let trendDirection: "UP" | "DOWN" | "SIDEWAYS" = "SIDEWAYS";
  if (data.sma20 > data.sma50 * (1 + genome.trend_threshold)) trendDirection = "UP";
  else if (data.sma20 < data.sma50 * (1 - genome.trend_threshold)) trendDirection = "DOWN";

  if (trendDirection === "SIDEWAYS") return null;

  if (!bayes.shouldTrade) return null;

  const temporalBoost = data.temporalScore;
  if (temporalBoost < -0.2) return null;

  let entry: number, stop: number, target: number;

  if (trendDirection === "UP") {
    entry = price;
    stop = data.klines[data.klines.length - 1].low * genome.long_stop_low_mult;
    const risk = entry - stop;
    if (risk <= 0) return null;
    const rrMultiplier = 1 + (bayes.winProbability - 0.5) * 0.2;
    target = entry + risk * Math.max(1.5, genome.long_target_rr * rrMultiplier);
  } else {
    if (data.rsi > genome.short_rsi_max) return null;
    entry = price;
    stop = price * genome.short_stop_pct;
    const risk = stop - entry;
    if (risk <= 0) return null;
    const rrMultiplier = 1 + (bayes.winProbability - 0.5) * 0.2;
    target = entry - risk * Math.max(1.2, genome.short_target_rr * rrMultiplier);
  }

  const { stop: _clampedStop, liquidationPrice } = clampStopToLiquidation(entry, stop, leverage);
  stop = _clampedStop;

  const risk = Math.abs(entry - stop);
  const reward = Math.abs(target - entry);
  const rr = risk > 0 ? reward / risk : 0;

  const minRR = bayes.edgeConfidence > 50
    ? Math.max(1.3, genome.min_rr - (bayes.winProbability - 0.5) * 0.3)
    : genome.min_rr;

  if (rr < minRR) return null;

  if (paperBalance <= 0 || maxDollarRisk <= 0) return null;
  const maxNotional = paperBalance * leverage;
  const rawSize = (maxDollarRisk / risk) * entry;
  const simulatedSize = Math.min(rawSize, maxNotional);
  const actualRisk = simulatedSize * (risk / entry);

  let proposal: TradeProposal = {
    agentId: "YUZU",
    symbol: t.symbol,
    entry,
    stop,
    target,
    riskReward: rr,
    simulatedSize,
    maxDollarRisk: actualRisk,
    marketData: data,
    temporalScore: data.temporalScore,
    liquidationPrice,
  };
  if ((genome.trade_direction ?? 1) < 0) proposal = mirrorProposalGeometry(proposal, leverage);
  return proposal;
}

// ──────────────────────────────────────────────
// Matty helpers — Bollinger Bands, EMA, RSI divergence, order blocks
// ──────────────────────────────────────────────

function calcEMA(klines: Kline[], period: number, endIndex: number): number {
  if (endIndex < period) return klines[endIndex]?.close ?? 0;
  const k = 2 / (period + 1);
  let ema = klines[endIndex - period + 1].close;
  for (let i = endIndex - period + 2; i <= endIndex; i++) {
    ema = klines[i].close * k + ema * (1 - k);
  }
  return ema;
}

function calcBollingerBands(klines: Kline[], period: number, endIndex: number, stdDev: number = 2): { upper: number; mid: number; lower: number } {
  if (endIndex < period - 1) {
    const c = klines[endIndex]?.close ?? 0;
    return { upper: c, mid: c, lower: c };
  }
  let sum = 0;
  for (let i = endIndex - period + 1; i <= endIndex; i++) sum += klines[i].close;
  const mid = sum / period;
  let variance = 0;
  for (let i = endIndex - period + 1; i <= endIndex; i++) variance += (klines[i].close - mid) ** 2;
  const sd = Math.sqrt(variance / period);
  return { upper: mid + stdDev * sd, mid, lower: mid - stdDev * sd };
}

// ──────────────────────────────────────────────
// Agent 6: MATTY — Chart Pattern Reversal Bot
// Detects double tops, double bottoms, head & shoulders,
// and inverse head & shoulders on 5m candles. Enters on
// neckline breakout confirmation. Stop goes beyond the
// pattern extreme; target projects the pattern height.
// ──────────────────────────────────────────────

function findSwingsLive(klines: Kline[], lookback: number): { highs: { idx: number; price: number }[]; lows: { idx: number; price: number }[] } {
  const highs: { idx: number; price: number }[] = [];
  const lows: { idx: number; price: number }[] = [];
  const end = klines.length - 1;
  const start = Math.max(0, end - lookback);
  for (let j = start + 2; j <= end - 2; j++) {
    if (
      klines[j].high > klines[j - 1].high && klines[j].high > klines[j + 1].high &&
      klines[j].high >= klines[j - 2].high && klines[j].high >= klines[j + 2].high
    ) {
      highs.push({ idx: j, price: klines[j].high });
    }
    if (
      klines[j].low < klines[j - 1].low && klines[j].low < klines[j + 1].low &&
      klines[j].low <= klines[j - 2].low && klines[j].low <= klines[j + 2].low
    ) {
      lows.push({ idx: j, price: klines[j].low });
    }
  }
  // Also include the most recent candle as a potential swing if it's an extreme
  if (end >= start + 2) {
    if (klines[end].high >= klines[end - 1].high && klines[end].high >= klines[end - 2].high) {
      highs.push({ idx: end, price: klines[end].high });
    }
    if (klines[end].low <= klines[end - 1].low && klines[end].low <= klines[end - 2].low) {
      lows.push({ idx: end, price: klines[end].low });
    }
  }
  return { highs, lows };
}

async function mattyAgent(
  data: MarketData,
  bayes: BayesianState,
  maxDollarRisk: number,
  symbol: string,
  paperBalance: number,
  leverage: number,
  genome: Genome,
  category: string = "spot"
): Promise<TradeProposal | null> {
  if (!bayes.shouldTrade) return null;

  const klines5m = await fetchKlines(symbol, "5", 200, category);
  if (klines5m.length < 50) return null;

  const price = data.ticker.lastPrice;
  const rsi = calcRSI(klines5m, 14);
  const rsiPrev = calcRSI(klines5m.slice(0, klines5m.length - 3), 14);
  const bb = calcBollingerBands(klines5m, 20, klines5m.length - 1);
  const bbPrev = calcBollingerBands(klines5m, 20, klines5m.length - 6);
  const swings = findSwingsLive(klines5m, Math.round(genome.pattern_lookback));
  const ema20 = calcEMA(klines5m, 20, klines5m.length - 1);

  const patternTolerance = genome.pattern_tolerance / 100;
  const stopBufferPct = genome.stop_buffer_pct;
  const targetRR = genome.target_rr;
  const minRR = genome.min_rr;

  let direction: "LONG" | "SHORT" | null = null;
  let setupReason = "";
  let stopRef = price;
  const end = klines5m.length - 1;

  // ── Double Top (SHORT) ──
  if (swings.highs.length >= 2) {
    const h1 = swings.highs[swings.highs.length - 2];
    const h2 = swings.highs[swings.highs.length - 1];
    const peakDiff = Math.abs(h1.price - h2.price) / Math.max(h1.price, h2.price);
    const valleyLow = Math.min(...klines5m.slice(h1.idx, h2.idx).map(k => k.low));
    const neckline = valleyLow;

    if (peakDiff <= patternTolerance && end - h2.idx <= 30 && price < neckline && rsi < 60) {
      direction = "SHORT";
      stopRef = Math.max(h1.price, h2.price);
      setupReason = `Double Top SHORT | Peaks ${h1.price.toFixed(4)}/${h2.price.toFixed(4)} (${(peakDiff * 100).toFixed(1)}% diff) | Neckline ${neckline.toFixed(4)} | RSI ${rsi.toFixed(0)}`;
    }
  }

  // ── Double Bottom (LONG) ──
  if (!direction && swings.lows.length >= 2) {
    const l1 = swings.lows[swings.lows.length - 2];
    const l2 = swings.lows[swings.lows.length - 1];
    const lowDiff = Math.abs(l1.price - l2.price) / Math.min(l1.price, l2.price);
    const resistanceHigh = Math.max(...klines5m.slice(l1.idx, l2.idx).map(k => k.high));
    const neckline = resistanceHigh;

    if (lowDiff <= patternTolerance && end - l2.idx <= 30 && price > neckline && rsi > 40) {
      direction = "LONG";
      stopRef = Math.min(l1.price, l2.price);
      setupReason = `Double Bottom LONG | Troughs ${l1.price.toFixed(4)}/${l2.price.toFixed(4)} (${(lowDiff * 100).toFixed(1)}% diff) | Neckline ${neckline.toFixed(4)} | RSI ${rsi.toFixed(0)}`;
    }
  }

  // ── Head and Shoulders (SHORT) ──
  if (!direction && swings.highs.length >= 3) {
    const h1 = swings.highs[swings.highs.length - 3];
    const h2 = swings.highs[swings.highs.length - 2]; // head (highest)
    const h3 = swings.highs[swings.highs.length - 1];
    const isHS = h2.price > h1.price && h2.price > h3.price &&
      Math.abs(h1.price - h3.price) / Math.max(h1.price, h3.price) <= patternTolerance;

    if (isHS) {
      const valley1 = Math.min(...klines5m.slice(h1.idx, h2.idx).map(k => k.low));
      const valley2 = Math.min(...klines5m.slice(h2.idx, h3.idx).map(k => k.low));
      const neckline = Math.min(valley1, valley2);
      const patternHeight = h2.price - neckline;

      if (patternHeight > 0 && end - h3.idx <= 30 && price < neckline) {
        direction = "SHORT";
        stopRef = h2.price;
        setupReason = `Head & Shoulders SHORT | Head ${h2.price.toFixed(4)} | Shoulders ${h1.price.toFixed(4)}/${h3.price.toFixed(4)} | Neckline ${neckline.toFixed(4)} | RSI ${rsi.toFixed(0)}`;
      }
    }
  }

  // ── Inverse Head and Shoulders (LONG) ──
  if (!direction && swings.lows.length >= 3) {
    const l1 = swings.lows[swings.lows.length - 3];
    const l2 = swings.lows[swings.lows.length - 2]; // head (lowest)
    const l3 = swings.lows[swings.lows.length - 1];
    const isInvHS = l2.price < l1.price && l2.price < l3.price &&
      Math.abs(l1.price - l3.price) / Math.min(l1.price, l3.price) <= patternTolerance;

    if (isInvHS) {
      const peak1 = Math.max(...klines5m.slice(l1.idx, l2.idx).map(k => k.high));
      const peak2 = Math.max(...klines5m.slice(l2.idx, l3.idx).map(k => k.high));
      const neckline = Math.min(peak1, peak2);
      const patternHeight = neckline - l2.price;

      if (patternHeight > 0 && end - l3.idx <= 30 && price > neckline) {
        direction = "LONG";
        stopRef = l2.price;
        setupReason = `Inverse H&S LONG | Head ${l2.price.toFixed(4)} | Shoulders ${l1.price.toFixed(4)}/${l3.price.toFixed(4)} | Neckline ${neckline.toFixed(4)} | RSI ${rsi.toFixed(0)}`;
      }
    }
  }

  // ── Bollinger Band Squeeze Breakout (LONG) ──
  // Bands were tight (squeeze), now price breaks above upper band with volume
  if (!direction) {
    const bandWidth = (bb.upper - bb.lower) / bb.mid;
    const prevBandWidth = (bbPrev.upper - bbPrev.lower) / bbPrev.mid;
    const squeeze = prevBandWidth < 0.04;
    const breakoutUp = squeeze && price > bb.upper && rsi > 50 && rsi < 75;
    const breakoutDown = squeeze && price < bb.lower && rsi < 50 && rsi > 25;

    if (breakoutUp) {
      direction = "LONG";
      stopRef = bb.mid;
      setupReason = `BB Squeeze Breakout LONG | BandWidth ${bandWidth.toFixed(4)} | PrevWidth ${prevBandWidth.toFixed(4)} | RSI ${rsi.toFixed(0)}`;
    } else if (breakoutDown) {
      direction = "SHORT";
      stopRef = bb.mid;
      setupReason = `BB Squeeze Breakout SHORT | BandWidth ${bandWidth.toFixed(4)} | PrevWidth ${prevBandWidth.toFixed(4)} | RSI ${rsi.toFixed(0)}`;
    }
  }

  // ── RSI Divergence (LONG) ──
  // Price makes lower low but RSI makes higher low → bullish divergence
  if (!direction && swings.lows.length >= 2) {
    const l1 = swings.lows[swings.lows.length - 2];
    const l2 = swings.lows[swings.lows.length - 1];
    const rsiAtL1 = calcRSI(klines5m.slice(0, l1.idx + 1), 14);
    const rsiAtL2 = calcRSI(klines5m.slice(0, l2.idx + 1), 14);
    const priceLowerLow = l2.price < l1.price;
    const rsiHigherLow = rsiAtL2 > rsiAtL1;
    const recentEnough = end - l2.idx <= 15;

    if (priceLowerLow && rsiHigherLow && recentEnough && rsi < 45 && price > ema20) {
      direction = "LONG";
      stopRef = l2.price;
      setupReason = `RSI Divergence LONG | Price LL ${l1.price.toFixed(4)}/${l2.price.toFixed(4)} | RSI HL ${rsiAtL1.toFixed(0)}/${rsiAtL2.toFixed(0)} | RSI ${rsi.toFixed(0)}`;
    }
  }

  // ── RSI Divergence (SHORT) ──
  // Price makes higher high but RSI makes lower high → bearish divergence
  if (!direction && swings.highs.length >= 2) {
    const h1 = swings.highs[swings.highs.length - 2];
    const h2 = swings.highs[swings.highs.length - 1];
    const rsiAtH1 = calcRSI(klines5m.slice(0, h1.idx + 1), 14);
    const rsiAtH2 = calcRSI(klines5m.slice(0, h2.idx + 1), 14);
    const priceHigherHigh = h2.price > h1.price;
    const rsiLowerHigh = rsiAtH2 < rsiAtH1;
    const recentEnough = end - h2.idx <= 15;

    if (priceHigherHigh && rsiLowerHigh && recentEnough && rsi > 55 && price < ema20) {
      direction = "SHORT";
      stopRef = h2.price;
      setupReason = `RSI Divergence SHORT | Price HH ${h1.price.toFixed(4)}/${h2.price.toFixed(4)} | RSI LH ${rsiAtH1.toFixed(0)}/${rsiAtH2.toFixed(0)} | RSI ${rsi.toFixed(0)}`;
    }
  }

  // ── BB Reversion (LONG) ──
  // Price pierces lower band then closes back inside — mean reversion
  if (!direction) {
    const recentCandles = klines5m.slice(-3);
    const piercedLower = recentCandles.some(k => k.low < bb.lower);
    const closedInside = klines5m[end].close > bb.lower;
    const rsiOversold = rsi < 35;

    if (piercedLower && closedInside && rsiOversold) {
      direction = "LONG";
      stopRef = Math.min(...recentCandles.map(k => k.low));
      setupReason = `BB Reversion LONG | RSI ${rsi.toFixed(0)} | Lower band ${bb.lower.toFixed(4)}`;
    }

    const piercedUpper = recentCandles.some(k => k.high > bb.upper);
    const closedInsideUp = klines5m[end].close < bb.upper;
    const rsiOverbought = rsi > 65;

    if (!direction && piercedUpper && closedInsideUp && rsiOverbought) {
      direction = "SHORT";
      stopRef = Math.max(...recentCandles.map(k => k.high));
      setupReason = `BB Reversion SHORT | RSI ${rsi.toFixed(0)} | Upper band ${bb.upper.toFixed(4)}`;
    }
  }

  if (!direction) return null;

  const entry = price;
  let stop = direction === "LONG"
    ? stopRef - (stopRef * stopBufferPct / 100)
    : stopRef + (stopRef * stopBufferPct / 100);
  const { stop: _clampedStop, liquidationPrice } = clampStopToLiquidation(entry, stop, leverage);
  stop = _clampedStop;

  const risk = Math.abs(entry - stop);
  if (risk <= 0) return null;

  let target: number;
  if (direction === "LONG") {
    const patternTarget = entry + risk * targetRR;
    target = Math.min(patternTarget, bb.mid * 1.01);
    if (target <= entry) target = patternTarget;
  } else {
    const patternTarget = entry - risk * targetRR;
    target = Math.max(patternTarget, bb.mid * 0.99);
    if (target >= entry) target = patternTarget;
  }

  const reward = Math.abs(target - entry);
  const rr = risk > 0 ? reward / risk : 0;
  if (rr < minRR) return null;

  if (paperBalance <= 0 || maxDollarRisk <= 0) return null;
  const maxNotional = paperBalance * leverage;
  const rawSize = (maxDollarRisk / risk) * entry;
  const simulatedSize = Math.min(rawSize, maxNotional);
  const actualRisk = simulatedSize * (risk / entry);

  let proposal: TradeProposal & { direction?: "LONG" | "SHORT" } = {
    agentId: "MATTY",
    symbol,
    entry,
    stop,
    target,
    riskReward: rr,
    simulatedSize,
    maxDollarRisk: actualRisk,
    marketData: data,
    temporalScore: data.temporalScore,
    direction,
    liquidationPrice,
  };
  if ((genome.trade_direction ?? 1) < 0) proposal = mirrorProposalGeometry(proposal, leverage);
  return proposal;
}

// ──────────────────────────────────────────────
// Agent 7: REKT — Volatile Coin Chaser
// Hunts high-volatility pump/dump coins with momentum breakouts.
// Enters when price has sufficient momentum + RSI in bullish/bearish range
// + trend confirmation. Wide stops, aggressive targets. Bypasses MOMO/RIN/SORA gates.
// ──────────────────────────────────────────────

async function rektAgent(
  data: MarketData,
  bayes: BayesianState,
  maxDollarRisk: number,
  symbol: string,
  paperBalance: number,
  leverage: number,
  genome: Genome
): Promise<TradeProposal | null> {
  if (!bayes.shouldTrade) return null;

  // REKT trades Bybit linear perps — use category=linear for klines
  const klines1m = await fetchKlines(symbol, "1", 100, "linear");
  if (klines1m.length < 30) return null;

  const price = data.ticker.lastPrice;
  const rsi = calcRSI(klines1m, 14);

  // Momentum: price change over last 5 candles as %
  const lookback = Math.min(5, klines1m.length - 1);
  const pastPrice = klines1m[klines1m.length - 1 - lookback].close;
  const momentumPct = pastPrice > 0 ? ((price - pastPrice) / pastPrice) * 100 : 0;

  // Trend: SMA(20) slope as %
  const sma20 = calcSMA(klines1m.slice(0, klines1m.length), 20);
  const sma20Prev = calcSMA(klines1m.slice(0, klines1m.length - 3), 20);
  const trendPct = sma20Prev > 0 ? ((sma20 - sma20Prev) / sma20Prev) * 100 : 0;

  const minMomentum = genome.min_momentum;
  const minRsiLong = genome.min_rsi_long;
  const maxRsiLong = genome.max_rsi_long;
  const minRsiShort = genome.min_rsi_short;
  const maxRsiShort = genome.max_rsi_short;
  const trendThreshold = genome.trend_threshold;

  let direction: "LONG" | "SHORT" | null = null;
  let setupReason = "";

  // LONG: bullish momentum + RSI in bullish range (not overbought) + uptrend
  if (
    momentumPct >= minMomentum &&
    rsi >= minRsiLong && rsi <= maxRsiLong &&
    trendPct >= trendThreshold
  ) {
    direction = "LONG";
    setupReason = `Momentum LONG | Move ${momentumPct.toFixed(2)}% over 5 bars | RSI ${rsi.toFixed(0)} | Trend ${trendPct.toFixed(3)}%`;
  }
  // SHORT: bearish momentum + RSI in bearish range (not oversold) + downtrend
  else if (
    -momentumPct >= minMomentum &&
    rsi >= minRsiShort && rsi <= maxRsiShort &&
    trendPct <= -trendThreshold
  ) {
    direction = "SHORT";
    setupReason = `Momentum SHORT | Move ${momentumPct.toFixed(2)}% over 5 bars | RSI ${rsi.toFixed(0)} | Trend ${trendPct.toFixed(3)}%`;
  }

  if (!direction) return null;

  // Wide momentum stop based on recent volatility (10-candle range)
  const recentCandles = klines1m.slice(-11, -1);
  const recentHigh = Math.max(...recentCandles.map(k => k.high));
  const recentLow = Math.min(...recentCandles.map(k => k.low));
  const candleRangePct = price > 0 ? ((recentHigh - recentLow) / price) * 100 : 0;
  const stopPct = Math.min(genome.max_stop_pct, Math.max(genome.min_stop_pct, candleRangePct * 0.9));

  let entry: number, stop: number, target: number;

  if (direction === "LONG") {
    entry = price;
    stop = price * (1 - stopPct / 100);
    const risk = entry - stop;
    if (risk <= 0) return null;
    target = entry + risk * genome.target_rr;
  } else {
    entry = price;
    stop = price * (1 + stopPct / 100);
    const risk = stop - entry;
    if (risk <= 0) return null;
    target = entry - risk * genome.target_rr;
  }

  const { stop: _clampedStop, liquidationPrice } = clampStopToLiquidation(entry, stop, leverage);
  stop = _clampedStop;

  const risk = Math.abs(entry - stop);
  const reward = Math.abs(target - entry);
  const rr = risk > 0 ? reward / risk : 0;
  if (rr < genome.min_rr) return null;

  if (paperBalance <= 0 || maxDollarRisk <= 0) return null;
  const maxNotional = paperBalance * leverage;
  const rawSize = (maxDollarRisk / risk) * entry;
  const simulatedSize = Math.min(rawSize, maxNotional);
  const actualRisk = simulatedSize * (risk / entry);

  let proposal: TradeProposal & { direction?: "LONG" | "SHORT" } = {
    agentId: "REKT",
    symbol,
    entry,
    stop,
    target,
    riskReward: rr,
    simulatedSize,
    maxDollarRisk: actualRisk,
    marketData: data,
    temporalScore: data.temporalScore,
    direction,
    liquidationPrice,
  };
  if ((genome.trade_direction ?? 1) < 0) proposal = mirrorProposalGeometry(proposal, leverage);
  return proposal;
}

// ──────────────────────────────────────────────
// Agent 8: APEX — Autonomous Alpha Hunter
// Mission: turn $50 into $5K by month-end.
// Cycles through 8 technical strategies, learns which ones win,
// and allocates more capital to winning strategies over time.
// All profits are reinvested (compounding).
// ──────────────────────────────────────────────

interface ApexStrategyResult {
  direction: "LONG" | "SHORT";
  strategy: string;
  entry: number;
  stop: number;
  target: number;
  confidence: number;
  reason: string;
}

// ── Strategy 1: MACD Crossover ──
function apexMACD(klines: Kline[]): ApexStrategyResult | null {
  if (klines.length < 35) return null;
  const ema12 = calcEMA(klines, 12, klines.length - 1);
  const ema26 = calcEMA(klines, 26, klines.length - 1);
  const ema12Prev = calcEMA(klines, 12, klines.length - 2);
  const ema26Prev = calcEMA(klines, 26, klines.length - 2);
  const macd = ema12 - ema26;
  const macdPrev = ema12Prev - ema26Prev;
  const signal = calcEMA(klines.slice(0, klines.length - 1).map((k, i) => ({ ...k, close: Math.abs(calcEMA(klines.slice(0, i + 1), 12, i) - calcEMA(klines.slice(0, i + 1), 26, i)) })), 9, klines.length - 2);
  const price = klines[klines.length - 1].close;

  const atr = calcATR(klines, 14);
  if (atr <= 0) return null;

  // Bullish crossover: MACD crosses above signal
  if (macdPrev <= 0 && macd > 0) {
    const stop = price - atr * 1.5;
    const risk = price - stop;
    if (risk <= 0) return null;
    return { direction: "LONG", strategy: "MACD_CROSSOVER", entry: price, stop, target: price + risk * 2, confidence: 1.5, reason: `MACD bullish crossover (MACD ${macd.toFixed(6)} > 0, ATR stop ${atr.toFixed(4)})` };
  }
  // Bearish crossover
  if (macdPrev >= 0 && macd < 0) {
    const stop = price + atr * 1.5;
    const risk = stop - price;
    if (risk <= 0) return null;
    return { direction: "SHORT", strategy: "MACD_CROSSOVER", entry: price, stop, target: price - risk * 2, confidence: 1.5, reason: `MACD bearish crossover (MACD ${macd.toFixed(6)} < 0, ATR stop ${atr.toFixed(4)})` };
  }
  return null;
}

// ── Strategy 2: Bollinger Band Reversion ──
function apexBollinger(klines: Kline[]): ApexStrategyResult | null {
  if (klines.length < 25) return null;
  const end = klines.length - 1;
  const bb = calcBollingerBands(klines, 20, end, 2);
  const price = klines[end].close;
  const rsi = calcRSI(klines, 14);

  const atr = calcATR(klines, 14);
  if (atr <= 0) return null;

  // Price below lower band + oversold → LONG
  if (price < bb.lower && rsi < 30) {
    const stop = Math.min(bb.lower, price - atr * 1.0);
    const risk = price - stop;
    if (risk <= 0) return null;
    return { direction: "LONG", strategy: "BOLLINGER_REVERSION", entry: price, stop, target: bb.mid, confidence: 1.2, reason: `BB reversion LONG (price ${price.toFixed(4)} < lower ${bb.lower.toFixed(4)}, RSI ${rsi.toFixed(0)}, ATR ${atr.toFixed(4)})` };
  }
  // Price above upper band + overbought → SHORT
  if (price > bb.upper && rsi > 70) {
    const stop = Math.max(bb.upper, price + atr * 1.0);
    const risk = stop - price;
    if (risk <= 0) return null;
    return { direction: "SHORT", strategy: "BOLLINGER_REVERSION", entry: price, stop, target: bb.mid, confidence: 1.2, reason: `BB reversion SHORT (price ${price.toFixed(4)} > upper ${bb.upper.toFixed(4)}, RSI ${rsi.toFixed(0)}, ATR ${atr.toFixed(4)})` };
  }
  return null;
}

// ── Strategy 3: EMA Crossover ──
function apexEMACross(klines: Kline[]): ApexStrategyResult | null {
  if (klines.length < 55) return null;
  const end = klines.length - 1;
  const ema9 = calcEMA(klines, 9, end);
  const ema21 = calcEMA(klines, 21, end);
  const ema9Prev = calcEMA(klines, 9, end - 1);
  const ema21Prev = calcEMA(klines, 21, end - 1);
  const price = klines[end].close;

  const atr = calcATR(klines, 14);
  if (atr <= 0) return null;

  // Bullish: EMA9 crosses above EMA21
  if (ema9Prev <= ema21Prev && ema9 > ema21) {
    const stop = Math.min(ema21, price - atr * 1.2);
    const risk = price - stop;
    if (risk <= 0) return null;
    return { direction: "LONG", strategy: "EMA_CROSSOVER", entry: price, stop, target: price + risk * 2.5, confidence: 1.3, reason: `EMA9/21 bullish cross (9: ${ema9.toFixed(4)} > 21: ${ema21.toFixed(4)}, ATR ${atr.toFixed(4)})` };
  }
  // Bearish: EMA9 crosses below EMA21
  if (ema9Prev >= ema21Prev && ema9 < ema21) {
    const stop = Math.max(ema21, price + atr * 1.2);
    const risk = stop - price;
    if (risk <= 0) return null;
    return { direction: "SHORT", strategy: "EMA_CROSSOVER", entry: price, stop, target: price - risk * 2.5, confidence: 1.3, reason: `EMA9/21 bearish cross (9: ${ema9.toFixed(4)} < 21: ${ema21.toFixed(4)}, ATR ${atr.toFixed(4)})` };
  }
  return null;
}

// ── Strategy 4: Stochastic Reversal ──
function apexStochastic(klines: Kline[]): ApexStrategyResult | null {
  if (klines.length < 20) return null;
  const end = klines.length - 1;
  const period = 14;
  let highestHigh = -Infinity, lowestLow = Infinity;
  for (let i = end - period + 1; i <= end; i++) {
    if (klines[i].high > highestHigh) highestHigh = klines[i].high;
    if (klines[i].low < lowestLow) lowestLow = klines[i].low;
  }
  const range = highestHigh - lowestLow;
  if (range <= 0) return null;
  const k = ((klines[end].close - lowestLow) / range) * 100;
  // Previous K
  let prevHH = -Infinity, prevLL = Infinity;
  for (let i = end - period; i < end; i++) {
    if (klines[i].high > prevHH) prevHH = klines[i].high;
    if (klines[i].low < prevLL) prevLL = klines[i].low;
  }
  const prevRange = prevHH - prevLL;
  const kPrev = prevRange > 0 ? ((klines[end - 1].close - prevLL) / prevRange) * 100 : 50;
  const price = klines[end].close;

  const atr = calcATR(klines, 14);
  if (atr <= 0) return null;

  // Oversold reversal: K crosses above 20
  if (kPrev < 20 && k > 20) {
    const stop = Math.min(lowestLow, price - atr * 1.0);
    const risk = price - stop;
    if (risk <= 0) return null;
    return { direction: "LONG", strategy: "STOCHASTIC_REVERSAL", entry: price, stop, target: price + risk * 2, confidence: 1.1, reason: `Stoch oversold reversal (K ${kPrev.toFixed(0)}→${k.toFixed(0)}, ATR ${atr.toFixed(4)})` };
  }
  // Overbought reversal: K crosses below 80
  if (kPrev > 80 && k < 80) {
    const stop = Math.max(highestHigh, price + atr * 1.0);
    const risk = stop - price;
    if (risk <= 0) return null;
    return { direction: "SHORT", strategy: "STOCHASTIC_REVERSAL", entry: price, stop, target: price - risk * 2, confidence: 1.1, reason: `Stoch overbought reversal (K ${kPrev.toFixed(0)}→${k.toFixed(0)}, ATR ${atr.toFixed(4)})` };
  }
  return null;
}

// ── Strategy 5: ADX Trend Rider ──
function apexADX(klines: Kline[]): ApexStrategyResult | null {
  if (klines.length < 30) return null;
  const end = klines.length - 1;
  // Simplified ADX: measure directional movement strength
  let plusDM = 0, minusDM = 0, trSum = 0;
  const period = 14;
  for (let i = end - period + 1; i <= end; i++) {
    const upMove = klines[i].high - klines[i - 1].high;
    const downMove = klines[i - 1].low - klines[i].low;
    if (upMove > downMove && upMove > 0) plusDM += upMove;
    if (downMove > upMove && downMove > 0) minusDM += downMove;
    const tr = Math.max(
      klines[i].high - klines[i].low,
      Math.abs(klines[i].high - klines[i - 1].close),
      Math.abs(klines[i].low - klines[i - 1].close)
    );
    trSum += tr;
  }
  if (trSum <= 0) return null;
  const plusDI = (plusDM / trSum) * 100;
  const minusDI = (minusDM / trSum) * 100;
  const dx = Math.abs(plusDI - minusDI) / (plusDI + minusDI) * 100;
  const price = klines[end].close;
  const atr = trSum / period; // ATR is essentially avg TR
  if (atr <= 0) return null;

  // Strong trend (DX > 25) + +DI > -DI → ride the trend LONG
  if (dx > 25 && plusDI > minusDI) {
    const stop = price - atr * 2.0;
    const risk = price - stop;
    if (risk <= 0) return null;
    return { direction: "LONG", strategy: "ADX_TREND_RIDER", entry: price, stop, target: price + risk * 2.5, confidence: 1.4, reason: `ADX trend LONG (DX ${dx.toFixed(0)}, +DI ${plusDI.toFixed(0)} > -DI ${minusDI.toFixed(0)}, ATR ${atr.toFixed(4)})` };
  }
  if (dx > 25 && minusDI > plusDI) {
    const stop = price + atr * 2.0;
    const risk = stop - price;
    if (risk <= 0) return null;
    return { direction: "SHORT", strategy: "ADX_TREND_RIDER", entry: price, stop, target: price - risk * 2.5, confidence: 1.4, reason: `ADX trend SHORT (DX ${dx.toFixed(0)}, -DI ${minusDI.toFixed(0)} > +DI ${plusDI.toFixed(0)}, ATR ${atr.toFixed(4)})` };
  }
  return null;
}

// ── Strategy 6: RSI Divergence ──
function apexRSIDivergence(klines: Kline[]): ApexStrategyResult | null {
  if (klines.length < 40) return null;
  const end = klines.length - 1;
  const swings = findSwingsLive(klines, 30);
  const price = klines[end].close;
  const atr = calcATR(klines, 14);
  if (atr <= 0) return null;

  // Bullish divergence: price lower low, RSI higher low
  if (swings.lows.length >= 2) {
    const l1 = swings.lows[swings.lows.length - 2];
    const l2 = swings.lows[swings.lows.length - 1];
    if (end - l2.idx <= 10 && l2.price < l1.price) {
      const rsi1 = calcRSI(klines.slice(0, l1.idx + 1), 14);
      const rsi2 = calcRSI(klines.slice(0, l2.idx + 1), 14);
      if (rsi2 > rsi1 && rsi2 < 45) {
        const stop = Math.min(l2.price, price - atr * 1.0);
        const risk = price - stop;
        if (risk <= 0) return null;
        return { direction: "LONG", strategy: "RSI_DIVERGENCE", entry: price, stop, target: price + risk * 2.5, confidence: 1.6, reason: `RSI bullish divergence (price LL, RSI HL ${rsi1.toFixed(0)}→${rsi2.toFixed(0)}, ATR ${atr.toFixed(4)})` };
      }
    }
  }
  // Bearish divergence: price higher high, RSI lower high
  if (swings.highs.length >= 2) {
    const h1 = swings.highs[swings.highs.length - 2];
    const h2 = swings.highs[swings.highs.length - 1];
    if (end - h2.idx <= 10 && h2.price > h1.price) {
      const rsi1 = calcRSI(klines.slice(0, h1.idx + 1), 14);
      const rsi2 = calcRSI(klines.slice(0, h2.idx + 1), 14);
      if (rsi2 < rsi1 && rsi2 > 55) {
        const stop = Math.max(h2.price, price + atr * 1.0);
        const risk = stop - price;
        if (risk <= 0) return null;
        return { direction: "SHORT", strategy: "RSI_DIVERGENCE", entry: price, stop, target: price - risk * 2.5, confidence: 1.6, reason: `RSI bearish divergence (price HH, RSI LH ${rsi1.toFixed(0)}→${rsi2.toFixed(0)}, ATR ${atr.toFixed(4)})` };
      }
    }
  }
  return null;
}

// ── Strategy 7: Momentum Breakout ──
function apexMomentumBreakout(klines: Kline[]): ApexStrategyResult | null {
  if (klines.length < 30) return null;
  const end = klines.length - 1;
  const lookback = 20;
  const recentHigh = Math.max(...klines.slice(end - lookback, end).map(k => k.high));
  const recentLow = Math.min(...klines.slice(end - lookback, end).map(k => k.low));
  const price = klines[end].close;
  const volume = klines[end].volume;
  const avgVol = klines.slice(end - 10, end).reduce((a, b) => a + b.volume, 0) / 10;
  const volSpike = volume > avgVol * 1.5;

  const atr = calcATR(klines, 14);
  if (atr <= 0) return null;

  // Breakout above recent high with volume
  if (price > recentHigh && volSpike) {
    const stop = recentHigh - atr * 0.5;
    const risk = price - stop;
    if (risk <= 0) return null;
    return { direction: "LONG", strategy: "MOMENTUM_BREAKOUT", entry: price, stop, target: price + risk * 2, confidence: 1.3, reason: `Momentum breakout LONG (price ${price.toFixed(4)} > high ${recentHigh.toFixed(4)}, vol spike, ATR ${atr.toFixed(4)})` };
  }
  // Breakdown below recent low with volume
  if (price < recentLow && volSpike) {
    const stop = recentLow + atr * 0.5;
    const risk = stop - price;
    if (risk <= 0) return null;
    return { direction: "SHORT", strategy: "MOMENTUM_BREAKOUT", entry: price, stop, target: price - risk * 2, confidence: 1.3, reason: `Momentum breakdown SHORT (price ${price.toFixed(4)} < low ${recentLow.toFixed(4)}, vol spike, ATR ${atr.toFixed(4)})` };
  }
  return null;
}

// ── Strategy 8: VWAP Reversion ──
function apexVWAP(klines: Kline[]): ApexStrategyResult | null {
  if (klines.length < 20) return null;
  const end = klines.length - 1;
  let pvSum = 0, volSum = 0;
  for (let i = end - 20; i <= end; i++) {
    const typical = (klines[i].high + klines[i].low + klines[i].close) / 3;
    pvSum += typical * klines[i].volume;
    volSum += klines[i].volume;
  }
  if (volSum <= 0) return null;
  const vwap = pvSum / volSum;
  const price = klines[end].close;
  const devPct = ((price - vwap) / vwap) * 100;
  const atr = calcATR(klines, 14);
  if (atr <= 0) return null;

  // Price far below VWAP → snap back LONG
  if (devPct < -1.5) {
    const stop = price - atr * 1.0;
    const risk = price - stop;
    if (risk <= 0) return null;
    return { direction: "LONG", strategy: "VWAP_REVERSION", entry: price, stop, target: vwap, confidence: 1.0, reason: `VWAP reversion LONG (price ${devPct.toFixed(2)}% below VWAP ${vwap.toFixed(4)}, ATR ${atr.toFixed(4)})` };
  }
  // Price far above VWAP → snap back SHORT
  if (devPct > 1.5) {
    const stop = price + atr * 1.0;
    const risk = stop - price;
    if (risk <= 0) return null;
    return { direction: "SHORT", strategy: "VWAP_REVERSION", entry: price, stop, target: vwap, confidence: 1.0, reason: `VWAP reversion SHORT (price ${devPct.toFixed(2)}% above VWAP ${vwap.toFixed(4)}, ATR ${atr.toFixed(4)})` };
  }
  return null;
}

// ── Strategies 9-13: Chart Pattern Library (shared with MATTY's detector) ──

function apexDoubleTop(klines: Kline[]): ApexStrategyResult | null {
  if (klines.length < 50) return null;
  const end = klines.length - 1;
  const swings = findSwingsLive(klines, 40);
  if (swings.highs.length < 2) return null;
  const h1 = swings.highs[swings.highs.length - 2];
  const h2 = swings.highs[swings.highs.length - 1];
  const peakDiff = Math.abs(h1.price - h2.price) / Math.max(h1.price, h2.price);
  if (peakDiff > 0.015 || end - h2.idx > 30) return null;
  const neckline = Math.min(...klines.slice(h1.idx, h2.idx).map(k => k.low));
  const price = klines[end].close;
  const rsi = calcRSI(klines, 14);
  if (price >= neckline || rsi >= 60) return null;
  const atr = calcATR(klines, 14);
  if (atr <= 0) return null;
  const stop = Math.max(h1.price, h2.price);
  const risk = stop - price;
  if (risk <= 0) return null;
  return { direction: "SHORT", strategy: "DOUBLE_TOP", entry: price, stop, target: price - risk * 2, confidence: 1.4, reason: `Double top SHORT (peaks ${(peakDiff * 100).toFixed(1)}% diff, neckline ${neckline.toFixed(4)}, RSI ${rsi.toFixed(0)})` };
}

function apexDoubleBottom(klines: Kline[]): ApexStrategyResult | null {
  if (klines.length < 50) return null;
  const end = klines.length - 1;
  const swings = findSwingsLive(klines, 40);
  if (swings.lows.length < 2) return null;
  const l1 = swings.lows[swings.lows.length - 2];
  const l2 = swings.lows[swings.lows.length - 1];
  const lowDiff = Math.abs(l1.price - l2.price) / Math.min(l1.price, l2.price);
  if (lowDiff > 0.015 || end - l2.idx > 30) return null;
  const neckline = Math.max(...klines.slice(l1.idx, l2.idx).map(k => k.high));
  const price = klines[end].close;
  const rsi = calcRSI(klines, 14);
  if (price <= neckline || rsi <= 40) return null;
  const atr = calcATR(klines, 14);
  if (atr <= 0) return null;
  const stop = Math.min(l1.price, l2.price);
  const risk = price - stop;
  if (risk <= 0) return null;
  return { direction: "LONG", strategy: "DOUBLE_BOTTOM", entry: price, stop, target: price + risk * 2, confidence: 1.4, reason: `Double bottom LONG (troughs ${(lowDiff * 100).toFixed(1)}% diff, neckline ${neckline.toFixed(4)}, RSI ${rsi.toFixed(0)})` };
}

function apexHeadShoulders(klines: Kline[]): ApexStrategyResult | null {
  if (klines.length < 50) return null;
  const end = klines.length - 1;
  const swings = findSwingsLive(klines, 40);
  if (swings.highs.length < 3) return null;
  const h1 = swings.highs[swings.highs.length - 3];
  const h2 = swings.highs[swings.highs.length - 2];
  const h3 = swings.highs[swings.highs.length - 1];
  const isHS = h2.price > h1.price && h2.price > h3.price &&
    Math.abs(h1.price - h3.price) / Math.max(h1.price, h3.price) <= 0.015;
  if (!isHS || end - h3.idx > 30) return null;
  const valley1 = Math.min(...klines.slice(h1.idx, h2.idx).map(k => k.low));
  const valley2 = Math.min(...klines.slice(h2.idx, h3.idx).map(k => k.low));
  const neckline = Math.min(valley1, valley2);
  const price = klines[end].close;
  if (price >= neckline) return null;
  const atr = calcATR(klines, 14);
  if (atr <= 0) return null;
  const risk = h2.price - price;
  if (risk <= 0) return null;
  return { direction: "SHORT", strategy: "HEAD_SHOULDERS", entry: price, stop: h2.price, target: price - risk * 2, confidence: 1.4, reason: `H&S SHORT (head ${h2.price.toFixed(4)}, neckline ${neckline.toFixed(4)})` };
}

function apexInverseHeadShoulders(klines: Kline[]): ApexStrategyResult | null {
  if (klines.length < 50) return null;
  const end = klines.length - 1;
  const swings = findSwingsLive(klines, 40);
  if (swings.lows.length < 3) return null;
  const l1 = swings.lows[swings.lows.length - 3];
  const l2 = swings.lows[swings.lows.length - 2];
  const l3 = swings.lows[swings.lows.length - 1];
  const isInvHS = l2.price < l1.price && l2.price < l3.price &&
    Math.abs(l1.price - l3.price) / Math.min(l1.price, l3.price) <= 0.015;
  if (!isInvHS || end - l3.idx > 30) return null;
  const peak1 = Math.max(...klines.slice(l1.idx, l2.idx).map(k => k.high));
  const peak2 = Math.max(...klines.slice(l2.idx, l3.idx).map(k => k.high));
  const neckline = Math.min(peak1, peak2);
  const price = klines[end].close;
  if (price <= neckline) return null;
  const atr = calcATR(klines, 14);
  if (atr <= 0) return null;
  const risk = price - l2.price;
  if (risk <= 0) return null;
  return { direction: "LONG", strategy: "INVERSE_HEAD_SHOULDERS", entry: price, stop: l2.price, target: price + risk * 2, confidence: 1.4, reason: `Inverse H&S LONG (head ${l2.price.toFixed(4)}, neckline ${neckline.toFixed(4)})` };
}

function apexBBSqueeze(klines: Kline[]): ApexStrategyResult | null {
  if (klines.length < 30) return null;
  const end = klines.length - 1;
  const bb = calcBollingerBands(klines, 20, end, 2);
  const bbPrev = calcBollingerBands(klines, 20, end - 6, 2);
  const price = klines[end].close;
  const rsi = calcRSI(klines, 14);
  const atr = calcATR(klines, 14);
  if (atr <= 0) return null;
  const width = (bb.upper - bb.lower) / bb.mid;
  const prevWidth = (bbPrev.upper - bbPrev.lower) / bbPrev.mid;
  if (prevWidth >= 0.04) return null;
  if (price > bb.upper && rsi > 50 && rsi < 75) {
    const risk = price - bb.mid;
    if (risk <= 0) return null;
    return { direction: "LONG", strategy: "BB_SQUEEZE_BREAKOUT", entry: price, stop: bb.mid, target: price + risk * 2, confidence: 1.3, reason: `BB squeeze breakout LONG (width ${width.toFixed(3)}, RSI ${rsi.toFixed(0)})` };
  }
  if (price < bb.lower && rsi < 50 && rsi > 25) {
    const risk = bb.mid - price;
    if (risk <= 0) return null;
    return { direction: "SHORT", strategy: "BB_SQUEEZE_BREAKOUT", entry: price, stop: bb.mid, target: price - risk * 2, confidence: 1.3, reason: `BB squeeze breakdown SHORT (width ${width.toFixed(3)}, RSI ${rsi.toFixed(0)})` };
  }
  return null;
}

// ── Strategy registry + adaptive selection ──

// ── Candlestick patterns (14-19): entry triggers on 1m candles ──
// These read the LOWEST timeframe for precision entries. They're only
// allowed to fire in the direction of the 1h trend (see apexHTFTrend),
// so a bullish engulfing only buys into an uptrend, never against one.

function candleBody(k: Kline): number {
  return Math.abs(k.close - k.open);
}

function apexBullishEngulfing(klines: Kline[]): ApexStrategyResult | null {
  if (klines.length < 20) return null;
  const end = klines.length - 1;
  const prev = klines[end - 1];
  const cur = klines[end];
  const prevRed = prev.close < prev.open;
  const curGreen = cur.close > cur.open;
  if (!prevRed || !curGreen) return null;
  if (cur.open > prev.close || cur.close < prev.open) return null;
  if (candleBody(cur) < candleBody(prev) * 1.1) return null;
  const atr = calcATR(klines, 14);
  if (atr <= 0) return null;
  const price = cur.close;
  const stop = Math.min(prev.low, cur.low) - atr * 0.5;
  const risk = price - stop;
  if (risk <= 0) return null;
  return { direction: "LONG", strategy: "BULL_ENGULFING_1M", entry: price, stop, target: price + risk * 2, confidence: 1.2, reason: `Bullish engulfing 1m (body ${candleBody(cur).toFixed(6)} swallows prev)` };
}

function apexBearishEngulfing(klines: Kline[]): ApexStrategyResult | null {
  if (klines.length < 20) return null;
  const end = klines.length - 1;
  const prev = klines[end - 1];
  const cur = klines[end];
  const prevGreen = prev.close > prev.open;
  const curRed = cur.close < cur.open;
  if (!prevGreen || !curRed) return null;
  if (cur.open < prev.close || cur.close > prev.open) return null;
  if (candleBody(cur) < candleBody(prev) * 1.1) return null;
  const atr = calcATR(klines, 14);
  if (atr <= 0) return null;
  const price = cur.close;
  const stop = Math.max(prev.high, cur.high) + atr * 0.5;
  const risk = stop - price;
  if (risk <= 0) return null;
  return { direction: "SHORT", strategy: "BEAR_ENGULFING_1M", entry: price, stop, target: price - risk * 2, confidence: 1.2, reason: `Bearish engulfing 1m (body ${candleBody(cur).toFixed(6)} swallows prev)` };
}

function apexHammer(klines: Kline[]): ApexStrategyResult | null {
  if (klines.length < 20) return null;
  const end = klines.length - 1;
  const cur = klines[end];
  const body = candleBody(cur);
  const range = cur.high - cur.low;
  if (range <= 0 || body <= 0) return null;
  const lowerWick = Math.min(cur.open, cur.close) - cur.low;
  const upperWick = cur.high - Math.max(cur.open, cur.close);
  if (lowerWick < body * 2 || upperWick > body * 0.5) return null;
  // Must appear after a local decline
  const back = klines[end - 5].close;
  if (cur.close >= back) return null;
  const atr = calcATR(klines, 14);
  if (atr <= 0) return null;
  const price = cur.close;
  const stop = cur.low - atr * 0.5;
  const risk = price - stop;
  if (risk <= 0) return null;
  return { direction: "LONG", strategy: "HAMMER_1M", entry: price, stop, target: price + risk * 2, confidence: 1.1, reason: `Hammer 1m after decline (wick ${(lowerWick / body).toFixed(1)}x body)` };
}

function apexShootingStar(klines: Kline[]): ApexStrategyResult | null {
  if (klines.length < 20) return null;
  const end = klines.length - 1;
  const cur = klines[end];
  const body = candleBody(cur);
  const range = cur.high - cur.low;
  if (range <= 0 || body <= 0) return null;
  const lowerWick = Math.min(cur.open, cur.close) - cur.low;
  const upperWick = cur.high - Math.max(cur.open, cur.close);
  if (upperWick < body * 2 || lowerWick > body * 0.5) return null;
  // Must appear after a local rally
  const back = klines[end - 5].close;
  if (cur.close <= back) return null;
  const atr = calcATR(klines, 14);
  if (atr <= 0) return null;
  const price = cur.close;
  const stop = cur.high + atr * 0.5;
  const risk = stop - price;
  if (risk <= 0) return null;
  return { direction: "SHORT", strategy: "SHOOTING_STAR_1M", entry: price, stop, target: price - risk * 2, confidence: 1.1, reason: `Shooting star 1m after rally (wick ${(upperWick / body).toFixed(1)}x body)` };
}

function apexThreeWhiteSoldiers(klines: Kline[]): ApexStrategyResult | null {
  if (klines.length < 20) return null;
  const end = klines.length - 1;
  const c1 = klines[end - 2], c2 = klines[end - 1], c3 = klines[end];
  const allGreen = c1.close > c1.open && c2.close > c2.open && c3.close > c3.open;
  if (!allGreen) return null;
  if (!(c2.close > c1.close && c3.close > c2.close)) return null;
  for (const c of [c1, c2, c3]) {
    const range = c.high - c.low;
    if (range <= 0 || candleBody(c) < range * 0.5) return null;
  }
  const atr = calcATR(klines, 14);
  if (atr <= 0) return null;
  const price = c3.close;
  const stop = c1.open - atr * 0.5;
  const risk = price - stop;
  if (risk <= 0) return null;
  return { direction: "LONG", strategy: "THREE_SOLDIERS_1M", entry: price, stop, target: price + risk * 2, confidence: 1.5, reason: `Three white soldiers 1m (3 rising green candles)` };
}

function apexThreeBlackCrows(klines: Kline[]): ApexStrategyResult | null {
  if (klines.length < 20) return null;
  const end = klines.length - 1;
  const c1 = klines[end - 2], c2 = klines[end - 1], c3 = klines[end];
  const allRed = c1.close < c1.open && c2.close < c2.open && c3.close < c3.open;
  if (!allRed) return null;
  if (!(c2.close < c1.close && c3.close < c2.close)) return null;
  for (const c of [c1, c2, c3]) {
    const range = c.high - c.low;
    if (range <= 0 || candleBody(c) < range * 0.5) return null;
  }
  const atr = calcATR(klines, 14);
  if (atr <= 0) return null;
  const price = c3.close;
  const stop = c1.open + atr * 0.5;
  const risk = stop - price;
  if (risk <= 0) return null;
  return { direction: "SHORT", strategy: "THREE_CROWS_1M", entry: price, stop, target: price - risk * 2, confidence: 1.5, reason: `Three black crows 1m (3 falling red candles)` };
}

const CANDLE_PATTERNS: Array<{ name: string; fn: (k: Kline[]) => ApexStrategyResult | null }> = [
  { name: "BULL_ENGULFING_1M", fn: apexBullishEngulfing },
  { name: "BEAR_ENGULFING_1M", fn: apexBearishEngulfing },
  { name: "HAMMER_1M", fn: apexHammer },
  { name: "SHOOTING_STAR_1M", fn: apexShootingStar },
  { name: "THREE_SOLDIERS_1M", fn: apexThreeWhiteSoldiers },
  { name: "THREE_CROWS_1M", fn: apexThreeBlackCrows },
];

// Higher-timeframe trend: 1h candles, EMA9 vs EMA21.
// UP / DOWN gates which direction entries are allowed; SIDEWAYS lifts the gate.
function apexHTFTrend(h1: Kline[]): { dir: "UP" | "DOWN" | "SIDEWAYS"; ema9: number; ema21: number } {
  if (h1.length < 25) return { dir: "SIDEWAYS", ema9: 0, ema21: 0 };
  const end = h1.length - 1;
  const ema9 = calcEMA(h1, 9, end);
  const ema21 = calcEMA(h1, 21, end);
  const price = h1[end].close;
  if (ema9 > ema21 * 1.001 && price > ema21) return { dir: "UP", ema9, ema21 };
  if (ema9 < ema21 * 0.999 && price < ema21) return { dir: "DOWN", ema9, ema21 };
  return { dir: "SIDEWAYS", ema9, ema21 };
}

const APEX_STRATEGIES: Array<{ name: string; fn: (k: Kline[]) => ApexStrategyResult | null }> = [
  { name: "MACD_CROSSOVER", fn: apexMACD },
  { name: "BOLLINGER_REVERSION", fn: apexBollinger },
  { name: "EMA_CROSSOVER", fn: apexEMACross },
  { name: "STOCHASTIC_REVERSAL", fn: apexStochastic },
  { name: "ADX_TREND_RIDER", fn: apexADX },
  { name: "RSI_DIVERGENCE", fn: apexRSIDivergence },
  { name: "MOMENTUM_BREAKOUT", fn: apexMomentumBreakout },
  { name: "VWAP_REVERSION", fn: apexVWAP },
  { name: "DOUBLE_TOP", fn: apexDoubleTop },
  { name: "DOUBLE_BOTTOM", fn: apexDoubleBottom },
  { name: "HEAD_SHOULDERS", fn: apexHeadShoulders },
  { name: "INVERSE_HEAD_SHOULDERS", fn: apexInverseHeadShoulders },
  { name: "BB_SQUEEZE_BREAKOUT", fn: apexBBSqueeze },
];

interface StrategyStat {
  strategy: string;
  weight: number;
  enabled: boolean;
  cooldown_until: string | null;
  win_rate: number;
  total_trades: number;
  total_pnl: number;
  expectancy: number;
}

async function loadStrategyStats(): Promise<StrategyStat[]> {
  const { data } = await supabase
    .from("apex_strategy_stats")
    .select("strategy, weight, enabled, cooldown_until, win_rate, total_trades, total_pnl, expectancy")
    .eq("enabled", true);
  return (data as StrategyStat[]) || [];
}

async function updateStrategyStats(strategy: string, isWin: boolean, pnl: number): Promise<void> {
  const { data: existing } = await supabase
    .from("apex_strategy_stats")
    .select("*")
    .eq("strategy", strategy)
    .maybeSingle();

  // Brand-new strategy: auto-create its scorecard so every strategy APEX
  // deploys — existing or invented on the fly — is expectancy-scored from
  // its very first closed trade.
  if (!existing) {
    await supabase.from("apex_strategy_stats").upsert({
      strategy,
      total_trades: 1,
      wins: isWin ? 1 : 0,
      losses: isWin ? 0 : 1,
      total_pnl: pnl,
      avg_win: isWin ? pnl : 0,
      avg_loss: isWin ? 0 : Math.abs(pnl),
      win_rate: 100,
      bayesian_alpha: 2 + (isWin ? 1 : 0),
      bayesian_beta: 2 + (isWin ? 0 : 1),
      weight: 1.0,
      expectancy: isWin ? pnl : -Math.abs(pnl),
      enabled: true,
      last_used_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }, { onConflict: "strategy" });
    return;
  }

  const totalTrades = (existing.total_trades ?? 0) + 1;
  const wins = (existing.wins ?? 0) + (isWin ? 1 : 0);
  const losses = (existing.losses ?? 0) + (isWin ? 0 : 1);
  const totalPnl = (existing.total_pnl ?? 0) + pnl;
  const winRate = totalTrades > 0 ? (wins / totalTrades) * 100 : 0;
  const newAlpha = (existing.bayesian_alpha ?? 2) + (isWin ? 1 : 0);
  const newBeta = (existing.bayesian_beta ?? 2) + (isWin ? 0 : 1);
  const winProb = newAlpha / (newAlpha + newBeta);

  const prevWins = existing.wins ?? 0;
  const prevLosses = existing.losses ?? 0;
  const avgWin = wins > 0 ? ((existing.avg_win ?? 0) * prevWins + (isWin ? pnl : 0)) / wins : 0;
  const avgLoss = losses > 0 ? ((existing.avg_loss ?? 0) * prevLosses + (isWin ? 0 : Math.abs(pnl))) / losses : 0;
  const expectancy = (winRate / 100) * avgWin - (1 - winRate / 100) * avgLoss;

  // Adaptive weight: strategies with higher win probability get more weight
  // Weight = winProb * 2 (ranges from 0 to 2), floored at 0.3 so strategies don't fully die
  const weight = Math.max(0.3, winProb * 2);

  // Cooldown after 3 consecutive losses
  const consecLosses = isWin ? 0 : (existing.consecutive_losses ?? 0) + 1;
  const cooldownUntil = consecLosses >= 3 ? new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString() : null;
  const enabled = consecLosses >= 5 ? false : existing.enabled;

  await supabase.from("apex_strategy_stats").update({
    total_trades: totalTrades,
    wins,
    losses,
    total_pnl: totalPnl,
    win_rate: winRate,
    avg_win: avgWin,
    avg_loss: avgLoss,
    expectancy,
    bayesian_alpha: newAlpha,
    bayesian_beta: newBeta,
    weight,
    enabled,
    cooldown_until: cooldownUntil,
    updated_at: new Date().toISOString(),
  }).eq("strategy", strategy);
}

async function apexAgent(
  data: MarketData,
  bayes: BayesianState,
  maxDollarRisk: number,
  symbol: string,
  paperBalance: number,
  leverage: number,
  genome: Genome,
  category: "spot" | "linear",
  strategyStats: StrategyStat[]
): Promise<TradeProposal & { strategy: string } | null> {
  if (!bayes.shouldTrade) return null;

  const klines = category === "linear"
    ? await fetchKlines(symbol, "5", 100, "linear")
    : await fetchKlines(symbol, "5", 100, "spot");
  if (klines.length < 30) return null;

  // Multi-timeframe context: 1h sets the direction, 1m provides the entry
  // trigger for candle patterns, 5m runs the indicator/chart strategies.
  const h1Klines = await fetchKlines(symbol, "60", 60, category);
  const m1Klines = await fetchKlines(symbol, "1", 100, category);
  const trend = apexHTFTrend(h1Klines);

  // Run all strategies, collect signals
  const signals: ApexStrategyResult[] = [];
  const now = Date.now();
  for (const strat of APEX_STRATEGIES) {
    const stat = strategyStats.find(s => s.strategy === strat.name);
    if (stat && stat.cooldown_until && new Date(stat.cooldown_until).getTime() > now) continue;
    try {
      const result = strat.fn(klines);
      if (result) {
        // HTF gate: in a 1h uptrend only LONGs, in a downtrend only SHORTs.
        if (trend.dir === "UP" && result.direction === "SHORT") continue;
        if (trend.dir === "DOWN" && result.direction === "LONG") continue;
        // Weight confidence by strategy's historical performance
        const statWeight = stat?.weight ?? 1.0;
        result.confidence *= statWeight;
        signals.push(result);
      }
    } catch {
      // strategy error — skip
    }
  }

  // Candle patterns on 1m candles — need directional context, so they only
  // fire when the 1h trend agrees with the pattern's direction.
  if (m1Klines.length >= 20 && trend.dir !== "SIDEWAYS") {
    for (const pattern of CANDLE_PATTERNS) {
      const stat = strategyStats.find(s => s.strategy === pattern.name);
      if (stat && stat.cooldown_until && new Date(stat.cooldown_until).getTime() > now) continue;
      try {
        const result = pattern.fn(m1Klines);
        if (!result) continue;
        if (trend.dir === "UP" && result.direction === "SHORT") continue;
        if (trend.dir === "DOWN" && result.direction === "LONG") continue;
        const statWeight = stat?.weight ?? 1.0;
        result.confidence *= statWeight;
        signals.push(result);
      } catch {
        // pattern error — skip
      }
    }
  }

  if (signals.length === 0) return null;

  // Pick the highest-confidence signal
  signals.sort((a, b) => b.confidence - a.confidence);
  const best = signals[0];

  const entry = best.entry;
  let stop = best.stop;
  const target = best.target;
  const { stop: _clampedStop, liquidationPrice } = clampStopToLiquidation(entry, stop, leverage);
  stop = _clampedStop;
  const risk = Math.abs(entry - stop);
  const reward = Math.abs(target - entry);
  const rr = risk > 0 ? reward / risk : 0;
  if (rr < genome.min_rr) return null;

  if (paperBalance <= 0 || maxDollarRisk <= 0) return null;
  const maxNotional = paperBalance * leverage;
  const rawSize = (maxDollarRisk / risk) * entry;
  const simulatedSize = Math.min(rawSize, maxNotional);
  const actualRisk = simulatedSize * (risk / entry);

  // Log all signals found for visibility
  const allStrats = signals.map(s => `${s.strategy}(${s.confidence.toFixed(1)})`).join(", ");

  let proposal = {
    agentId: "APEX",
    symbol,
    entry,
    stop,
    target,
    riskReward: rr,
    simulatedSize,
    maxDollarRisk: actualRisk,
    marketData: data,
    temporalScore: data.temporalScore,
    direction: best.direction,
    liquidationPrice,
    strategy: best.strategy,
    // Store extra info in a property we'll read when opening the trade
    _apexReason: `1h trend: ${trend.dir} | ${best.strategy}: ${best.reason} | Signals: ${allStrats}`,
    _apexTrend: trend.dir,
  } as TradeProposal & { strategy: string; _apexReason: string; _apexTrend: string };
  if ((genome.trade_direction ?? 1) < 0) {
    proposal = mirrorProposalGeometry(proposal, leverage) as typeof proposal;
    proposal._apexReason += ` | INTENTIONAL GENOME REVERSAL: ${best.direction} → ${proposal.direction}`;
  }
  if (!validTradeGeometry(proposal)) {
    console.error("APEX rejected invalid direction or order geometry", proposal.symbol, proposal.strategy);
    return null;
  }
  return proposal;
}

// ──────────────────────────────────────────────
// Agent 10: MIRAGE — Mirror Experiment Bot
// Watches the same volatile coins as REKT (and APEX where easy), but takes
// the OPPOSITE side of every signal (REKT long → MIRAGE short), keeping
// identical entry/stop/target geometry so its results are a clean live A/B
// against the originals. Own fund, own risk budget — its P&L never touches
// paper_balance or the team total.
// ──────────────────────────────────────────────

function mirrorProposal(
  source: TradeProposal,
  fundBalance: number,
  leverage: number,
  sourceAgent: string
): TradeProposal {
  const entry = source.entry;
  const stop = 2 * entry - source.stop;
  const target = 2 * entry - source.target;

  const { stop: clampedStop, liquidationPrice } = clampStopToLiquidation(entry, stop, leverage);

  const risk = Math.abs(entry - clampedStop);
  const reward = Math.abs(target - entry);
  const rr = risk > 0 ? reward / risk : 0;

  // Same notional as the source trade so results are directly comparable
  const maxNotional = fundBalance * leverage;
  const simulatedSize = Math.min(source.simulatedSize, maxNotional);
  const actualRisk = simulatedSize * (risk / entry);

  const direction: "LONG" | "SHORT" = source.direction === "LONG" ? "SHORT" : "LONG";

  return {
    agentId: "MIRAGE",
    symbol: source.symbol,
    entry,
    stop: clampedStop,
    target,
    riskReward: rr,
    simulatedSize,
    maxDollarRisk: actualRisk,
    marketData: source.marketData,
    temporalScore: source.temporalScore,
    direction,
    liquidationPrice,
    _mirrorSource: sourceAgent,
    _mirrorReason: `MIRROR of ${sourceAgent} ${source.direction} (rr ${source.riskReward.toFixed(2)}) → ${direction}`,
  } as TradeProposal & { _mirrorSource: string; _mirrorReason: string };
}

// Build MIRAGE's mirror of a fresh REKT proposal. Runs REKT's signal logic
// with a neutral Bayesian state so MIRAGE trades whenever REKT *would* trade,
// regardless of REKT's own circuit breaker.
async function mirageFromRekt(
  data: MarketData,
  symbol: string,
  fundBalance: number,
  maxDollarRisk: number,
  genome: Genome,
  leverage: number
): Promise<TradeProposal | null> {
  const neutralBayes: BayesianState = { alpha: 2, beta: 2, edgeConfidence: 0, shouldTrade: true, winProbability: 0.5 };
  const rekt = await rektAgent(data, neutralBayes, maxDollarRisk, symbol, fundBalance, leverage, genome);
  if (!rekt || !isFeeViable(rekt.entry, rekt.target)) return null;
  if (rekt.riskReward < genome.min_rr) return null;
  return mirrorProposal(rekt, fundBalance, leverage, "REKT");
}

// ──────────────────────────────────────────────
// Agent 9: AKI — Logger + Leaderboard + Bayesian updater
// ──────────────────────────────────────────────

async function akiLogTrade(
  agentId: string,
  status: string,
  pnl: number,
  blocked: boolean
): Promise<void> {
  const { data: existing } = await supabase
    .from("agent_stats")
    .select("*")
    .eq("agent_id", agentId)
    .maybeSingle();

  if (!existing) {
    const isWin = status === "CLOSED" && pnl > 0;
    const isLoss = status === "CLOSED" && pnl < 0;
    await supabase.from("agent_stats").insert({
      agent_id: agentId,
      total_trades: 1,
      wins: isWin ? 1 : 0,
      losses: isLoss ? 1 : 0,
      blocked: blocked ? 1 : 0,
      win_rate: isWin ? 100 : 0,
      avg_win: pnl > 0 ? pnl : 0,
      avg_loss: pnl < 0 ? pnl : 0,
      biggest_win: pnl > 0 ? pnl : 0,
      biggest_loss: pnl < 0 ? Math.abs(pnl) : 0,
      total_pnl: pnl,
      max_drawdown: pnl < 0 ? Math.abs(pnl) : 0,
      current_drawdown: pnl < 0 ? Math.abs(pnl) : 0,
      bayesian_alpha: 2 + (isWin ? 1 : 0),
      bayesian_beta: 2 + (isLoss ? 1 : 0),
      edge_confidence: 20,
      should_trade: true,
      updated_at: new Date().toISOString(),
    });
    return;
  }

  const totalTrades = existing.total_trades + 1;
  const wins = existing.wins + (status === "CLOSED" && pnl > 0 ? 1 : 0);
  const losses = existing.losses + (status === "CLOSED" && pnl < 0 ? 1 : 0);
  const blockedCount = existing.blocked + (blocked ? 1 : 0);
  const closedTrades = wins + losses;
  const winRate = closedTrades > 0 ? (wins / closedTrades) * 100 : 0;

  const allWins = pnl > 0 ? [...[existing.avg_win * existing.wins, pnl]] : [existing.avg_win * existing.wins];
  const allLosses = pnl < 0 ? [...[existing.avg_loss * existing.losses, pnl]] : [existing.avg_loss * existing.losses];

  const avgWin = wins > 0 ? allWins.reduce((a, b) => a + b, 0) / wins : 0;
  const avgLoss = losses > 0 ? allLosses.reduce((a, b) => a + b, 0) / losses : 0;
  const biggestWin = Math.max(existing.biggest_win, pnl > 0 ? pnl : 0);
  const biggestLoss = Math.max(existing.biggest_loss, pnl < 0 ? Math.abs(pnl) : 0);

  const totalPnl = existing.total_pnl + pnl;
  const newDrawdown = pnl < 0 ? existing.current_drawdown + Math.abs(pnl) : 0;
  const maxDrawdown = Math.max(existing.max_drawdown, newDrawdown);

  // Bayesian update on closed trades only
  const newAlpha = (existing.bayesian_alpha ?? 2) + (status === "CLOSED" && pnl > 0 ? 1 : 0);
  const newBeta = (existing.bayesian_beta ?? 2) + (status === "CLOSED" && pnl < 0 ? 1 : 0);
  const winProb = newAlpha / (newAlpha + newBeta);
  const confidence = Math.min(100, (closedTrades / (closedTrades + 4)) * 100);

  let shouldTrade = existing.should_trade ?? true;
  if (closedTrades >= 20 && winProb < 0.35) shouldTrade = false;
  else if (closedTrades >= 20 && winProb >= 0.40) shouldTrade = true;

  await supabase
    .from("agent_stats")
    .update({
      total_trades: totalTrades,
      wins,
      losses,
      blocked: blockedCount,
      win_rate: winRate,
      avg_win: avgWin,
      avg_loss: avgLoss,
      biggest_win: biggestWin,
      biggest_loss: biggestLoss,
      total_pnl: totalPnl,
      max_drawdown: maxDrawdown,
      current_drawdown: newDrawdown,
      bayesian_alpha: newAlpha,
      bayesian_beta: newBeta,
      edge_confidence: confidence,
      should_trade: shouldTrade,
      updated_at: new Date().toISOString(),
    })
    .eq("agent_id", agentId);
}

async function updateSystemConfig(pnl: number, tradeOpened: boolean, blocked: boolean): Promise<void> {
  const { data: config } = await supabase
    .from("system_config")
    .select("*")
    .eq("id", 1)
    .maybeSingle();
  if (!config) return;

  const isClose = !tradeOpened && !blocked && pnl !== 0;

  await supabase
    .from("system_config")
    .update({
      total_team_pnl: config.total_team_pnl + pnl,
      paper_balance: isClose ? config.paper_balance + pnl : config.paper_balance,
      total_trades: config.total_trades + (tradeOpened ? 1 : 0),
      total_blocked: config.total_blocked + (blocked ? 1 : 0),
      updated_at: new Date().toISOString(),
    })
    .eq("id", 1);
}

// ──────────────────────────────────────────────
// Trade management — check open trades for stop/target hits
// ──────────────────────────────────────────────

async function checkOpenTrades(maxHoldHoursMap: Record<string, number>): Promise<{ closed: number; pnl: number; details: Record<string, unknown>[] }> {
  const checkDetails: Record<string, unknown>[] = [];
  const { data: openTrades } = await supabase
    .from("paper_trades")
    .select("*")
    .eq("status", "OPEN");

  if (!openTrades || openTrades.length === 0) {
    checkDetails.push({ info: "No open trades to check" });
    return { closed: 0, pnl: 0, details: checkDetails };
  }

  checkDetails.push({ info: `Checking ${openTrades.length} open trades for stop/target/timeout` });

  let closedCount = 0;
  let totalPnl = 0;

  for (const trade of openTrades) {
    // REKT, APEX, MIRAGE trade perps — use linear category for price fetching
    const tradeMarketData = trade.market_data as Record<string, unknown> | null;
    const isPerpTrade = tradeMarketData?.perp === true || trade.agent_id === "REKT" || trade.agent_id === "APEX" || trade.agent_id === "MIRAGE";
    const tickerCat = isPerpTrade ? "linear" : "spot";
    const ticker = await fetchTicker(trade.symbol, tickerCat);
    if (!ticker) {
      checkDetails.push({ agent: trade.agent_id, symbol: trade.symbol, info: "Could not fetch price — skipping" });
      continue;
    }

    const price = ticker.lastPrice;

    const entry = trade.entry_price;
    const stop = trade.stop_price;
    const target = trade.target_price;
    const size = trade.simulated_size;
    const openedAt = new Date(trade.opened_at).getTime();
    const ageHours = (Date.now() - openedAt) / (1000 * 60 * 60);

    // Determine direction from entry/stop/target relationship
    const isShort = stop > entry;
    const isLong = !isShort;

    if (!(isLong ? stop < entry && entry < target : target < entry && entry < stop)) {
      checkDetails.push({ agent: trade.agent_id, symbol: trade.symbol, info: "INVALID stop/target geometry; trade skipped for manual review" });
      continue;
    }
    const recentKlines = await fetchTradeCandles(trade.symbol, tickerCat, openedAt);
    if (recentKlines === null) {
      checkDetails.push({ agent: trade.agent_id, symbol: trade.symbol, info: "Incomplete Bybit 1m history; unsafe to infer exit. Skipping." });
      continue;
    }

    const maxHoldHours = maxHoldHoursMap[trade.agent_id] ?? 24;
    // Preserve the original trailing rule for now, but apply it in actual
    // chronological order. The trailing stop only becomes active NEXT candle
    // after a completed candle reaches the trigger.
    const trailConfig = { trigger: 0.25, lock: 0.85 };
    const progressToTarget = isLong
      ? (price - entry) / (target - entry)
      : (entry - price) / (entry - target);
    let effectiveStop = stop;
    let trailingTriggered = false;
    let closeReason = "";
    let pnl = 0;
    let closed = false;
    let exitPrice = price;
    const liquidation = Number(trade.liquidation_price) || null;
    const timeoutAt = openedAt + maxHoldHours * 3_600_000;

    for (const candle of recentKlines) {
      if (candle.time < openedAt) continue; // Entry candle may contain pre-entry highs/lows.
      if (candle.time >= timeoutAt) {
        closeReason = "TIMEOUT";
        exitPrice = candle.open;
        closed = true;
        break;
      }
      const hitStop = isLong ? candle.low <= effectiveStop : candle.high >= effectiveStop;
      const hitTarget = isLong ? candle.high >= target : candle.low <= target;
      const hitLiq = liquidation !== null && (isLong ? candle.low <= liquidation : candle.high >= liquidation);
      // With OHLC data event ordering within a minute is unknown. Use a
      // conservative stop-first assumption and never fabricate a target win.
      if (hitLiq && (!hitStop || (isLong ? liquidation >= effectiveStop : liquidation <= effectiveStop))) {
        closeReason = "LIQUIDATION";
        exitPrice = liquidation!;
      } else if (hitStop || hitLiq) {
        closeReason = hitLiq ? "LIQUIDATION" : trailingTriggered ? "TRAILING_STOP_HIT" : "STOP_HIT";
        exitPrice = hitLiq && !hitStop ? liquidation! : effectiveStop;
      } else if (hitTarget) {
        closeReason = "TARGET_HIT";
        exitPrice = target;
      }
      if (closeReason) { closed = true; break; }

      // Never trail using this candle's high/low before testing its original stop.
      const favourable = isLong ? candle.high : candle.low;
      const progress = isLong
        ? (favourable - entry) / (target - entry)
        : (entry - favourable) / (entry - target);
      if (progress >= trailConfig.trigger) {
        const locked = entry + (favourable - entry) * trailConfig.lock;
        effectiveStop = isLong ? Math.max(effectiveStop, entry, locked) : Math.min(effectiveStop, entry, locked);
        trailingTriggered = true;
      }
    }
    if (closed) {
      // simulated_size is USDT notional, not the number of coins.
      pnl = (isLong ? (exitPrice - entry) : (entry - exitPrice)) / entry * size;
    }

    if (!closed) {
      const stopPctAway = isLong
        ? ((price - stop) / price) * 100
        : ((stop - price) / price) * 100;
      const targetPctAway = isLong
        ? ((target - price) / price) * 100
        : ((price - target) / price) * 100;
      checkDetails.push({
        agent: trade.agent_id,
        symbol: trade.symbol,
        info: `OPEN ${ageHours.toFixed(1)}h/${maxHoldHours}h max | Price: ${price} | Stop: ${stop} (${stopPctAway.toFixed(1)}% away) | Target: ${target} (${targetPctAway.toFixed(1)}% away) | Progress: ${(progressToTarget * 100).toFixed(0)}%${trailingTriggered ? " | TRAILING ACTIVE" : ""}${liquidation ? ` | Liq: ${liquidation.toFixed(2)}` : ""}`,
      });
    }

    if (closed) {
      // Taker fees on entry + exit, charged on notional
      pnl -= TAKER_FEE_RATE * size * 2;
      const pnlPct = entry > 0 ? (pnl / size) * 100 : 0;
      const { data: updatedTrade, error: closeError } = await supabase
        .from("paper_trades")
        .update({
          status: "CLOSED",
          exit_price: exitPrice,
          pnl: Math.round(pnl * 100) / 100,
          pnl_pct: Math.round(pnlPct * 100) / 100,
          close_reason: closeReason,
          closed_at: new Date().toISOString(),
        })
        .eq("id", trade.id)
        .eq("status", "OPEN")
        .select("id")
        .maybeSingle();
      if (closeError || !updatedTrade) {
        checkDetails.push({ agent: trade.agent_id, symbol: trade.symbol, info: "Close not applied (already closed or DB error)" });
        continue;
      }

      await akiLogTrade(trade.agent_id, "CLOSED", pnl, false);
      await updateSymbolStats(trade.agent_id, trade.symbol, pnl > 0, pnl);
      // MIRAGE: update its own fund — never paper_balance or team P&L
      if (trade.agent_id === "MIRAGE") {
        const { data: mirageConfig } = await supabase.from("system_config").select("mirage_balance").eq("id", 1).maybeSingle();
        if (mirageConfig) {
          await supabase.from("system_config").update({
            mirage_balance: (mirageConfig.mirage_balance ?? 100) + pnl,
          }).eq("id", 1);
        }
        await updateSystemConfig(0, false, false);
      }
      // APEX: update per-strategy learning stats and compound its own balance
      if (trade.agent_id === "APEX") {
        const stratName = (trade.market_data as Record<string, unknown>)?.strategy as string | undefined;
        if (stratName) await updateStrategyStats(stratName, pnl > 0, pnl);
        // Compound APEX balance — APEX has its own bankroll, separate from paper_balance
        const { data: apexConfig } = await supabase.from("system_config").select("apex_compound_balance").eq("id", 1).maybeSingle();
        if (apexConfig) {
          await supabase.from("system_config").update({
            apex_compound_balance: (apexConfig.apex_compound_balance ?? 50) + pnl,
          }).eq("id", 1);
        }
        // APEX PnL does NOT go into the shared paper_balance — it has its own fund
        await updateSystemConfig(0, false, false);
      } else {
        await updateSystemConfig(pnl, false, false);
      }
      closedCount++;
      totalPnl += pnl;
      checkDetails.push({
        agent: trade.agent_id,
        symbol: trade.symbol,
        info: `CLOSED: ${closeReason} | P&L: ${pnl >= 0 ? "+" : ""}${pnl.toFixed(2)} | Held: ${ageHours.toFixed(1)}h`,
      });
    }
  }

  return { closed: closedCount, pnl: totalPnl, details: checkDetails };
}

// ──────────────────────────────────────────────
// Risk helpers
// ──────────────────────────────────────────────

async function getTeamRisk(): Promise<number> {
  const { data: openTrades } = await supabase
    .from("paper_trades")
    .select("max_dollar_risk")
    .eq("status", "OPEN");

  if (!openTrades) return 0;
  return openTrades.reduce((sum, t) => sum + (t.max_dollar_risk || 0), 0);
}

async function countOpenTradesByAgent(agentId: string): Promise<number> {
  const { count } = await supabase
    .from("paper_trades")
    .select("*", { count: "exact", head: true })
    .eq("status", "OPEN")
    .eq("agent_id", agentId);
  return count || 0;
}

async function getAgentRisk(agentId: string): Promise<number> {
  const { data: openTrades } = await supabase
    .from("paper_trades")
    .select("max_dollar_risk")
    .eq("status", "OPEN")
    .eq("agent_id", agentId);

  if (!openTrades) return 0;
  return openTrades.reduce((sum, t) => sum + (t.max_dollar_risk || 0), 0);
}

// ──────────────────────────────────────────────
// Fee-viability filter — skip proposals whose target move is too small to
// clear taker fees on entry + exit with meaningful margin.
// TAKER_FEE_RATE × 2 ≈ 0.11% of notional; require ≥ 0.35% target move.
// ──────────────────────────────────────────────

const MIN_TARGET_MOVE_PCT = 0.35;

function isFeeViable(entry: number, target: number): boolean {
  return entry > 0 && Math.abs(target - entry) / entry >= MIN_TARGET_MOVE_PCT / 100;
}

// ──────────────────────────────────────────────
// Main pipeline — runs all 7 agents
// ──────────────────────────────────────────────

async function runPipeline(): Promise<{
  opened: number;
  closed: number;
  blocked: number;
  details: Record<string, unknown>[];
}> {
  const details: Record<string, unknown>[] = [];
  let opened = 0;
  let blocked = 0;

  // Load champion genomes so live trading uses evolved parameters
  const genomes = await loadChampionGenomes();
  const maxHoldHoursMap: Record<string, number> = {
    KIBO: genomes.KIBO.max_hold_bars,           // 1h candles → hours
    YUZU: genomes.YUZU.max_hold_bars,            // 1h candles → hours
    MATTY: genomes.MATTY.max_hold_bars * 5 / 60, // 5m candles → hours
    REKT: 999,                                   // no timeout — REKT exits only on TP/SL
    APEX: genomes.APEX.max_hold_bars * 5 / 60,  // 5m candles → hours
    MIRAGE: 999,                                 // mirror REKT: exits only on TP/SL
  };
  details.push({ info: `Loaded champion genomes: KIBO Gen (evolved), YUZU Gen (evolved), MATTY Gen (evolved), REKT Gen (evolved), APEX Gen (default) | Max hold: KIBO ${maxHoldHoursMap.KIBO}h, YUZU ${maxHoldHoursMap.YUZU}h, MATTY ${maxHoldHoursMap.MATTY.toFixed(1)}h, REKT ${maxHoldHoursMap.REKT.toFixed(2)}h, APEX ${maxHoldHoursMap.APEX.toFixed(1)}h` });

  const closeResult = await checkOpenTrades(maxHoldHoursMap);
  const closed = closeResult.closed;
  details.push(...closeResult.details);

  const { data: config } = await supabase
    .from("system_config")
    .select("*")
    .eq("id", 1)
    .maybeSingle();

  if (!config || !config.is_running) {
    return { opened: 0, closed, blocked: 0, details: [{ info: "System is paused" }] };
  }

  const watchlist: string[] = config.watchlist;
  const maxTeamRisk = (config.max_total_risk_pct / 100) * config.paper_balance;
  const maxPositionsPerAgent = config.max_positions_per_agent || 3;
  const maxDollarRiskPerTrade = (config.max_risk_per_trade_pct / 100) * config.paper_balance;
  const rektRiskBudget = ((config.rekt_risk_pct ?? 10) / 100) * config.paper_balance;
  const mattyRiskBudget = ((config.matty_risk_pct ?? 15) / 100) * config.paper_balance;
  const apexBalanceForBudget = config.apex_compound_balance ?? config.apex_start_balance ?? 50;
  const apexRiskBudget = ((config.apex_risk_pct ?? 8) / 100) * apexBalanceForBudget;

  // Check team risk but don't block agents with their own dedicated budgets (REKT, MATTY, APEX)
  const currentTeamRisk = await getTeamRisk();
  const rektRiskEarly = await getAgentRisk("REKT");
  const mattyRiskEarly = await getAgentRisk("MATTY");
  const apexRiskEarly = await getAgentRisk("APEX");
  const kiboYuzuRiskEarly = currentTeamRisk - rektRiskEarly - mattyRiskEarly - apexRiskEarly;
  const kiboYuzuBudgetEarly = maxTeamRisk - rektRiskBudget - mattyRiskBudget - apexRiskBudget;
  if (kiboYuzuRiskEarly >= kiboYuzuBudgetEarly) {
    details.push({ info: `KIBO/YUZU risk limit reached (${kiboYuzuRiskEarly.toFixed(2)}/${kiboYuzuBudgetEarly.toFixed(2)}) — REKT/MATTY/APEX may still trade` });
  }

  // Refresh temporal bias cache once per cycle (first run will be slow, subsequent runs use cache)
  // Only refresh if cache is stale — check the most recent update
  const { data: cacheCheck } = await supabase
    .from("temporal_bias_cache")
    .select("updated_at")
    .order("updated_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  const cacheStale = !cacheCheck ||
    (Date.now() - new Date(cacheCheck.updated_at).getTime()) > 24 * 60 * 60 * 1000;

  if (cacheStale) {
    details.push({ info: "Refreshing temporal bias cache (30-day hourly analysis)..." });
    await refreshTemporalBias(watchlist);
  }

  // Get Bayesian states for trading agents
  const kiboBayes = await getBayesianState("KIBO");
  const yuzuBayes = await getBayesianState("YUZU");
  const mattyBayes = await getBayesianState("MATTY");
  const rektBayes = await getBayesianState("REKT");
  const apexBayes = await getBayesianState("APEX");

  details.push({
    bayesian: {
      KIBO: { winProb: kiboBayes.winProbability.toFixed(2), confidence: kiboBayes.edgeConfidence.toFixed(0), shouldTrade: kiboBayes.shouldTrade },
      YUZU: { winProb: yuzuBayes.winProbability.toFixed(2), confidence: yuzuBayes.edgeConfidence.toFixed(0), shouldTrade: yuzuBayes.shouldTrade },
      MATTY: { winProb: mattyBayes.winProbability.toFixed(2), confidence: mattyBayes.edgeConfidence.toFixed(0), shouldTrade: mattyBayes.shouldTrade },
      REKT: { winProb: rektBayes.winProbability.toFixed(2), confidence: rektBayes.edgeConfidence.toFixed(0), shouldTrade: rektBayes.shouldTrade },
      APEX: { winProb: apexBayes.winProbability.toFixed(2), confidence: apexBayes.edgeConfidence.toFixed(0), shouldTrade: apexBayes.shouldTrade },
    }
  });

  for (const symbol of watchlist) {
    const marketData = await gatherMarketData(symbol);
    if (!marketData) {
      details.push({ symbol, info: "Could not fetch market data" });
      continue;
    }

    // ── MOMO ──
    const momo = momoAgent(marketData);
    details.push({ agent: "MOMO", symbol, ...momo.details, reason: momo.reason });

    if (!momo.pass) {
      await supabase.from("paper_trades").insert({
        agent_id: "MOMO",
        symbol,
        status: "BLOCKED",
        momo_pass: false,
        sora_decision: "BLOCK",
        block_reason: momo.reason,
        market_data: momo.details as Record<string, unknown>,
        closed_at: new Date().toISOString(),
        close_reason: "BLOCKED",
      });
      await akiLogTrade("MOMO", "BLOCKED", 0, true);
      await updateSystemConfig(0, false, true);
      blocked++;
    }

    // ── RIN ──
    const rin = rinAgent(marketData);
    details.push({ agent: "RIN", symbol, ...rin.details, reason: rin.reason });

    if (!rin.pass) {
      await supabase.from("paper_trades").insert({
        agent_id: "RIN",
        symbol,
        status: "BLOCKED",
        momo_pass: true,
        rin_pass: false,
        sora_decision: "BLOCK",
        block_reason: rin.reason,
        market_data: { momo: momo.details, rin: rin.details } as Record<string, unknown>,
        closed_at: new Date().toISOString(),
        close_reason: "BLOCKED",
      });
      await akiLogTrade("RIN", "BLOCKED", 0, true);
      await updateSystemConfig(0, false, true);
      blocked++;
    }

    // ── KIBO, YUZU, and MATTY: Generate proposals ──
    // KIBO/YUZU are trend-followers gated by MOMO+RIN quality checks.
    // MATTY is a reversal bot — it runs independently with its own entry criteria.
    const trendGatesPass = momo.pass && rin.pass;

    const symbolLeverage = (config.leverage_tiers as Record<string, number>)?.[symbol] || config.leverage || 10;

    const kiboProposal = trendGatesPass ? kiboAgent(marketData, kiboBayes, maxDollarRiskPerTrade, config.paper_balance, symbolLeverage, genomes.KIBO) : null;
    const yuzuProposal = trendGatesPass ? yuzuAgent(marketData, yuzuBayes, maxDollarRiskPerTrade, config.paper_balance, symbolLeverage, genomes.YUZU) : null;
    const mattyProposal = await mattyAgent(marketData, mattyBayes, maxDollarRiskPerTrade, symbol, config.paper_balance, symbolLeverage, genomes.MATTY);

    const proposals: TradeProposal[] = [
      kiboProposal,
      yuzuProposal,
      mattyProposal,
    ].filter((p): p is TradeProposal => p !== null && isFeeViable(p.entry, p.target));

    if (proposals.length === 0) {
      details.push({ agent: "KIBO/YUZU/MATTY/REKT", symbol, info: "No setup qualifies", temporalScore: marketData.temporalScore });
      continue;
    }

    for (const proposal of proposals) {
      scopeStopInPlace(proposal);
      // Multiple positions per agent now allowed
      const agentOpenCount = await countOpenTradesByAgent(proposal.agentId);
      if (agentOpenCount >= maxPositionsPerAgent) {
        details.push({ agent: proposal.agentId, symbol, info: `Max positions (${maxPositionsPerAgent}) reached` });
        continue;
      }

      // Per-symbol learning: check if this agent should trade this symbol
      const symbolCheck = await shouldTradeSymbol(proposal.agentId, symbol);
      if (!symbolCheck.allowed) {
        details.push({ agent: proposal.agentId, symbol, info: `Symbol skipped: ${symbolCheck.reason}` });
        continue;
      }

      // Don't open duplicate position on same symbol with same agent
      const { count: dupCount } = await supabase
        .from("paper_trades")
        .select("*", { count: "exact", head: true })
        .eq("status", "OPEN")
        .eq("agent_id", proposal.agentId)
        .eq("symbol", symbol);
      if (dupCount && dupCount > 0) {
        details.push({ agent: proposal.agentId, symbol, info: "Already has open position on this symbol" });
        continue;
      }

      // ── SORA risk gate (skip for MATTY — different timeframe, own risk model) ──
      const isMatty = proposal.agentId === "MATTY";
      const isRekt = proposal.agentId === "REKT";
      const skipSora = isMatty || isRekt;
      const sora = skipSora ? { approve: true, pass: true, reason: isMatty ? "SKIP (MATTY independent)" : "SKIP (REKT independent)", details: {} } : soraAgent(marketData, proposal.entry, proposal.stop);
      if (!skipSora) details.push({ agent: "SORA", symbol, ...sora.details, reason: sora.reason });

      if (!sora.approve) {
        await supabase.from("paper_trades").insert({
          agent_id: proposal.agentId,
          symbol,
          status: "BLOCKED",
          entry_price: proposal.entry,
          stop_price: proposal.stop,
          target_price: proposal.target,
          momo_pass: true,
          rin_pass: true,
          sora_decision: "BLOCK",
          kibo_decision: proposal.agentId === "KIBO" ? "APPROVE" : null,
          yuzu_decision: proposal.agentId === "YUZU" ? "APPROVE" : null,
          matty_decision: proposal.agentId === "MATTY" ? "APPROVE" : null,
          rekt_decision: proposal.agentId === "REKT" ? "APPROVE" : null,
          block_reason: sora.reason,
          market_data: {
            momo: momo.details,
            rin: rin.details,
            sora: sora.details,
            proposal: { entry: proposal.entry, stop: proposal.stop, target: proposal.target, rr: proposal.riskReward },
            temporal: { score: proposal.temporalScore, hour: marketData.hourUtc },
          } as Record<string, unknown>,
          closed_at: new Date().toISOString(),
          close_reason: "BLOCKED",
        });
        await akiLogTrade(proposal.agentId, "BLOCKED", 0, true);
        await akiLogTrade("SORA", "BLOCKED", 0, true);
        await updateSystemConfig(0, false, true);
        blocked++;
        continue;
      }

      // Check team risk (exclude REKT, MATTY, APEX — they have their own dedicated risk budgets)
      if (proposal.agentId === "KIBO" || proposal.agentId === "YUZU") {
        const teamRisk = await getTeamRisk();
        const rektRisk = await getAgentRisk("REKT");
        const mattyRisk = await getAgentRisk("MATTY");
        const apexRisk = await getAgentRisk("APEX");
        const kiboYuzuRisk = teamRisk - rektRisk - mattyRisk - apexRisk;
        const kiboYuzuBudget = maxTeamRisk - rektRiskBudget - mattyRiskBudget - apexRiskBudget;
        if (kiboYuzuRisk + proposal.maxDollarRisk > kiboYuzuBudget) {
          details.push({ agent: "EXECUTOR", symbol, info: `KIBO/YUZU risk limit would be exceeded (${kiboYuzuRisk.toFixed(2)}/${kiboYuzuBudget.toFixed(2)})` });
          continue;
        }
      }

      const tradeId = crypto.randomUUID();
      await supabase.from("paper_trades").insert({
        id: tradeId,
        agent_id: proposal.agentId,
        symbol,
        status: "OPEN",
        entry_price: proposal.entry,
        stop_price: proposal.stop,
        target_price: proposal.target,
        simulated_size: proposal.simulatedSize,
        max_dollar_risk: proposal.maxDollarRisk,
        liquidation_price: proposal.liquidationPrice,
        momo_pass: isMatty || isRekt ? false : true,
        rin_pass: isMatty || isRekt ? false : true,
        sora_decision: isMatty || isRekt ? "SKIP" : "APPROVE",
        kibo_decision: proposal.agentId === "KIBO" ? "APPROVE" : "SKIP",
        yuzu_decision: proposal.agentId === "YUZU" ? "APPROVE" : "SKIP",
        matty_decision: proposal.agentId === "MATTY" ? "APPROVE" : "SKIP",
        rekt_decision: proposal.agentId === "REKT" ? "APPROVE" : "SKIP",
        opened_at: new Date().toISOString(),
        market_data: isMatty || isRekt ? {
          proposal: {
            entry: proposal.entry,
            stop: proposal.stop,
            target: proposal.target,
            rr: proposal.riskReward,
            size: proposal.simulatedSize,
          },
          temporal: { score: proposal.temporalScore, hour: marketData.hourUtc },
          bayesian: isRekt ? {
            winProb: rektBayes.winProbability,
            confidence: rektBayes.edgeConfidence,
          } : {
            winProb: mattyBayes.winProbability,
            confidence: mattyBayes.edgeConfidence,
          },
        } as Record<string, unknown> : {
          momo: momo.details,
          rin: rin.details,
          sora: sora.details,
          proposal: {
            entry: proposal.entry,
            stop: proposal.stop,
            target: proposal.target,
            rr: proposal.riskReward,
            size: proposal.simulatedSize,
          },
          temporal: { score: proposal.temporalScore, hour: marketData.hourUtc },
          bayesian: {
            winProb: proposal.agentId === "KIBO" ? kiboBayes.winProbability : yuzuBayes.winProbability,
            confidence: proposal.agentId === "KIBO" ? kiboBayes.edgeConfidence : yuzuBayes.edgeConfidence,
          },
        } as Record<string, unknown>,
      });

      await akiLogTrade(proposal.agentId, "OPEN", 0, false);
      await updateSystemConfig(0, true, false);
      opened++;
      details.push({
        agent: proposal.agentId,
        symbol,
        info: `PAPER TRADE OPENED | ENTRY: ${proposal.entry} | STOP: ${proposal.stop} | TARGET: ${proposal.target} | R/R: ${proposal.riskReward.toFixed(2)} | TEMPORAL: ${proposal.temporalScore.toFixed(2)}`,
      });
    }
  }

  // ── YUZU: Scan mid-volatility perps for scalping opportunities ──
  // YUZU is a trend-following scalper that needs coins with real movement.
  // The spot watchlist (BTC, ETH, SOL) doesn't move enough in 3 hours for
  // a scalper to hit targets. But the MOST volatile perps (STRK, SOXL, SNDK)
  // are so noisy that trend signals get whipsawed. So YUZU scans the top 15
  // volatile perps but skips the 5 most extreme — landing on mid-volatility
  // coins that trend enough to scalp without being pure noise.
  const yuzuMaxPositions = maxPositionsPerAgent;
  const yuzuOpenCount = await countOpenTradesByAgent("YUZU");
  if (yuzuOpenCount < yuzuMaxPositions && yuzuBayes.shouldTrade) {
    const yuzuAllMovers = await fetchTopMoversPerp(50_000_000, 15);
    // Coins that are too noisy for YUZU's trend signals — they whipsaw repeatedly
    // and bleed death by a thousand cuts. Backtests confirm consistent losses.
    const yuzuBlocklist = ["SOXLUSDT", "SNDKUSDT", "DOGEUSDT", "WLDUSDT"];
    const yuzuMovers = yuzuAllMovers.slice(5).filter(s => !yuzuBlocklist.includes(s));
    details.push({ agent: "YUZU", info: `Scanning ${yuzuMovers.length} mid-volatility perps for scalps: ${yuzuMovers.join(", ")} | Budget: shared KIBO/YUZU` });

    for (const perpSymbol of yuzuMovers) {
      if (yuzuOpenCount + (await countOpenTradesByAgent("YUZU")) >= yuzuMaxPositions) break;

      const { count: yuzuDup } = await supabase
        .from("paper_trades")
        .select("*", { count: "exact", head: true })
        .eq("status", "OPEN")
        .eq("agent_id", "YUZU")
        .eq("symbol", perpSymbol);
      if (yuzuDup && yuzuDup > 0) continue;

      const symbolCheck = await shouldTradeSymbol("YUZU", perpSymbol);
      if (!symbolCheck.allowed) continue;

      const perpTicker = await fetchTicker(perpSymbol, "linear");
      if (!perpTicker) continue;

      const perpKlines1h = await fetchKlines(perpSymbol, "60", 100, "linear");
      if (perpKlines1h.length < 20) continue;

      const perpMarketData: MarketData = {
        ticker: perpTicker,
        klines: perpKlines1h,
        volatility: calcVolatility(perpKlines1h, 20),
        shortTermMove: perpKlines1h.length >= 10
          ? ((perpKlines1h[perpKlines1h.length - 1].close - perpKlines1h[perpKlines1h.length - 10].close) / perpKlines1h[perpKlines1h.length - 10].close) * 100
          : 0,
        volumeSpike: false,
        rsi: calcRSI(perpKlines1h, 14),
        sma20: calcSMA(perpKlines1h, 20),
        sma50: calcSMA(perpKlines1h, Math.min(50, perpKlines1h.length)),
        trendDirection: "SIDEWAYS",
        temporalScore: 0,
        hourUtc: new Date().getUTCHours(),
      };

      const yuzuPerpLeverage = (config.leverage_tiers as Record<string, number>)?.[perpSymbol] || config.leverage || 10;
      const yuzuPerpProposal = yuzuAgent(perpMarketData, yuzuBayes, maxDollarRiskPerTrade, config.paper_balance, yuzuPerpLeverage, genomes.YUZU);
      if (!yuzuPerpProposal || !isFeeViable(yuzuPerpProposal.entry, yuzuPerpProposal.target)) continue;
      scopeStopInPlace(yuzuPerpProposal);

      // YUZU shares the KIBO/YUZU risk budget (not a separate budget like REKT/MATTY/APEX)
      const teamRisk = await getTeamRisk();
      const rektRisk = await getAgentRisk("REKT");
      const mattyRisk = await getAgentRisk("MATTY");
      const apexRisk = await getAgentRisk("APEX");
      const kiboYuzuRisk = teamRisk - rektRisk - mattyRisk - apexRisk;
      const kiboYuzuBudget = maxTeamRisk - rektRiskBudget - mattyRiskBudget - apexRiskBudget;
      if (kiboYuzuRisk + yuzuPerpProposal.maxDollarRisk > kiboYuzuBudget) {
        details.push({ agent: "YUZU", symbol: perpSymbol, info: `Team risk limit would be exceeded (${kiboYuzuRisk.toFixed(2)}/${kiboYuzuBudget.toFixed(2)})` });
        break;
      }

      const yuzuTradeId = crypto.randomUUID();
      await supabase.from("paper_trades").insert({
        id: yuzuTradeId,
        agent_id: "YUZU",
        symbol: perpSymbol,
        status: "OPEN",
        entry_price: yuzuPerpProposal.entry,
        stop_price: yuzuPerpProposal.stop,
        target_price: yuzuPerpProposal.target,
        simulated_size: yuzuPerpProposal.simulatedSize,
        max_dollar_risk: yuzuPerpProposal.maxDollarRisk,
        liquidation_price: yuzuPerpProposal.liquidationPrice,
        momo_pass: false,
        rin_pass: false,
        sora_decision: "SKIP",
        kibo_decision: "SKIP",
        yuzu_decision: "APPROVE",
        matty_decision: "SKIP",
        rekt_decision: "SKIP",
        opened_at: new Date().toISOString(),
        market_data: {
          proposal: {
            entry: yuzuPerpProposal.entry,
            stop: yuzuPerpProposal.stop,
            target: yuzuPerpProposal.target,
            rr: yuzuPerpProposal.riskReward,
            size: yuzuPerpProposal.simulatedSize,
          },
          perp: true,
          bayesian: {
            winProb: yuzuBayes.winProbability,
            confidence: yuzuBayes.edgeConfidence,
          },
        } as Record<string, unknown>,
      });

      await akiLogTrade("YUZU", "OPEN", 0, false);
      await updateSystemConfig(0, true, false);
      opened++;
      details.push({
        agent: "YUZU",
        symbol: perpSymbol,
        info: `PERP SCALP OPENED | ENTRY: ${yuzuPerpProposal.entry} | STOP: ${yuzuPerpProposal.stop} | TARGET: ${yuzuPerpProposal.target} | R/R: ${yuzuPerpProposal.riskReward.toFixed(2)}`,
      });
    }
  } else if (yuzuBayes.shouldTrade) {
    details.push({ agent: "YUZU", info: `Max positions (${yuzuMaxPositions}) reached` });
  } else {
    details.push({ agent: "YUZU", info: "Bayesian circuit breaker — not trading" });
  }

  // ── REKT: Scan Bybit linear perps for volatile coins ──
  // REKT gets its own dynamic watchlist of the most volatile perp coins,
  // completely separate from the spot watchlist the other agents use.
  // REKT also gets a dedicated risk budget carved out from the total,
  // so KIBO/YUZU can't starve it by consuming the entire team risk pool.
  const rektLeverage = 50;
  const rektMaxPositions = 5;
  const rektOpenCount = await countOpenTradesByAgent("REKT");
  if (rektOpenCount < rektMaxPositions && rektBayes.shouldTrade) {
    const topMovers = await fetchTopMoversPerp(50_000_000, 15);
    details.push({ agent: "REKT", info: `Scanning ${topMovers.length} volatile perps: ${topMovers.join(", ")} | Dedicated risk: ${rektRiskBudget.toFixed(2)}` });

    for (const perpSymbol of topMovers) {
      if (rektOpenCount + (await countOpenTradesByAgent("REKT")) >= rektMaxPositions) break;

      // Skip if REKT already has an open position on this symbol
      const { count: rektDup } = await supabase
        .from("paper_trades")
        .select("*", { count: "exact", head: true })
        .eq("status", "OPEN")
        .eq("agent_id", "REKT")
        .eq("symbol", perpSymbol);
      if (rektDup && rektDup > 0) continue;

      // Per-symbol learning
      const symbolCheck = await shouldTradeSymbol("REKT", perpSymbol);
      if (!symbolCheck.allowed) continue;

      // Fetch perp ticker for market data
      const perpTicker = await fetchTicker(perpSymbol, "linear");
      if (!perpTicker) continue;

      // Build a minimal MarketData for REKT from perp data
      const perpKlines1h = await fetchKlines(perpSymbol, "60", 100, "linear");
      if (perpKlines1h.length < 20) continue;

      const perpMarketData: MarketData = {
        ticker: perpTicker,
        klines: perpKlines1h,
        volatility: calcVolatility(perpKlines1h, 20),
        shortTermMove: perpKlines1h.length >= 10
          ? ((perpKlines1h[perpKlines1h.length - 1].close - perpKlines1h[perpKlines1h.length - 10].close) / perpKlines1h[perpKlines1h.length - 10].close) * 100
          : 0,
        volumeSpike: false,
        rsi: calcRSI(perpKlines1h, 14),
        sma20: calcSMA(perpKlines1h, 20),
        sma50: calcSMA(perpKlines1h, Math.min(50, perpKlines1h.length)),
        trendDirection: "SIDEWAYS",
        temporalScore: 0,
        hourUtc: new Date().getUTCHours(),
      };

      const rektProposal = await rektAgent(perpMarketData, rektBayes, maxDollarRiskPerTrade, perpSymbol, config.paper_balance, rektLeverage, genomes.REKT);
      if (!rektProposal || !isFeeViable(rektProposal.entry, rektProposal.target)) continue;

      // Check REKT's dedicated risk budget instead of the shared team risk pool
      const rektCurrentRisk = await getAgentRisk("REKT");
      if (rektCurrentRisk + rektProposal.maxDollarRisk > rektRiskBudget) {
        details.push({ agent: "REKT", symbol: perpSymbol, info: `REKT risk budget exceeded (${rektCurrentRisk.toFixed(2)}/${rektRiskBudget.toFixed(2)})` });
        break;
      }

      const tradeId = crypto.randomUUID();
      await supabase.from("paper_trades").insert({
        id: tradeId,
        agent_id: "REKT",
        symbol: perpSymbol,
        status: "OPEN",
        entry_price: rektProposal.entry,
        stop_price: rektProposal.stop,
        target_price: rektProposal.target,
        simulated_size: rektProposal.simulatedSize,
        max_dollar_risk: rektProposal.maxDollarRisk,
        liquidation_price: rektProposal.liquidationPrice,
        momo_pass: false,
        rin_pass: false,
        sora_decision: "SKIP",
        kibo_decision: "SKIP",
        yuzu_decision: "SKIP",
        matty_decision: "SKIP",
        rekt_decision: "APPROVE",
        opened_at: new Date().toISOString(),
        market_data: {
          proposal: {
            entry: rektProposal.entry,
            stop: rektProposal.stop,
            target: rektProposal.target,
            rr: rektProposal.riskReward,
            size: rektProposal.simulatedSize,
          },
          perp: true,
          bayesian: {
            winProb: rektBayes.winProbability,
            confidence: rektBayes.edgeConfidence,
          },
        } as Record<string, unknown>,
      });

      await akiLogTrade("REKT", "OPEN", 0, false);
      await updateSystemConfig(0, true, false);
      opened++;
      details.push({
        agent: "REKT",
        symbol: perpSymbol,
        info: `PERP SCALP OPENED | ENTRY: ${rektProposal.entry} | STOP: ${rektProposal.stop} | TARGET: ${rektProposal.target} | R/R: ${rektProposal.riskReward.toFixed(2)}`,
      });
    }
  } else if (rektBayes.shouldTrade) {
    details.push({ agent: "REKT", info: `Max positions (${rektMaxPositions}) reached` });
  } else {
    details.push({ agent: "REKT", info: "Bayesian circuit breaker — not trading" });
  }

  // ── MATTY: Also scan volatile perps for chart patterns ──
  // MATTY looks for double tops/bottoms, H&S, inverse H&S on 5m candles.
  // These patterns rarely form on large-cap spot coins (BTC, ETH) but
  // form frequently on volatile perps. Give MATTY its own scan of the
  // same top movers REKT uses, with its own position/risk limits.
  const mattyMaxPositions = maxPositionsPerAgent;
  const mattyOpenCount = await countOpenTradesByAgent("MATTY");
  if (mattyOpenCount < mattyMaxPositions && mattyBayes.shouldTrade) {
    const mattyMovers = await fetchTopMoversPerp(50_000_000, 10);
    details.push({ agent: "MATTY", info: `Scanning ${mattyMovers.length} volatile perps for patterns: ${mattyMovers.join(", ")} | Dedicated risk: ${mattyRiskBudget.toFixed(2)}` });

    for (const perpSymbol of mattyMovers) {
      if (mattyOpenCount + (await countOpenTradesByAgent("MATTY")) >= mattyMaxPositions) break;

      const { count: mattyDup } = await supabase
        .from("paper_trades")
        .select("*", { count: "exact", head: true })
        .eq("status", "OPEN")
        .eq("agent_id", "MATTY")
        .eq("symbol", perpSymbol);
      if (mattyDup && mattyDup > 0) continue;

      const symbolCheck = await shouldTradeSymbol("MATTY", perpSymbol);
      if (!symbolCheck.allowed) continue;

      const perpTicker = await fetchTicker(perpSymbol, "linear");
      if (!perpTicker) continue;

      const perpKlines1h = await fetchKlines(perpSymbol, "60", 100, "linear");
      if (perpKlines1h.length < 20) continue;

      const perpMarketData: MarketData = {
        ticker: perpTicker,
        klines: perpKlines1h,
        volatility: calcVolatility(perpKlines1h, 20),
        shortTermMove: perpKlines1h.length >= 10
          ? ((perpKlines1h[perpKlines1h.length - 1].close - perpKlines1h[perpKlines1h.length - 10].close) / perpKlines1h[perpKlines1h.length - 10].close) * 100
          : 0,
        volumeSpike: false,
        rsi: calcRSI(perpKlines1h, 14),
        sma20: calcSMA(perpKlines1h, 20),
        sma50: calcSMA(perpKlines1h, Math.min(50, perpKlines1h.length)),
        trendDirection: "SIDEWAYS",
        temporalScore: 0,
        hourUtc: new Date().getUTCHours(),
      };

      const mattyPerpLeverage = (config.leverage_tiers as Record<string, number>)?.[perpSymbol] || config.leverage || 10;
      const mattyPerpProposal = await mattyAgent(perpMarketData, mattyBayes, maxDollarRiskPerTrade, perpSymbol, config.paper_balance, mattyPerpLeverage, genomes.MATTY, "linear");
      if (!mattyPerpProposal || !isFeeViable(mattyPerpProposal.entry, mattyPerpProposal.target)) continue;

      // MATTY has its own dedicated risk budget (like REKT)
      const mattyCurrentRisk = await getAgentRisk("MATTY");
      if (mattyCurrentRisk + mattyPerpProposal.maxDollarRisk > mattyRiskBudget) {
        details.push({ agent: "MATTY", symbol: perpSymbol, info: `MATTY risk budget exceeded (${mattyCurrentRisk.toFixed(2)}/${mattyRiskBudget.toFixed(2)})` });
        break;
      }

      const mattyTradeId = crypto.randomUUID();
      await supabase.from("paper_trades").insert({
        id: mattyTradeId,
        agent_id: "MATTY",
        symbol: perpSymbol,
        status: "OPEN",
        entry_price: mattyPerpProposal.entry,
        stop_price: mattyPerpProposal.stop,
        target_price: mattyPerpProposal.target,
        simulated_size: mattyPerpProposal.simulatedSize,
        max_dollar_risk: mattyPerpProposal.maxDollarRisk,
        liquidation_price: mattyPerpProposal.liquidationPrice,
        momo_pass: false,
        rin_pass: false,
        sora_decision: "SKIP",
        kibo_decision: "SKIP",
        yuzu_decision: "SKIP",
        matty_decision: "APPROVE",
        rekt_decision: "SKIP",
        opened_at: new Date().toISOString(),
        market_data: {
          proposal: {
            entry: mattyPerpProposal.entry,
            stop: mattyPerpProposal.stop,
            target: mattyPerpProposal.target,
            rr: mattyPerpProposal.riskReward,
            size: mattyPerpProposal.simulatedSize,
          },
          perp: true,
          bayesian: {
            winProb: mattyBayes.winProbability,
            confidence: mattyBayes.edgeConfidence,
          },
        } as Record<string, unknown>,
      });

      await akiLogTrade("MATTY", "OPEN", 0, false);
      await updateSystemConfig(0, true, false);
      opened++;
      details.push({
        agent: "MATTY",
        symbol: perpSymbol,
        info: `PATTERN TRADE OPENED | ENTRY: ${mattyPerpProposal.entry} | STOP: ${mattyPerpProposal.stop} | TARGET: ${mattyPerpProposal.target} | R/R: ${mattyPerpProposal.riskReward.toFixed(2)}`,
      });
    }
  } else if (mattyBayes.shouldTrade) {
    details.push({ agent: "MATTY", info: `Max positions (${mattyMaxPositions}) reached` });
  } else {
    details.push({ agent: "MATTY", info: "Bayesian circuit breaker — not trading" });
  }

  // ── APEX: Autonomous Alpha Hunter ──
  // APEX cycles through 8+ technical strategies (MACD, Bollinger, EMA cross,
  // Stochastic, ADX, RSI divergence, momentum breakout, VWAP), learns which
  // ones produce wins, and allocates more capital to winning strategies.
  // All profits are reinvested (compounding). Risk scales with mission urgency.
  const apexMaxPositions = 5;
  const apexOpenCount = await countOpenTradesByAgent("APEX");

  // ── MIRAGE: Mirror Experiment Bot ──
  // Runs REKT's signal logic on the same coins with a neutral circuit breaker,
  // then flips every proposal to the opposite side with identical geometry.
  // Own fund (mirage_balance), own risk budget — P&L isolated from the team.
  const mirageLeverage = 50;
  const mirageMaxPositions = 5;
  const mirageBalance = config.mirage_balance ?? 100;
  const mirageRiskBudget = ((config.mirage_risk_pct ?? 15) / 100) * mirageBalance;
  const mirageOpenCount = await countOpenTradesByAgent("MIRAGE");
  if (mirageBalance > 0 && mirageOpenCount < mirageMaxPositions) {
    const mirageMovers = await fetchTopMoversPerp(50_000_000, 15);
    details.push({ agent: "MIRAGE", info: `Mirror scan: ${mirageMovers.length} volatile perps (same list as REKT) | Fund: ${mirageBalance.toFixed(2)} | Risk budget: ${mirageRiskBudget.toFixed(2)}` });

    for (const perpSymbol of mirageMovers) {
      if (mirageOpenCount + (await countOpenTradesByAgent("MIRAGE")) >= mirageMaxPositions) break;

      const { count: mirageDup } = await supabase
        .from("paper_trades")
        .select("*", { count: "exact", head: true })
        .eq("status", "OPEN")
        .eq("agent_id", "MIRAGE")
        .eq("symbol", perpSymbol);
      if (mirageDup && mirageDup > 0) continue;

      const symbolCheck = await shouldTradeSymbol("MIRAGE", perpSymbol);
      if (!symbolCheck.allowed) continue;

      const mirageTicker = await fetchTicker(perpSymbol, "linear");
      if (!mirageTicker) continue;

      const mirageKlines1h = await fetchKlines(perpSymbol, "60", 100, "linear");
      if (mirageKlines1h.length < 20) continue;

      const mirageMarketData: MarketData = {
        ticker: mirageTicker,
        klines: mirageKlines1h,
        volatility: calcVolatility(mirageKlines1h, 20),
        shortTermMove: mirageKlines1h.length >= 10
          ? ((mirageKlines1h[mirageKlines1h.length - 1].close - mirageKlines1h[mirageKlines1h.length - 10].close) / mirageKlines1h[mirageKlines1h.length - 10].close) * 100
          : 0,
        volumeSpike: false,
        rsi: calcRSI(mirageKlines1h, 14),
        sma20: calcSMA(mirageKlines1h, 20),
        sma50: calcSMA(mirageKlines1h, Math.min(50, mirageKlines1h.length)),
        trendDirection: "SIDEWAYS",
        temporalScore: 0,
        hourUtc: new Date().getUTCHours(),
      };

      const mirageProposal = await mirageFromRekt(mirageMarketData, perpSymbol, mirageBalance, maxDollarRiskPerTrade, genomes.REKT, mirageLeverage);
      if (!mirageProposal) continue;

      const mirageCurrentRisk = await getAgentRisk("MIRAGE");
      if (mirageCurrentRisk + mirageProposal.maxDollarRisk > mirageRiskBudget) {
        details.push({ agent: "MIRAGE", symbol: perpSymbol, info: `MIRAGE risk budget exceeded (${mirageCurrentRisk.toFixed(2)}/${mirageRiskBudget.toFixed(2)})` });
        break;
      }

      const mirageTradeId = crypto.randomUUID();
      const mirageReason = (mirageProposal as TradeProposal & { _mirrorReason?: string })._mirrorReason || "";
      await supabase.from("paper_trades").insert({
        id: mirageTradeId,
        agent_id: "MIRAGE",
        symbol: perpSymbol,
        status: "OPEN",
        entry_price: mirageProposal.entry,
        stop_price: mirageProposal.stop,
        target_price: mirageProposal.target,
        simulated_size: mirageProposal.simulatedSize,
        max_dollar_risk: mirageProposal.maxDollarRisk,
        liquidation_price: mirageProposal.liquidationPrice,
        momo_pass: false,
        rin_pass: false,
        sora_decision: "SKIP",
        kibo_decision: "SKIP",
        yuzu_decision: "SKIP",
        matty_decision: "SKIP",
        rekt_decision: "SKIP",
        apex_decision: "SKIP",
        opened_at: new Date().toISOString(),
        market_data: {
          proposal: {
            entry: mirageProposal.entry,
            stop: mirageProposal.stop,
            target: mirageProposal.target,
            rr: mirageProposal.riskReward,
            size: mirageProposal.simulatedSize,
          },
          perp: true,
          mirrored_from: "REKT",
          mirror_reason: mirageReason,
        } as Record<string, unknown>,
      });

      await akiLogTrade("MIRAGE", "OPEN", 0, false);
      opened++;
      details.push({
        agent: "MIRAGE",
        symbol: perpSymbol,
        info: `MIRRORED ${mirageProposal.direction} OPENED | ENTRY: ${mirageProposal.entry} | STOP: ${mirageProposal.stop} | TARGET: ${mirageProposal.target} | R/R: ${mirageProposal.riskReward.toFixed(2)} | ${mirageReason}`,
      });
    }
  } else if (mirageBalance > 0) {
    details.push({ agent: "MIRAGE", info: `Max positions (${mirageMaxPositions}) reached` });
  } else {
    details.push({ agent: "MIRAGE", info: "Fund depleted — not trading" });
  }

  // ── APEX scan continues below ──
  const apexStrategyStats = await loadStrategyStats();
  if (apexOpenCount < apexMaxPositions && apexBayes.shouldTrade) {
    const startDate = config.apex_start_date ? new Date(config.apex_start_date) : new Date();
    const endDate = config.apex_end_date ? new Date(config.apex_end_date) : new Date(Date.now() + 17 * 24 * 60 * 60 * 1000);
    const totalDays = Math.max(1, (endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
    const daysElapsed = Math.max(0, (Date.now() - startDate.getTime()) / (1000 * 60 * 60 * 24));
    const daysLeft = Math.max(0, totalDays - daysElapsed);
    const urgency = Math.min(1, daysElapsed / totalDays);

    const startBalance = config.apex_start_balance ?? 50;
    const targetBalance = config.apex_target_balance ?? 5000;
    const apexBalance = (config.apex_compound_balance ?? startBalance) + (config.total_team_pnl ?? 0) * 0.1;
    const progress = Math.min(1, Math.max(0, (apexBalance - startBalance) / (targetBalance - startBalance)));
    const urgencyMultiplier = 1 + urgency * 1.0 * (1 - progress * 0.5);

    const apexPerpMovers = await fetchTopMoversPerp(50_000_000, 10);
    const apexScanList = [...watchlist.slice(0, 5), ...apexPerpMovers];
    const apexUnique = [...new Set(apexScanList)];

    const activeStrats = apexStrategyStats.filter(s => !s.cooldown_until || new Date(s.cooldown_until).getTime() < Date.now());
    const avgExpectancy = activeStrats.length > 0
      ? activeStrats.reduce((a, s) => a + (s.expectancy ?? 0), 0) / activeStrats.length
      : 0;

    details.push({
      agent: "APEX",
      info: `Mission: ${startBalance} → ${targetBalance} | Balance: ${apexBalance.toFixed(2)} | ${daysLeft.toFixed(0)}d left | Urgency: ${(urgency * 100).toFixed(0)}% | Risk: ${urgencyMultiplier.toFixed(2)}x | ${activeStrats.length} strategies active | Avg expectancy: ${avgExpectancy.toFixed(3)} | Scanning ${apexUnique.length} symbols`,
    });

    for (const scanSymbol of apexUnique) {
      if (apexOpenCount + (await countOpenTradesByAgent("APEX")) >= apexMaxPositions) break;

      const isPerp = apexPerpMovers.includes(scanSymbol);
      const cat = isPerp ? "linear" : "spot";

      const { count: apexDup } = await supabase
        .from("paper_trades")
        .select("*", { count: "exact", head: true })
        .eq("status", "OPEN")
        .eq("agent_id", "APEX")
        .eq("symbol", scanSymbol);
      if (apexDup && apexDup > 0) continue;

      const symbolCheck = await shouldTradeSymbol("APEX", scanSymbol);
      if (!symbolCheck.allowed) continue;

      const scanTicker = await fetchTicker(scanSymbol, cat);
      if (!scanTicker) continue;

      const scanKlines1h = await fetchKlines(scanSymbol, "60", 100, cat);
      if (scanKlines1h.length < 20) continue;

      const scanMarketData: MarketData = {
        ticker: scanTicker,
        klines: scanKlines1h,
        volatility: calcVolatility(scanKlines1h, 20),
        shortTermMove: scanKlines1h.length >= 10
          ? ((scanKlines1h[scanKlines1h.length - 1].close - scanKlines1h[scanKlines1h.length - 10].close) / scanKlines1h[scanKlines1h.length - 10].close) * 100
          : 0,
        volumeSpike: false,
        rsi: calcRSI(scanKlines1h, 14),
        sma20: calcSMA(scanKlines1h, 20),
        sma50: calcSMA(scanKlines1h, Math.min(50, scanKlines1h.length)),
        trendDirection: "SIDEWAYS",
        temporalScore: 0,
        hourUtc: new Date().getUTCHours(),
      };

      const apexLeverage = apexLeverageForSymbol(scanSymbol, isPerp);
      const apexRiskPerTrade = (apexBalanceForBudget * 0.03) * urgencyMultiplier;
      const apexProposal = await apexAgent(scanMarketData, apexBayes, apexRiskPerTrade, scanSymbol, apexBalanceForBudget, apexLeverage, genomes.APEX, cat, apexStrategyStats);
      if (!apexProposal || !isFeeViable(apexProposal.entry, apexProposal.target)) continue;
      scopeStopInPlace(apexProposal);

      const apexCurrentRisk = await getAgentRisk("APEX");
      if (apexCurrentRisk + apexProposal.maxDollarRisk > apexRiskBudget) {
        details.push({ agent: "APEX", symbol: scanSymbol, info: `APEX risk budget exceeded (${apexCurrentRisk.toFixed(2)}/${apexRiskBudget.toFixed(2)})` });
        break;
      }

      const apexTradeId = crypto.randomUUID();
      const apexReason = (apexProposal as TradeProposal & { _apexReason?: string })._apexReason || "";
      const apexStrategy = apexProposal.strategy;
      await supabase.from("paper_trades").insert({
        id: apexTradeId,
        agent_id: "APEX",
        symbol: scanSymbol,
        status: "OPEN",
        entry_price: apexProposal.entry,
        stop_price: apexProposal.stop,
        target_price: apexProposal.target,
        simulated_size: apexProposal.simulatedSize,
        max_dollar_risk: apexProposal.maxDollarRisk,
        liquidation_price: apexProposal.liquidationPrice,
        momo_pass: false,
        rin_pass: false,
        sora_decision: "SKIP",
        kibo_decision: "SKIP",
        yuzu_decision: "SKIP",
        matty_decision: "SKIP",
        rekt_decision: "SKIP",
        apex_decision: "APPROVE",
        opened_at: new Date().toISOString(),
        market_data: {
          proposal: {
            entry: apexProposal.entry,
            stop: apexProposal.stop,
            target: apexProposal.target,
            rr: apexProposal.riskReward,
            size: apexProposal.simulatedSize,
          },
          perp: isPerp,
          strategy: apexStrategy,
          final_direction: apexProposal.direction,
          signal_reversed: apexReason.includes("INTENTIONAL GENOME REVERSAL"),
          reason: apexReason,
          htf_trend: (apexProposal as TradeProposal & { _apexTrend?: string })._apexTrend || null,
          mission: {
            urgency: urgency.toFixed(2),
            riskMultiplier: urgencyMultiplier.toFixed(2),
            daysLeft: daysLeft.toFixed(0),
            progress: progress.toFixed(2),
            balance: apexBalance.toFixed(2),
          },
          bayesian: {
            winProb: apexBayes.winProbability,
            confidence: apexBayes.edgeConfidence,
          },
        } as Record<string, unknown>,
      });

      await supabase.from("apex_strategy_stats")
        .update({ last_used_at: new Date().toISOString() })
        .eq("strategy", apexStrategy);

      await akiLogTrade("APEX", "OPEN", 0, false);
      await updateSystemConfig(0, true, false);
      opened++;
      details.push({
        agent: "APEX",
        symbol: scanSymbol,
        info: `${apexStrategy} ${apexProposal.direction} | ENTRY: ${apexProposal.entry} | STOP: ${apexProposal.stop} | TARGET: ${apexProposal.target} | R/R: ${apexProposal.riskReward.toFixed(2)} | Risk: ${apexProposal.maxDollarRisk.toFixed(2)} (${urgencyMultiplier.toFixed(1)}x) | ${isPerp ? "PERP" : "SPOT"}`,
      });
    }
  } else if (apexBayes.shouldTrade) {
    details.push({ agent: "APEX", info: `Max positions (${apexMaxPositions}) reached` });
  } else {
    details.push({ agent: "APEX", info: "Bayesian circuit breaker — not trading" });
  }

  return { opened, closed, blocked, details };
}

// ──────────────────────────────────────────────
// HTTP handler
// ──────────────────────────────────────────────

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const runId = crypto.randomUUID();
    const startedAt = new Date().toISOString();

    await supabase.from("run_log").insert({
      id: runId,
      started_at: startedAt,
      status: "RUNNING",
    });

    const result = await runPipeline();

    await supabase
      .from("run_log")
      .update({
        completed_at: new Date().toISOString(),
        status: "SUCCESS",
        trades_opened: result.opened,
        trades_closed: result.closed,
        trades_blocked: result.blocked,
        cycles_completed: 1,
        summary: { details: result.details.slice(-20) },
      })
      .eq("id", runId);

    return new Response(
      JSON.stringify({
        success: true,
        runId,
        opened: result.opened,
        closed: result.closed,
        blocked: result.blocked,
        details: result.details.slice(-10),
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message, success: false }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
