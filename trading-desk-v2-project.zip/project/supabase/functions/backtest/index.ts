import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY, {
  auth: { persistSession: false },
});

// Taker fee per side, charged on notional (Bybit linear perps)
const TAKER_FEE_RATE = 0.00055;

// ──────────────────────────────────────────────
// Types
// ──────────────────────────────────────────────

interface Kline {
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  time: number;
}

interface BacktestTrade {
  agent: string;
  symbol: string;
  entry: number;
  stop: number;
  target: number;
  exit: number;
  pnl: number;
  pnlPct: number;
  result: "WIN" | "LOSS" | "TIMEOUT";
  entryTime: number;
  exitTime: number;
  reason: string;
  rr: number;
}

interface BacktestSummary {
  agent_id: string;
  symbol: string;
  period_days: number;
  total_trades: number;
  wins: number;
  losses: number;
  blocked: number;
  win_rate: number;
  total_pnl: number;
  avg_win: number;
  avg_loss: number;
  biggest_win: number;
  biggest_loss: number;
  max_drawdown: number;
  profit_factor: number;
  sharpe_ratio: number;
  trades_json: BacktestTrade[];
}

interface Genome {
  [key: string]: number;
}

interface GenomeRow {
  id: string;
  agent_id: string;
  generation: number;
  genome: Genome;
  fitness_score: number;
  total_pnl: number;
  total_trades: number;
  win_rate: number;
  profit_factor: number;
  is_champion: boolean;
  parent_id: string | null;
  mutation_notes: string | null;
  created_at: string;
  live_pnl: number;
  composite_score: number;
}

// ──────────────────────────────────────────────
// Market data — fetch historical klines from Bybit
// ──────────────────────────────────────────────

async function fetchKlines(symbol: string, interval: string, limit: number, category: string = "spot"): Promise<Kline[]> {
  const cacheKey = `${category}:${symbol}:${interval}:${limit}`;
  const cached = klineCache.get(cacheKey);
  if (cached && Date.now() - cached.fetchedAt < KLINE_CACHE_TTL_MS) return cached.klines;

  const toOkxBar = (i: string) => ({ "60": "1H", "5": "5m", "1": "1m" } as Record<string, string>)[i] || "1H";
  const toOkxInst = (s: string) => s.replace(/USDT$/, "-USDT-SWAP");
  const toBinanceInterval = (i: string) => ({ "60": "1h", "5": "5m", "1": "1m" } as Record<string, string>)[i] || "1h";

  const tryBinanceVision = async (): Promise<Kline[]> => {
    try {
      const res = await fetch(`https://data-api.binance.vision/api/v3/klines?symbol=${symbol}&interval=${toBinanceInterval(interval)}&limit=${limit}`);
      if (!res.ok) return [];
      const json = await res.json();
      if (!Array.isArray(json)) return [];
      return json.map((k: (string | number)[]) => ({
        time: Number(k[0]),
        open: parseFloat(String(k[1])),
        high: parseFloat(String(k[2])),
        low: parseFloat(String(k[3])),
        close: parseFloat(String(k[4])),
        volume: parseFloat(String(k[5])),
      }));
    } catch {
      return [];
    }
  };

  const tryOkx = async (): Promise<Kline[]> => {
    try {
      const res = await fetch(`https://www.okx.com/api/v5/market/candles?instId=${toOkxInst(symbol)}&bar=${toOkxBar(interval)}&limit=${Math.min(limit, 300)}`);
      if (!res.ok) return [];
      const json = await res.json();
      const list = json?.data;
      if (!Array.isArray(list)) return [];
      return list
        .map((k: string[]) => ({
          time: parseInt(k[0]),
          open: parseFloat(k[1]),
          high: parseFloat(k[2]),
          low: parseFloat(k[3]),
          close: parseFloat(k[4]),
          volume: parseFloat(k[5]),
        }))
        .sort((a: Kline, b: Kline) => a.time - b.time);
    } catch {
      return [];
    }
  };

  // 1) Bybit (primary)
  const urls = [
    `https://api.bybit.com/v5/market/kline?category=${category}&symbol=${symbol}&interval=${interval}&limit=${limit}`,
    `https://api.bytick.com/v5/market/kline?category=${category}&symbol=${symbol}&interval=${interval}&limit=${limit}`,
  ];
  for (const url of urls) {
    try {
      const res = await fetch(url);
      if (!res.ok) continue;
      const json = await res.json();
      const list = json?.result?.list;
      if (!Array.isArray(list)) continue;
      const parsed = list
        .map((k: string[]) => ({
          time: parseInt(k[0]),
          open: parseFloat(k[1]),
          high: parseFloat(k[2]),
          low: parseFloat(k[3]),
          close: parseFloat(k[4]),
          volume: parseFloat(k[5]),
        }))
        .sort((a: Kline, b: Kline) => a.time - b.time);
      klineCache.set(cacheKey, { klines: parsed, fetchedAt: Date.now() });
      return parsed;
    } catch {
      continue;
    }
  }

  // 2-3) Fallbacks
  const binanceKlines = await tryBinanceVision();
  if (binanceKlines.length > 0) {
    klineCache.set(cacheKey, { klines: binanceKlines, fetchedAt: Date.now() });
    return binanceKlines;
  }
  const okxKlines = await tryOkx();
  if (okxKlines.length > 0) {
    klineCache.set(cacheKey, { klines: okxKlines, fetchedAt: Date.now() });
    return okxKlines;
  }
  return [];
}

// Pure performance cache — a reset just means re-downloading candles, never a correctness issue
const klineCache = new Map<string, { klines: Kline[]; fetchedAt: number }>();
const KLINE_CACHE_TTL_MS = 10 * 60 * 1000;

// ──────────────────────────────────────────────
// Scan Bybit linear perps for most volatile coins by 24h price change
// ──────────────────────────────────────────────

async function fetchTopMoversPerp(minVolumeUsd: number = 50_000_000, maxResults: number = 15): Promise<string[]> {
  const urls = [
    "https://api.bybit.com/v5/market/tickers?category=linear",
    "https://api.bytick.com/v5/market/tickers?category=linear",
  ];
  for (const url of urls) {
    try {
      const res = await fetch(url);
      if (!res.ok) continue;
      const json = await res.json();
      const list = json?.result?.list;
      if (!Array.isArray(list)) continue;

      return list
        .map((t: Record<string, string>) => ({
          symbol: t.symbol,
          turnover24h: parseFloat(t.turnover24h),
          priceChangePct: Math.abs(parseFloat(t.price24hPcnt) * 100),
        }))
        .filter((t: { symbol: string; turnover24h: number; priceChangePct: number }) =>
          t.symbol.endsWith("USDT") &&
          !t.symbol.includes("PERP") &&
          t.turnover24h >= minVolumeUsd &&
          t.priceChangePct > 0
        )
        .sort((a: { priceChangePct: number }, b: { priceChangePct: number }) => b.priceChangePct - a.priceChangePct)
        .slice(0, maxResults)
        .map((t: { symbol: string }) => t.symbol);
    } catch {
      continue;
    }
  }

  // OKX fallback: linear perp tickers, instId like BTC-USDT-SWAP
  try {
    const res = await fetch("https://www.okx.com/api/v5/market/tickers?instType=SWAP");
    if (res.ok) {
      const json = await res.json();
      const list = json?.data;
      if (Array.isArray(list)) {
        return list
          .map((t: Record<string, string>) => ({
            symbol: String(t.instId || "").replace(/-USDT-SWAP$/, "USDT"),
            quoteVolume24h: parseFloat(t.volCcy24h || "0"),
            last: parseFloat(t.last || "0"),
            open24h: parseFloat(t.open24h || "0"),
          }))
          .filter((t: { symbol: string; quoteVolume24h: number; last: number; open24h: number }) =>
            t.symbol.endsWith("USDT") &&
            t.quoteVolume24h >= minVolumeUsd &&
            t.last > 0 && t.open24h > 0
          )
          .map((t: { symbol: string; quoteVolume24h: number; last: number; open24h: number }) => ({
            symbol: t.symbol,
            quoteVolume24h: t.quoteVolume24h,
            priceChangePct: Math.abs(((t.last - t.open24h) / t.open24h) * 100),
          }))
          .sort((a: { priceChangePct: number }, b: { priceChangePct: number }) => b.priceChangePct - a.priceChangePct)
          .slice(0, maxResults)
          .map((t: { symbol: string }) => t.symbol);
      }
    }
  } catch {
    // fall through
  }
  return [];
}

// ──────────────────────────────────────────────
// Indicators
// ──────────────────────────────────────────────

function calcRSI(klines: Kline[], period: number, endIndex: number): number {
  if (endIndex < period) return 50;
  let gains = 0;
  let losses = 0;
  for (let i = endIndex - period + 1; i <= endIndex; i++) {
    const change = klines[i].close - klines[i - 1].close;
    if (change >= 0) gains += change;
    else losses -= change;
  }
  const avgGain = gains / period;
  const avgLoss = losses / period;
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - 100 / (1 + rs);
}

function calcSMA(klines: Kline[], period: number, endIndex: number): number {
  if (endIndex < period - 1) return klines[endIndex]?.close ?? 0;
  let sum = 0;
  for (let i = endIndex - period + 1; i <= endIndex; i++) {
    sum += klines[i].close;
  }
  return sum / period;
}

function calcVolatility(klines: Kline[], period: number, endIndex: number): number {
  if (endIndex < period) return 0;
  const returns: number[] = [];
  for (let i = endIndex - period + 1; i <= endIndex; i++) {
    if (klines[i - 1].close > 0) {
      returns.push((klines[i].close - klines[i - 1].close) / klines[i - 1].close);
    }
  }
  const mean = returns.reduce((a, b) => a + b, 0) / returns.length;
  const variance = returns.reduce((a, b) => a + (b - mean) ** 2, 0) / returns.length;
  return Math.sqrt(variance) * 100;
}

// ──────────────────────────────────────────────
// RIN — Whale Activity (backtest version)
// ──────────────────────────────────────────────

function rinBacktest(klines: Kline[], i: number): { pass: boolean; reason: string } {
  if (i < 10) return { pass: false, reason: "Not enough data" };

  const recentKlines = klines.slice(i - 9, i + 1);
  const recentVolumes = recentKlines.map((k) => k.volume);
  const avgVol = recentVolumes.reduce((a, b) => a + b, 0) / recentVolumes.length;
  const lastVol = recentVolumes[recentVolumes.length - 1];
  const volRatio = avgVol > 0 ? lastVol / avgVol : 1;

  const aboveAvgCount = recentVolumes.filter((v) => v > avgVol * 1.5).length;
  const activityClustered = aboveAvgCount >= 3;

  const extremeVolumeSpike = volRatio > 5;
  const rsi = calcRSI(klines, 14, i);
  const sma20 = calcSMA(klines, 20, i);
  const sma50 = calcSMA(klines, Math.min(50, i + 1), i);
  let trendDirection: "UP" | "DOWN" | "SIDEWAYS" = "SIDEWAYS";
  if (sma20 > sma50 * 1.002) trendDirection = "UP";
  else if (sma20 < sma50 * 0.998) trendDirection = "DOWN";

  const dangerousOverbought = rsi > 80 && extremeVolumeSpike;
  const dangerousOversold = rsi < 20 && extremeVolumeSpike;
  const manipulationRisk = extremeVolumeSpike && trendDirection === "SIDEWAYS";

  const passSignal = !dangerousOverbought && !dangerousOversold && !manipulationRisk;

  let walletsOfInterest = "Normal activity";
  if (extremeVolumeSpike) walletsOfInterest = "Extreme volume spike — whale likely";
  else if (volRatio > 2) walletsOfInterest = "Volume spike detected";
  else if (activityClustered) walletsOfInterest = "Clustered volume above average";

  return {
    pass: passSignal,
    reason: `WALLETS: ${walletsOfInterest} | VOL RATIO: ${volRatio.toFixed(2)}x | CLUSTERED: ${activityClustered}`,
  };
}

// ──────────────────────────────────────────────
// MOMO — Quality filter (backtest version)
// ──────────────────────────────────────────────

function momoBacktest(klines: Kline[], i: number): boolean {
  if (i < 20) return false;
  const volatility = calcVolatility(klines, 20, i);

  const recentKlines = klines.slice(Math.max(0, i - 20), i + 1);
  const avgVolume = recentKlines.reduce((a, b) => a + b.volume, 0) / recentKlines.length;
  const quoteVolume = avgVolume * klines[i].close;

  const liquidityScore = Math.min(100, Math.log10(quoteVolume + 1) * 12);
  const volumeHealthy = quoteVolume > 500000;
  const volatilityOk = volatility < 8;

  const lookback = Math.min(24, i);
  const priceChange = lookback > 0
    ? ((klines[i].close - klines[i - lookback].close) / klines[i - lookback].close) * 100
    : 0;
  const notPumped = Math.abs(priceChange) < 15;

  return liquidityScore > 40 && volumeHealthy && volatilityOk && notPumped;
}

// ──────────────────────────────────────────────
// SORA — Risk gate (backtest version)
// ──────────────────────────────────────────────

function soraBacktest(klines: Kline[], i: number, entry: number, stop: number): boolean {
  const shortTermMove = i >= 10
    ? ((klines[i].close - klines[i - 9].close) / klines[i - 9].close) * 100
    : 0;
  const extremeMove = Math.abs(shortTermMove) > 15;
  const rsi = calcRSI(klines, 14, i);
  const overbought = rsi > 82;
  const oversold = rsi < 18;
  const volatility = calcVolatility(klines, 20, i);
  const tooVolatile = volatility > 12;

  const stopDistance = Math.abs(entry - stop);
  const stopPct = entry > 0 ? (stopDistance / entry) * 100 : 0;
  const stopClear = stopPct > 0.5 && stopPct < 8;

  const volumeSpike = i >= 20 && klines[i].volume > (klines.slice(i - 19, i + 1).reduce((a, b) => a + b.volume, 0) / 20) * 2;
  const hypeDriven = volumeSpike && extremeMove;

  const isLong = stop < entry;

  return !extremeMove && !tooVolatile && stopClear && !hypeDriven &&
    !(overbought && isLong) && !(oversold && isLong);
}

// ──────────────────────────────────────────────
// KIBO — Big setup agent (genome-driven)
// ──────────────────────────────────────────────

function kiboBacktest(klines: Kline[], i: number, g: Genome): { entry: number; stop: number; target: number; rr: number } | null {
  const sma20 = calcSMA(klines, 20, i);
  const sma50 = calcSMA(klines, Math.min(50, i + 1), i);
  let trendDirection: "UP" | "DOWN" | "SIDEWAYS" = "SIDEWAYS";
  if (sma20 > sma50 * (1 + g.trend_threshold)) trendDirection = "UP";
  else if (sma20 < sma50 * (1 - g.trend_threshold)) trendDirection = "DOWN";

  if (trendDirection === "SIDEWAYS") return null;

  const price = klines[i].close;
  const rsi = calcRSI(klines, 14, i);
  let entry: number, stop: number, target: number;

  if (trendDirection === "UP") {
    entry = price;
    stop = Math.min(sma50 * g.long_stop_sma50_mult, klines[i].low * g.long_stop_low_mult);
    const risk = entry - stop;
    if (risk <= 0) return null;
    target = entry + risk * g.long_target_rr;
  } else {
    if (rsi > g.short_rsi_max) return null;
    entry = price;
    stop = price * g.short_stop_pct;
    const risk = stop - entry;
    if (risk <= 0) return null;
    target = entry - risk * g.short_target_rr;
  }

  const risk = Math.abs(entry - stop);
  const reward = Math.abs(target - entry);
  const rr = risk > 0 ? reward / risk : 0;
  if (rr < g.min_rr) return null;

  return { entry, stop, target, rr };
}

// ──────────────────────────────────────────────
// YUZU — Small-win scalper (genome-driven)
// ──────────────────────────────────────────────

function yuzuBacktest(klines: Kline[], i: number, g: Genome): { entry: number; stop: number; target: number; rr: number } | null {
  const sma20 = calcSMA(klines, 20, i);
  const sma50 = calcSMA(klines, Math.min(50, i + 1), i);
  let trendDirection: "UP" | "DOWN" | "SIDEWAYS" = "SIDEWAYS";
  if (sma20 > sma50 * (1 + g.trend_threshold)) trendDirection = "UP";
  else if (sma20 < sma50 * (1 - g.trend_threshold)) trendDirection = "DOWN";

  if (trendDirection === "SIDEWAYS") return null;

  const price = klines[i].close;
  const rsi = calcRSI(klines, 14, i);
  let entry: number, stop: number, target: number;

  if (trendDirection === "UP") {
    entry = price;
    stop = klines[i].low * g.long_stop_low_mult;
    const risk = entry - stop;
    if (risk <= 0) return null;
    target = entry + risk * g.long_target_rr;
  } else {
    if (rsi > g.short_rsi_max) return null;
    entry = price;
    stop = price * g.short_stop_pct;
    const risk = stop - entry;
    if (risk <= 0) return null;
    target = entry - risk * g.short_target_rr;
  }

  const risk = Math.abs(entry - stop);
  const reward = Math.abs(target - entry);
  const rr = risk > 0 ? reward / risk : 0;
  if (rr < g.min_rr) return null;

  return { entry, stop, target, rr };
}

// ──────────────────────────────────────────────
// MATTY — Mean-Reversion Reversal Bot (genome-driven)
// ──────────────────────────────────────────────

function calcEMABt(klines: Kline[], period: number, endIndex: number): number {
  if (endIndex < period) return klines[endIndex]?.close ?? 0;
  const k = 2 / (period + 1);
  let ema = klines[endIndex - period + 1].close;
  for (let i = endIndex - period + 2; i <= endIndex; i++) {
    ema = klines[i].close * k + ema * (1 - k);
  }
  return ema;
}

function calcBollingerBandsBt(klines: Kline[], period: number, endIndex: number, stdDev: number = 2): { upper: number; mid: number; lower: number } {
  if (endIndex < period - 1) {
    const c = klines[endIndex]?.close ?? 0;
    return { upper: c, mid: c, lower: c };
  }
  let sum = 0;
  for (let i = endIndex - period + 1; i <= endIndex; i++) sum += klines[i].close;
  const mid = sum / period;
  let variance = 0;
  for (let i = endIndex - period + 1; i <= endIndex; i++) variance += (klines[i].close - mid) ** 2;
  const sd = Math.sqrt(variance / period);
  return { upper: mid + stdDev * sd, mid, lower: mid - stdDev * sd };
}

function rektBacktest(klines: Kline[], i: number, g: Genome): { entry: number; stop: number; target: number; rr: number; reason: string; direction: "LONG" | "SHORT" } | null {
  if (i < 30) return null;

  const price = klines[i].close;
  const rsi = calcRSI(klines, 14, i);

  // Momentum: price change over last 5 candles as %
  const lookback = Math.min(5, i);
  const pastPrice = klines[i - lookback].close;
  const momentumPct = pastPrice > 0 ? ((price - pastPrice) / pastPrice) * 100 : 0;
  const absMomentum = Math.abs(momentumPct);

  // Trend: SMA(20) slope as %
  const sma20 = calcSMA(klines, 20, i);
  const sma20Prev = calcSMA(klines, 20, i - 3);
  const trendPct = sma20Prev > 0 ? ((sma20 - sma20Prev) / sma20Prev) * 100 : 0;

  let direction: "LONG" | "SHORT" | null = null;
  let reason = "";

  // LONG: bullish momentum + RSI in bullish range (not overbought) + uptrend
  if (
    momentumPct >= g.min_momentum &&
    rsi >= g.min_rsi_long && rsi <= g.max_rsi_long &&
    trendPct >= g.trend_threshold
  ) {
    direction = "LONG";
    reason = `Momentum LONG | Move ${momentumPct.toFixed(2)}% over 5 bars | RSI ${rsi.toFixed(0)} | Trend ${trendPct.toFixed(3)}%`;
  }
  // SHORT: bearish momentum + RSI in bearish range (not oversold) + downtrend
  else if (
    -momentumPct >= g.min_momentum &&
    rsi >= g.min_rsi_short && rsi <= g.max_rsi_short &&
    trendPct <= -g.trend_threshold
  ) {
    direction = "SHORT";
    reason = `Momentum SHORT | Move ${momentumPct.toFixed(2)}% over 5 bars | RSI ${rsi.toFixed(0)} | Trend ${trendPct.toFixed(3)}%`;
  }

  if (!direction) return null;

  // Wide momentum stop based on recent volatility
  const recentCandles = klines.slice(Math.max(0, i - 10), i);
  const recentHigh = Math.max(...recentCandles.map(k => k.high));
  const recentLow = Math.min(...recentCandles.map(k => k.low));
  const candleRangePct = price > 0 ? ((recentHigh - recentLow) / price) * 100 : 0;
  const stopPct = Math.min(g.max_stop_pct, Math.max(g.min_stop_pct, candleRangePct * 0.9));

  let entry: number, stop: number, target: number;
  if (direction === "LONG") {
    entry = price;
    stop = price * (1 - stopPct / 100);
    const risk = entry - stop;
    if (risk <= 0) return null;
    target = entry + risk * g.target_rr;
  } else {
    entry = price;
    stop = price * (1 + stopPct / 100);
    const risk = stop - entry;
    if (risk <= 0) return null;
    target = entry - risk * g.target_rr;
  }

  const risk = Math.abs(entry - stop);
  const reward = Math.abs(target - entry);
  const rr = risk > 0 ? reward / risk : 0;
  if (rr < g.min_rr) return null;

  return { entry, stop, target, rr, direction, reason };
}

function findSwings(klines: Kline[], i: number, lookback: number, threshold: number): { highs: { idx: number; price: number }[]; lows: { idx: number; price: number }[] } {
  const highs: { idx: number; price: number }[] = [];
  const lows: { idx: number; price: number }[] = [];
  const start = Math.max(0, i - lookback);
  for (let j = start + 2; j <= i - 2; j++) {
    if (klines[j].high > klines[j - 1].high && klines[j].high > klines[j + 1].high && klines[j].high >= klines[j - 2].high && klines[j].high >= klines[j + 2].high) {
      highs.push({ idx: j, price: klines[j].high });
    }
    if (klines[j].low < klines[j - 1].low && klines[j].low < klines[j + 1].low && klines[j].low <= klines[j - 2].low && klines[j].low <= klines[j + 2].low) {
      lows.push({ idx: j, price: klines[j].low });
    }
  }
  return { highs, lows };
}

function mattyBacktest(klines: Kline[], i: number, g: Genome): { entry: number; stop: number; target: number; rr: number; reason: string } | null {
  if (i < 60) return null;

  const price = klines[i].close;
  const rsi = calcRSI(klines, 14, i);
  const bb = calcBollingerBandsBt(klines, 20, i, 2);
  const swings = findSwings(klines, i, Math.round(g.pattern_lookback), g.pattern_tolerance / 100);

  let direction: "LONG" | "SHORT" | null = null;
  let reason = "";
  let stopRef = price;

  // ── Double Top (SHORT) ──
  // Two highs within tolerance of each other, second high slightly lower or equal
  if (swings.highs.length >= 2) {
    const h1 = swings.highs[swings.highs.length - 2];
    const h2 = swings.highs[swings.highs.length - 1];
    const peakDiff = Math.abs(h1.price - h2.price) / Math.max(h1.price, h2.price);
    const valleyLow = Math.min(...klines.slice(h1.idx, h2.idx).map(k => k.low));
    const patternHeight = Math.max(h1.price, h2.price) - valleyLow;
    const neckline = valleyLow;

    if (peakDiff <= g.pattern_tolerance / 100 && patternHeight > 0 && h2.idx >= i - 10) {
      // Confirmation: current candle breaks below neckline
      if (price < neckline && rsi < 55) {
        direction = "SHORT";
        stopRef = Math.max(h1.price, h2.price);
        reason = `Double Top SHORT | Peaks ${h1.price.toFixed(4)}/${h2.price.toFixed(4)} (${(peakDiff * 100).toFixed(1)}% diff) | Neckline ${neckline.toFixed(4)} | RSI ${rsi.toFixed(0)}`;
      }
    }
  }

  // ── Double Bottom (LONG) ──
  if (!direction && swings.lows.length >= 2) {
    const l1 = swings.lows[swings.lows.length - 2];
    const l2 = swings.lows[swings.lows.length - 1];
    const lowDiff = Math.abs(l1.price - l2.price) / Math.min(l1.price, l2.price);
    const resistanceHigh = Math.max(...klines.slice(l1.idx, l2.idx).map(k => k.high));
    const patternHeight = resistanceHigh - Math.min(l1.price, l2.price);
    const neckline = resistanceHigh;

    if (lowDiff <= g.pattern_tolerance / 100 && patternHeight > 0 && l2.idx >= i - 10) {
      if (price > neckline && rsi > 45) {
        direction = "LONG";
        stopRef = Math.min(l1.price, l2.price);
        reason = `Double Bottom LONG | Troughs ${l1.price.toFixed(4)}/${l2.price.toFixed(4)} (${(lowDiff * 100).toFixed(1)}% diff) | Neckline ${neckline.toFixed(4)} | RSI ${rsi.toFixed(0)}`;
      }
    }
  }

  // ── Head and Shoulders (SHORT) ──
  if (!direction && swings.highs.length >= 3) {
    const h1 = swings.highs[swings.highs.length - 3];
    const h2 = swings.highs[swings.highs.length - 2]; // head (highest)
    const h3 = swings.highs[swings.highs.length - 1];
    const isHSPattern = h2.price > h1.price && h2.price > h3.price &&
      Math.abs(h1.price - h3.price) / Math.max(h1.price, h3.price) <= g.pattern_tolerance / 100;

    if (isHSPattern) {
      // Neckline = lows between shoulders and head
      const valley1 = Math.min(...klines.slice(h1.idx, h2.idx).map(k => k.low));
      const valley2 = Math.min(...klines.slice(h2.idx, h3.idx).map(k => k.low));
      const neckline = Math.min(valley1, valley2);
      const patternHeight = h2.price - neckline;

      if (patternHeight > 0 && price < neckline && h3.idx >= i - 15) {
        direction = "SHORT";
        stopRef = h2.price;
        reason = `Head & Shoulders SHORT | Head ${h2.price.toFixed(4)} | Shoulders ${h1.price.toFixed(4)}/${h3.price.toFixed(4)} | Neckline ${neckline.toFixed(4)} | RSI ${rsi.toFixed(0)}`;
      }
    }
  }

  // ── Inverse Head and Shoulders (LONG) ──
  if (!direction && swings.lows.length >= 3) {
    const l1 = swings.lows[swings.lows.length - 3];
    const l2 = swings.lows[swings.lows.length - 2]; // head (lowest)
    const l3 = swings.lows[swings.lows.length - 1];
    const isInvHS = l2.price < l1.price && l2.price < l3.price &&
      Math.abs(l1.price - l3.price) / Math.min(l1.price, l3.price) <= g.pattern_tolerance / 100;

    if (isInvHS) {
      const peak1 = Math.max(...klines.slice(l1.idx, l2.idx).map(k => k.high));
      const peak2 = Math.max(...klines.slice(l2.idx, l3.idx).map(k => k.high));
      const neckline = Math.min(peak1, peak2);
      const patternHeight = neckline - l2.price;

      if (patternHeight > 0 && price > neckline && l3.idx >= i - 15) {
        direction = "LONG";
        stopRef = l2.price;
        reason = `Inverse H&S LONG | Head ${l2.price.toFixed(4)} | Shoulders ${l1.price.toFixed(4)}/${l3.price.toFixed(4)} | Neckline ${neckline.toFixed(4)} | RSI ${rsi.toFixed(0)}`;
      }
    }
  }

  if (!direction) return null;

  const entry = price;
  const stop = direction === "LONG" ? stopRef - (stopRef * g.stop_buffer_pct / 100) : stopRef + (stopRef * g.stop_buffer_pct / 100);
  const risk = Math.abs(entry - stop);
  if (risk <= 0) return null;

  // Target: pattern height projection (standard target for these patterns)
  const bbMid = bb.mid;
  let target: number;
  if (direction === "LONG") {
    const patternTarget = entry + risk * g.target_rr;
    target = Math.min(patternTarget, bbMid * 1.01); // Don't overshoot the mean
    if (target <= entry) target = patternTarget;
  } else {
    const patternTarget = entry - risk * g.target_rr;
    target = Math.max(patternTarget, bbMid * 0.99);
    if (target >= entry) target = patternTarget;
  }

  const reward = Math.abs(target - entry);
  const rr = risk > 0 ? reward / risk : 0;
  if (rr < g.min_rr) return null;

  return { entry, stop, target, rr, reason };
}

// ──────────────────────────────────────────────
// Simulate trade outcome using future candles
// ──────────────────────────────────────────────

interface ExitOpts {
  stopMult?: number;
  targetMult?: number;
  useTrailing?: boolean;
  trailTrigger?: number;
  trailLock?: number;
  breakevenAt?: number;
}

function simulateTrade(
  klines: Kline[],
  entryIndex: number,
  entry: number,
  stop: number,
  target: number,
  maxHoldBars: number,
  useTrailing = true,
  trailTrigger = 0.4,
  trailLock = 0.6,
  breakevenAt = 0
): { exitPrice: number; exitIndex: number; result: "WIN" | "LOSS" | "TIMEOUT" } {
  const isShort = stop > entry;
  // Track best price seen since entry so the stop ratchets like the live engine
  let bestPrice = entry;
  let trailingActive = false;
  let breakevenActive = false;
  for (let j = entryIndex + 1; j < Math.min(klines.length, entryIndex + 1 + maxHoldBars); j++) {
    const targetDist = entry > 0 ? Math.abs(target - entry) / entry : 0;
    if (isShort) {
      bestPrice = Math.min(bestPrice, klines[j].low);
      const progress = entry > 0 ? (entry - klines[j].low) / entry : 0;
      if (useTrailing && !trailingActive && targetDist > 0 && progress >= trailTrigger * targetDist) {
        trailingActive = true;
      }
      if (breakevenAt > 0 && targetDist > 0 && progress >= breakevenAt) {
        breakevenActive = true;
      }
      const stopLevel = breakevenActive ? Math.min(stop, entry) : stop;
      if (klines[j].high >= stopLevel) {
        if (trailingActive) {
          const locked = entry - (entry - bestPrice) * trailLock;
          return { exitPrice: Math.min(stopLevel, locked), exitIndex: j, result: "LOSS" };
        }
        return { exitPrice: stopLevel, exitIndex: j, result: "LOSS" };
      }
      if (klines[j].low <= target) {
        return { exitPrice: target, exitIndex: j, result: "WIN" };
      }
    } else {
      bestPrice = Math.max(bestPrice, klines[j].high);
      const progress = entry > 0 ? (klines[j].high - entry) / entry : 0;
      if (useTrailing && !trailingActive && targetDist > 0 && progress >= trailTrigger * targetDist) {
        trailingActive = true;
      }
      if (breakevenAt > 0 && targetDist > 0 && progress >= breakevenAt) {
        breakevenActive = true;
      }
      const stopLevel = breakevenActive ? Math.max(stop, entry) : stop;
      if (klines[j].low <= stopLevel) {
        if (trailingActive) {
          const locked = entry + (bestPrice - entry) * trailLock;
          return { exitPrice: Math.max(stopLevel, locked), exitIndex: j, result: "LOSS" };
        }
        return { exitPrice: stopLevel, exitIndex: j, result: "LOSS" };
      }
      if (klines[j].high >= target) {
        return { exitPrice: target, exitIndex: j, result: "WIN" };
      }
    }
  }
  const exitIndex = Math.min(klines.length - 1, entryIndex + maxHoldBars);
  return { exitPrice: klines[exitIndex].close, exitIndex, result: "TIMEOUT" };
}

// ──────────────────────────────────────────────
// Run backtest for one symbol + one agent with a given genome
// ──────────────────────────────────────────────

function runBacktestForAgent(
  klines: Kline[],
  symbol: string,
  agentId: "KIBO" | "YUZU" | "MATTY" | "REKT" | "APEX",
  maxDollarRisk: number,
  genome: Genome,
  leverage: number,
  paperBalance: number,
  reverse = false,
  disableTrailing = false,
  exitOpts?: ExitOpts
): { trades: BacktestTrade[]; endingBalance: number } {
  const trades: BacktestTrade[] = [];
  const minIndex = 55;

  // Direction gene: a champion that evolved trade_direction = -1 runs every
  // signal mirrored (long becomes short and vice versa).
  const geneReversed = (genome.trade_direction ?? 1) < 0;

  const maxHoldBars = Math.round(genome.max_hold_bars);
  const minGap = Math.round(genome.min_gap);

  let lastTradeIndex = -1;
  let runningBalance = paperBalance;

  for (let i = minIndex; i < klines.length - 1; i++) {
    if (i - lastTradeIndex < minGap) continue;

    const skipGates = agentId === "MATTY" || agentId === "REKT" || agentId === "APEX";
    if (!skipGates) {
      if (!momoBacktest(klines, i)) continue;
      const rin = rinBacktest(klines, i);
      if (!rin.pass) continue;
    }

    let proposal: { entry: number; stop: number; target: number; rr: number; reason?: string } | null = null;
    if (agentId === "KIBO") {
      proposal = kiboBacktest(klines, i, genome);
    } else if (agentId === "YUZU") {
      proposal = yuzuBacktest(klines, i, genome);
    } else if (agentId === "REKT" || agentId === "APEX") {
      proposal = rektBacktest(klines, i, genome);
    } else {
      proposal = mattyBacktest(klines, i, genome);
    }
    if (!proposal) continue;

    // Scenario testing: mirror the trade around the entry price so a LONG
    // becomes an equivalent SHORT (and vice versa) with identical geometry
    if (reverse || geneReversed) {
      proposal = {
        ...proposal,
        stop: 2 * proposal.entry - proposal.stop,
        target: 2 * proposal.entry - proposal.target,
        reason: (proposal.reason ? proposal.reason + " | " : "") + "REVERSED",
      };
    }

    if (!skipGates) {
      if (!soraBacktest(klines, i, proposal.entry, proposal.stop)) continue;
    }

    // Exit-lab scaling: stretch/shrink stop and target distances around entry
    if (exitOpts?.stopMult !== undefined && exitOpts.stopMult !== 1) {
      proposal.stop = proposal.entry + (proposal.stop - proposal.entry) * exitOpts.stopMult;
    }
    if (exitOpts?.targetMult !== undefined && exitOpts.targetMult !== 1) {
      proposal.target = proposal.entry + (proposal.target - proposal.entry) * exitOpts.targetMult;
    }

    const sim = simulateTrade(
      klines, i, proposal.entry, proposal.stop, proposal.target, maxHoldBars,
      exitOpts?.useTrailing ?? !disableTrailing,
      exitOpts?.trailTrigger ?? 0.4,
      exitOpts?.trailLock ?? 0.6,
      exitOpts?.breakevenAt ?? 0
    );
    const risk = Math.abs(proposal.entry - proposal.stop);
    const riskPct = risk / proposal.entry;
    // Compounding: risk scales with current balance, not initial
    const dynamicRisk = maxDollarRisk * (runningBalance / paperBalance);
    const rawSize = dynamicRisk / riskPct;
    const maxNotional = runningBalance * leverage;
    const simulatedSize = Math.min(rawSize, maxNotional);

    // Liquidation check — if stop is wider than liquidation distance, the trade
    // would be liquidated before the stop triggers, resulting in full position loss
    const isShort = proposal.stop > proposal.entry;
    const liqDistance = (proposal.entry / leverage) * 0.9;
    const liquidationPrice = isShort ? proposal.entry + liqDistance : proposal.entry - liqDistance;
    const stopBeyondLiq = isShort
      ? proposal.stop > liquidationPrice
      : proposal.stop < liquidationPrice;

    let pnl: number;
    if (stopBeyondLiq && sim.result === "LOSS") {
      // Liquidation: lose the full margin (entry equity), not just planned risk
      pnl = -Math.min(simulatedSize / leverage, runningBalance);
    } else if (sim.result === "WIN") {
      pnl = isShort
        ? ((proposal.entry - sim.exitPrice) / proposal.entry) * simulatedSize
        : ((sim.exitPrice - proposal.entry) / proposal.entry) * simulatedSize;
    } else if (sim.result === "LOSS") {
      // Book the actual exit price — a trailed stop can exit in profit,
      // so we cannot assume the loss equals the original stop distance
      pnl = isShort
        ? ((proposal.entry - sim.exitPrice) / proposal.entry) * simulatedSize
        : ((sim.exitPrice - proposal.entry) / proposal.entry) * simulatedSize;
    } else {
      pnl = isShort
        ? ((proposal.entry - sim.exitPrice) / proposal.entry) * simulatedSize
        : ((sim.exitPrice - proposal.entry) / proposal.entry) * simulatedSize;
    }
    // Taker fees on entry + exit, charged on notional
    pnl -= TAKER_FEE_RATE * simulatedSize * 2;

    const pnlPct = simulatedSize > 0 ? (pnl / simulatedSize) * 100 : 0;

    const roundedPnl = Math.round(pnl * 100) / 100;
    runningBalance += roundedPnl;
    if (runningBalance <= 0) {
      // Account blown — stop trading this symbol
      trades.push({
        agent: agentId,
        symbol,
        entry: proposal.entry,
        stop: proposal.stop,
        target: proposal.target,
        exit: sim.exitPrice,
        pnl: roundedPnl,
        pnlPct: Math.round(pnlPct * 100) / 100,
        result: sim.result,
        entryTime: klines[i].time,
        exitTime: klines[sim.exitIndex].time,
        reason: proposal.reason || (agentId === "REKT" ? "Volatility surge setup" : agentId === "APEX" ? "Alpha hunt setup" : "BB mean-reversion setup"),
        rr: Math.round(proposal.rr * 100) / 100,
      });
      break;
    }

    trades.push({
      agent: agentId,
      symbol,
      entry: proposal.entry,
      stop: proposal.stop,
      target: proposal.target,
      exit: sim.exitPrice,
      pnl: roundedPnl,
      pnlPct: Math.round(pnlPct * 100) / 100,
      result: sim.result,
      entryTime: klines[i].time,
      exitTime: klines[sim.exitIndex].time,
      reason: proposal.reason || (agentId === "REKT" ? "Volatility surge setup" : agentId === "APEX" ? "Alpha hunt setup" : "BB mean-reversion setup"),
      rr: Math.round(proposal.rr * 100) / 100,
    });

    lastTradeIndex = sim.exitIndex;
  }

  return { trades, endingBalance: runningBalance };
}

// ──────────────────────────────────────────────
// Compute summary statistics
// ──────────────────────────────────────────────

function computeSummary(
  agentId: string,
  symbol: string,
  periodDays: number,
  trades: BacktestTrade[]
): BacktestSummary {
  const wins = trades.filter((t) => t.pnl > 0);
  const losses = trades.filter((t) => t.pnl < 0);
  const winRate = trades.length > 0 ? (wins.length / trades.length) * 100 : 0;
  const totalPnl = trades.reduce((a, b) => a + b.pnl, 0);
  const avgWin = wins.length > 0 ? wins.reduce((a, b) => a + b.pnl, 0) / wins.length : 0;
  const avgLoss = losses.length > 0 ? losses.reduce((a, b) => a + b.pnl, 0) / losses.length : 0;
  const biggestWin = wins.length > 0 ? Math.max(...wins.map((t) => t.pnl)) : 0;
  const biggestLoss = losses.length > 0 ? Math.min(...losses.map((t) => t.pnl)) : 0;

  let peak = 0;
  let cumulative = 0;
  let maxDd = 0;
  for (const t of trades) {
    cumulative += t.pnl;
    if (cumulative > peak) peak = cumulative;
    const dd = peak - cumulative;
    if (dd > maxDd) maxDd = dd;
  }

  const grossProfit = wins.reduce((a, b) => a + b.pnl, 0);
  const grossLoss = Math.abs(losses.reduce((a, b) => a + b.pnl, 0));
  const profitFactor = grossLoss > 0 ? grossProfit / grossLoss : (grossProfit > 0 ? 99 : 0);

  const pnlValues = trades.map((t) => t.pnl);
  const meanPnl = pnlValues.length > 0 ? pnlValues.reduce((a, b) => a + b, 0) / pnlValues.length : 0;
  const variance = pnlValues.length > 1
    ? pnlValues.reduce((a, b) => a + (b - meanPnl) ** 2, 0) / pnlValues.length
    : 0;
  const stdPnl = Math.sqrt(variance);
  const sharpe = stdPnl > 0 ? (meanPnl / stdPnl) * Math.sqrt(252) : 0;

  return {
    agent_id: agentId,
    symbol,
    period_days: periodDays,
    total_trades: trades.length,
    wins: wins.length,
    losses: losses.length,
    blocked: 0,
    win_rate: Math.round(winRate * 100) / 100,
    total_pnl: Math.round(totalPnl * 100) / 100,
    avg_win: Math.round(avgWin * 100) / 100,
    avg_loss: Math.round(avgLoss * 100) / 100,
    biggest_win: Math.round(biggestWin * 100) / 100,
    biggest_loss: Math.round(biggestLoss * 100) / 100,
    max_drawdown: Math.round(maxDd * 100) / 100,
    profit_factor: Math.round(profitFactor * 100) / 100,
    sharpe_ratio: Math.round(sharpe * 100) / 100,
    trades_json: trades.slice(-100),
  };
}

// ──────────────────────────────────────────────
// Default genomes (fallback if DB has no champion)
// ──────────────────────────────────────────────

const DEFAULT_GENOMES: Record<string, Genome> = {
  KIBO: {
    trend_threshold: 0.002,
    long_stop_sma50_mult: 0.995,
    long_stop_low_mult: 0.99,
    long_target_rr: 2.5,
    short_rsi_max: 45,
    short_stop_pct: 1.03,
    short_target_rr: 2.0,
    min_rr: 2.0,
    max_hold_bars: 12,
    min_gap: 3,
    trade_direction: 1,
  },
  YUZU: {
    trend_threshold: 0.002,
    long_stop_low_mult: 0.995,
    long_target_rr: 1.8,
    short_rsi_max: 50,
    short_stop_pct: 1.02,
    short_target_rr: 1.5,
    min_rr: 1.5,
    max_hold_bars: 3,
    min_gap: 2,
    trade_direction: 1,
  },
  MATTY: {
    pattern_lookback: 40,
    pattern_tolerance: 1.5,
    stop_buffer_pct: 0.3,
    target_rr: 1.8,
    min_rr: 1.2,
    max_hold_bars: 36,
    min_gap: 3,
    trade_direction: 1,
  },
  REKT: {
    min_momentum: 0.3,
    min_rsi_long: 45,
    max_rsi_long: 78,
    min_rsi_short: 22,
    max_rsi_short: 55,
    trend_threshold: 0.001,
    min_stop_pct: 0.5,
    max_stop_pct: 1.0,
    target_rr: 1.5,
    min_rr: 1.2,
    max_hold_bars: 6,
    min_gap: 1,
    trade_direction: 1,
  },
  APEX: {
    min_momentum: 0.15,
    min_rsi_long: 40,
    max_rsi_long: 72,
    min_rsi_short: 28,
    max_rsi_short: 60,
    trend_threshold: 0.0008,
    min_stop_pct: 0.4,
    max_stop_pct: 1.2,
    target_rr: 2.0,
    min_rr: 1.5,
    max_hold_bars: 8,
    min_gap: 2,
    trade_direction: 1,
  },
};

// ──────────────────────────────────────────────
// Mutation logic — create a variant genome
// ──────────────────────────────────────────────

const MUTATION_RANGES: Record<string, Record<string, [number, number]>> = {
  KIBO: {
    trend_threshold: [0.001, 0.005],
    long_stop_sma50_mult: [0.99, 0.999],
    long_stop_low_mult: [0.985, 0.995],
    long_target_rr: [2.0, 3.5],
    short_rsi_max: [35, 55],
    short_stop_pct: [1.01, 1.06],
    short_target_rr: [1.5, 2.5],
    min_rr: [1.5, 2.5],
    max_hold_bars: [8, 18],
    min_gap: [2, 5],
    trade_direction: [-1, 1],
  },
  YUZU: {
    trend_threshold: [0.001, 0.005],
    long_stop_low_mult: [0.99, 0.998],
    long_target_rr: [1.3, 2.5],
    short_rsi_max: [40, 55],
    short_stop_pct: [1.01, 1.05],
    short_target_rr: [1.0, 2.0],
    min_rr: [1.0, 2.0],
    max_hold_bars: [2, 6],
    min_gap: [1, 4],
    trade_direction: [-1, 1],
  },
  MATTY: {
    pattern_lookback: [25, 60],
    pattern_tolerance: [0.8, 3.0],
    stop_buffer_pct: [0.1, 0.8],
    target_rr: [1.2, 2.5],
    min_rr: [1.0, 1.8],
    max_hold_bars: [24, 48],
    min_gap: [2, 5],
    trade_direction: [-1, 1],
  },
  REKT: {
    min_momentum: [0.15, 0.6],
    min_rsi_long: [40, 50],
    max_rsi_long: [70, 82],
    min_rsi_short: [18, 28],
    max_rsi_short: [50, 60],
    trend_threshold: [0.0005, 0.003],
    min_stop_pct: [0.3, 0.8],
    max_stop_pct: [0.7, 1.3],
    target_rr: [1.2, 2.0],
    min_rr: [1.0, 1.5],
    max_hold_bars: [4, 10],
    min_gap: [1, 3],
    trade_direction: [-1, 1],
  },
  APEX: {
    min_momentum: [0.08, 0.4],
    min_rsi_long: [35, 50],
    max_rsi_long: [62, 80],
    min_rsi_short: [20, 35],
    max_rsi_short: [50, 65],
    trend_threshold: [0.0003, 0.002],
    min_stop_pct: [0.2, 0.7],
    max_stop_pct: [0.8, 1.6],
    target_rr: [1.5, 2.8],
    min_rr: [1.2, 2.0],
    max_hold_bars: [5, 12],
    min_gap: [1, 4],
    trade_direction: [-1, 1],
  },
};

function mutateGenome(
  agentId: string,
  parent: Genome,
  geneFraction = 0.3,
  deltaScale = 0.2
): { genome: Genome; notes: string } {
  const ranges = MUTATION_RANGES[agentId];
  if (!ranges) return { genome: { ...parent }, notes: "No mutation ranges defined" };

  const mutated: Genome = { ...parent };
  const keys = Object.keys(ranges);
  const numToMutate = Math.max(1, Math.ceil(keys.length * geneFraction));
  const changed: string[] = [];

  for (let i = 0; i < numToMutate; i++) {
    const key = keys[Math.floor(Math.random() * keys.length)];
    if (changed.includes(key)) continue;
    // trade_direction is a binary gene: selected = flip, never nudge.
    // A nudge within [-1, 1] could never cross the boundary, so the direction
    // would never actually change.
    if (key === "trade_direction") {
      mutated[key] = (parent[key] ?? 1) < 0 ? 1 : -1;
      changed.push(key);
      continue;
    }
    const [min, max] = ranges[key];
    const range = max - min;
    const delta = (Math.random() - 0.5) * range * deltaScale;
    let newVal = (parent[key] || (min + max) / 2) + delta;
    newVal = Math.max(min, Math.min(max, newVal));

    if (key === "bb_period" || key === "max_hold_bars" || key === "min_gap" || key === "pattern_lookback") {
      newVal = Math.round(newVal);
    } else if (key !== "bb_std_dev" && key !== "trend_threshold" && key !== "trend_strength_max" && key !== "stop_band_buffer") {
      newVal = Math.round(newVal * 1000) / 1000;
    } else {
      newVal = Math.round(newVal * 10000) / 10000;
    }

    mutated[key] = newVal;
    changed.push(key);
  }

  const notes = changed.length > 0
    ? `Mutated: ${changed.map((k) => `${k} ${parent[k]?.toFixed(3)}→${mutated[k]?.toFixed(3)}`).join(", ")}`
    : "No changes";

  return { genome: mutated, notes };
}

// ──────────────────────────────────────────────
// Run backtest with a specific genome set and return per-agent fitness
// ──────────────────────────────────────────────

interface AgentFitness {
  agent_id: string;
  total_pnl: number;
  total_trades: number;
  win_rate: number;
  profit_factor: number;
  summaries: BacktestSummary[];
}

async function runBacktestWithGenomes(
  symbols: string[],
  periodDays: number,
  maxDollarRisk: number,
  genomes: Record<string, Genome>,
  leverageTiers: Record<string, number>,
  paperBalance: number,
  disableTrailing = false
): Promise<AgentFitness[]> {
  const limit1h = Math.min(1000, periodDays * 24);
  const limit5m = 1000;
  const limit1m_klines = 1000; // Bybit max per request; ~16h of 1m data
  const agentResults: Record<string, BacktestSummary[]> = {};
  // Each agent trades one shared account across all its symbols
  const agentBalances: Record<string, number> = {
    KIBO: paperBalance,
    YUZU: paperBalance,
    MATTY: paperBalance,
    REKT: paperBalance,
    APEX: paperBalance,
  };

  for (const symbol of symbols) {
    const leverage = leverageTiers[symbol] || 10;

    const klines1h = await fetchKlines(symbol, "60", limit1h);
    if (klines1h.length >= 60) {
      for (const agent of ["KIBO", "YUZU"] as const) {
        if (agentBalances[agent] <= 0) continue;
        const riskBudget = maxDollarRisk * (agentBalances[agent] / paperBalance);
        const { trades, endingBalance } = runBacktestForAgent(klines1h, symbol, agent, riskBudget, genomes[agent], leverage, agentBalances[agent], false, disableTrailing);
        agentBalances[agent] = endingBalance;
        const summary = computeSummary(agent, symbol, periodDays, trades);
        if (!agentResults[agent]) agentResults[agent] = [];
        agentResults[agent].push(summary);
      }
    }

    const klines5m = await fetchKlines(symbol, "5", limit5m);
    if (klines5m.length >= 60) {
      if (agentBalances["MATTY"] > 0) {
        const mattyRiskBudget = maxDollarRisk * (agentBalances["MATTY"] / paperBalance);
        const { trades, endingBalance } = runBacktestForAgent(klines5m, symbol, "MATTY" as const, mattyRiskBudget, genomes["MATTY"], leverage, agentBalances["MATTY"], false, disableTrailing);
        agentBalances["MATTY"] = endingBalance;
        const summary = computeSummary("MATTY", symbol, periodDays, trades);
        if (!agentResults["MATTY"]) agentResults["MATTY"] = [];
        agentResults["MATTY"].push(summary);
      }
    }

    // REKT only trades volatile Bybit linear perps — NOT the spot watchlist.
    // BTC/ETH/SOL don't move enough for the momentum strategy to work.
    // REKT hunts coins with real volatility where 0.3%+ momentum bursts actually occur.
  }

  // YUZU also scans volatile perps — as a scalper it needs coins that move
  // enough to hit targets within 3 hours. The spot watchlist alone is too slow.
  const yuzuPerpLeverage = 50;
  const yuzuAllMovers = await fetchTopMoversPerp(50_000_000, 15);
  const yuzuBlocklist = ["SOXLUSDT", "SNDKUSDT", "DOGEUSDT", "WLDUSDT"];
  const yuzuTopMovers = yuzuAllMovers.slice(5).filter(s => !yuzuBlocklist.includes(s));
  for (const perpSymbol of yuzuTopMovers) {
    if (agentBalances["YUZU"] <= 0) continue;
    const klines1h = await fetchKlines(perpSymbol, "60", limit1h, "linear");
    if (klines1h.length >= 60) {
      const yuzuRiskBudget = maxDollarRisk * (agentBalances["YUZU"] / paperBalance);
      const { trades, endingBalance } = runBacktestForAgent(klines1h, perpSymbol, "YUZU" as const, yuzuRiskBudget, genomes["YUZU"], yuzuPerpLeverage, agentBalances["YUZU"], false, disableTrailing);
      agentBalances["YUZU"] = endingBalance;
      const summary = computeSummary("YUZU", perpSymbol, periodDays, trades);
      if (!agentResults["YUZU"]) agentResults["YUZU"] = [];
      agentResults["YUZU"].push(summary);
    }
  }

  // REKT scans the most volatile Bybit linear perps (coins that pump/dump 10%+ daily)
  const rektLeverage = 50;
  const topMovers = await fetchTopMoversPerp(50_000_000, 15);
  for (const perpSymbol of topMovers) {
    if (agentBalances["REKT"] <= 0) continue;
    const klines1m = await fetchKlines(perpSymbol, "1", limit1m_klines, "linear");
    if (klines1m.length >= 60) {
      const rektRiskBudget = maxDollarRisk * (agentBalances["REKT"] / paperBalance);
      const { trades, endingBalance } = runBacktestForAgent(klines1m, perpSymbol, "REKT" as const, rektRiskBudget, genomes["REKT"], rektLeverage, agentBalances["REKT"], false, disableTrailing);
      agentBalances["REKT"] = endingBalance;
      const summary = computeSummary("REKT", perpSymbol, periodDays, trades);
      if (!agentResults["REKT"]) agentResults["REKT"] = [];
      agentResults["REKT"].push(summary);
    }
  }

  // APEX scans both spot watchlist (5m candles) and top perp movers (5m candles)
  // It fuses momentum + trend + RSI — same genome shape as REKT but with 5m candles
  const apexLeverage = 50;
  for (const perpSymbol of topMovers) {
    if (agentBalances["APEX"] <= 0) continue;
    const klines5m = await fetchKlines(perpSymbol, "5", limit5m, "linear");
    if (klines5m.length >= 60) {
      const apexRiskBudget = maxDollarRisk * (agentBalances["APEX"] / paperBalance);
      const { trades, endingBalance } = runBacktestForAgent(klines5m, perpSymbol, "APEX" as const, apexRiskBudget, genomes["APEX"], apexLeverage, agentBalances["APEX"], false, disableTrailing);
      agentBalances["APEX"] = endingBalance;
      const summary = computeSummary("APEX", perpSymbol, periodDays, trades);
      if (!agentResults["APEX"]) agentResults["APEX"] = [];
      agentResults["APEX"].push(summary);
    }
  }

  return Object.entries(agentResults).map(([agentId, summaries]) => {
    const totalPnl = summaries.reduce((a, b) => a + b.total_pnl, 0);
    const totalTrades = summaries.reduce((a, b) => a + b.total_trades, 0);
    const totalWins = summaries.reduce((a, b) => a + b.wins, 0);
    const grossProfit = summaries.reduce((a, b) => a + Math.max(0, b.total_pnl), 0);
    const grossLoss = Math.abs(summaries.reduce((a, b) => a + Math.min(0, b.total_pnl), 0));
    const winRate = totalTrades > 0 ? (totalWins / totalTrades) * 100 : 0;
    const profitFactor = grossLoss > 0 ? grossProfit / grossLoss : (grossProfit > 0 ? 99 : 0);
    return {
      agent_id: agentId,
      total_pnl: Math.round(totalPnl * 100) / 100,
      total_trades: totalTrades,
      win_rate: Math.round(winRate * 100) / 100,
      profit_factor: Math.round(profitFactor * 100) / 100,
      summaries,
    };
  });
}

// ──────────────────────────────────────────────
// Load champion genomes from DB
// ──────────────────────────────────────────────

async function loadChampionGenomes(): Promise<Record<string, { genome: Genome; row: GenomeRow }>> {
  const { data } = await supabase
    .from("agent_genomes")
    .select("*")
    .eq("is_champion", true)
    .in("agent_id", ["KIBO", "YUZU", "MATTY", "REKT", "APEX"]);

  const result: Record<string, { genome: Genome; row: GenomeRow }> = {};
  if (data) {
    for (const row of data as GenomeRow[]) {
      result[row.agent_id] = { genome: row.genome, row };
    }
  }

  for (const agentId of ["KIBO", "YUZU", "MATTY", "REKT", "APEX"]) {
    if (!result[agentId]) {
      result[agentId] = { genome: { ...DEFAULT_GENOMES[agentId] }, row: null as unknown as GenomeRow };
    }
  }

  return result;
}

// ──────────────────────────────────────────────
// Normal backtest runner (uses champion genomes)
// ──────────────────────────────────────────────

async function runNormalBacktest(symbols: string[], periodDays: number, maxDollarRisk: number, leverageTiers: Record<string, number>, paperBalance: number): Promise<BacktestSummary[]> {
  const champions = await loadChampionGenomes();
  const genomes: Record<string, Genome> = {};
  for (const [agentId, info] of Object.entries(champions)) {
    genomes[agentId] = info.genome;
  }

  const fitness = await runBacktestWithGenomes(symbols, periodDays, maxDollarRisk, genomes, leverageTiers, paperBalance);
  const summaries: BacktestSummary[] = [];
  for (const f of fitness) {
    summaries.push(...f.summaries);
  }
  return summaries;
}

// ──────────────────────────────────────────────
// Live performance — fetch real P&L from paper_trades
// ──────────────────────────────────────────────

async function getLivePerformance(agentId: string): Promise<{ pnl: number; trades: number; winRate: number }> {
  const { data } = await supabase
    .from("paper_trades")
    .select("pnl, status")
    .eq("agent_id", agentId)
    .in("status", ["CLOSED", "WIN", "LOSS", "TIMEOUT"]);

  if (!data || data.length === 0) return { pnl: 0, trades: 0, winRate: 0 };

  const totalPnl = data.reduce((sum, t) => sum + (t.pnl ?? 0), 0);
  const wins = data.filter((t) => (t.pnl ?? 0) > 0).length;
  const winRate = data.length > 0 ? (wins / data.length) * 100 : 0;

  return {
    pnl: Math.round(totalPnl * 100) / 100,
    trades: data.length,
    winRate: Math.round(winRate * 100) / 100,
  };
}

// Fitness = P&L plus a small capped activity bonus so a genome that never
// trades loses to one that trades and loses a little. Capped at 5 so it can
// never outweigh real P&L differences.
function computeFitness(pnl: number, tradeCount: number): number {
  return pnl + Math.min(tradeCount * 0.5, 5);
}

// ──────────────────────────────────────────────
// Evolution runner — mutate champions, test, crown new champions
// Fitness = backtest P&L + capped activity bonus. Live results are used as
// PRESSURE, not as bonus points: a bot losing live trades mutates harder and
// its champion carries a handicap so failing settings are replaced sooner.
// ──────────────────────────────────────────────

async function runEvolution(
  symbols: string[],
  periodDays: number,
  maxDollarRisk: number,
  leverageTiers: Record<string, number>,
  paperBalance: number
): Promise<{ generation: number; results: Array<{ agent_id: string; champion_pnl: number; mutant_pnl: number; improved: boolean; mutation_notes: string }> }> {
  const champions = await loadChampionGenomes();
  const runId = `evo-${Date.now()}`;
  const results: Array<{ agent_id: string; champion_pnl: number; mutant_pnl: number; improved: boolean; mutation_notes: string }> = [];

  for (const agentId of ["KIBO", "YUZU", "MATTY", "REKT", "APEX"] as const) {
    const championGenome = champions[agentId].genome;
    const championRow = champions[agentId].row;
    const parentGen = championRow?.generation ?? 1;
    const parentId = championRow?.id ?? null;

    // Fetch live performance for this agent — shared across all genome variants
    // since the same agent executes trades regardless of genome generation
    const live = await getLivePerformance(agentId);

    // Live pressure: with enough real trades to judge (>=5), a bot that is
    // losing money or winning under 35% evolves under harder pressure.
    const MIN_LIVE_TRADES = 5;
    const losingLive = live.trades >= MIN_LIVE_TRADES && (live.pnl < 0 || live.winRate < 35);
    const liveHandicap = losingLive ? Math.min(Math.abs(live.pnl), 20) * 0.5 : 0;
    const mutantCount = losingLive ? 5 : 3;
    const geneFraction = losingLive ? 0.5 : 0.3;
    const deltaScale = losingLive ? 0.4 : 0.2;

    // Create mutated variants (more + bigger steps when live is losing)
    const mutants: Array<{ genome: Genome; notes: string }> = [];
    for (let m = 0; m < mutantCount; m++) {
      mutants.push(mutateGenome(agentId, championGenome, geneFraction, deltaScale));
    }

    // Track each mutant's own stats so a crowned champion gets its real numbers
    const mutantsFitness: Array<{ genome: Genome; pnl: number; tradeCount: number; winRate: number; profitFactor: number }> = [];

    // Test champion (baseline) — fill all agents so the run doesn't crash on missing genomes
    const championGenomes: Record<string, Genome> = { ...DEFAULT_GENOMES };
    championGenomes[agentId] = championGenome;
    const championFitness = await runBacktestWithGenomes(symbols, periodDays, maxDollarRisk, championGenomes, leverageTiers, paperBalance);
    const champFit = championFitness.find((f) => f.agent_id === agentId);
    const championPnl = champFit?.total_pnl ?? 0;
    const champTrades = champFit?.total_trades ?? 0;

    // Fitness: backtest PnL with a mild, capped activity bonus so a genome that
    // never trades loses to one that trades and loses a little. Live PnL is NOT
    // blended in — the live trades were placed by the old champion, so attributing
    // them to a mutant is wrong and the old blend math reduced to a constant.
    // Champion composite carries the live handicap when losing live, so
    // mutants only need a smaller backtest edge to replace failing settings.
    const championComposite = computeFitness(championPnl, champTrades) - liveHandicap;

    // Floor check: if the champion is deeply negative, reset to defaults
    // instead of continuing to mutate a broken genome
    if (championComposite < -300) {
      const defaultGenome = DEFAULT_GENOMES[agentId];
      const defaultGenomes: Record<string, Genome> = { ...DEFAULT_GENOMES };
      defaultGenomes[agentId] = defaultGenome;
      const defaultFitness = await runBacktestWithGenomes(symbols, periodDays, maxDollarRisk, defaultGenomes, leverageTiers, paperBalance);
      const defaultPnl = defaultFitness.find((f) => f.agent_id === agentId)?.total_pnl ?? 0;
      const defaultComposite = computeFitness(defaultPnl, defaultFitness.find((f) => f.agent_id === agentId)?.total_trades ?? 0);

      // Dethrone the bad champion and crown the default genome
      await supabase.from("agent_genomes").update({ is_champion: false }).eq("agent_id", agentId).eq("is_champion", true);
      await supabase.from("agent_genomes").insert({
        agent_id: agentId,
        generation: parentGen + 1,
        genome: defaultGenome,
        fitness_score: defaultComposite,
        total_pnl: defaultPnl,
        total_trades: defaultFitness.find((f) => f.agent_id === agentId)?.total_trades ?? 0,
        win_rate: defaultFitness.find((f) => f.agent_id === agentId)?.win_rate ?? 0,
        profit_factor: defaultFitness.find((f) => f.agent_id === agentId)?.profit_factor ?? 0,
        is_champion: true,
        parent_id: parentId,
        mutation_notes: `Reset to defaults (champion was ${championComposite.toFixed(0)})`,
        backtest_run_id: runId,
        live_pnl: live.pnl,
        composite_score: defaultComposite,
      });

      results.push({
        agent_id: agentId,
        champion_pnl: Math.round(championComposite * 100) / 100,
        mutant_pnl: Math.round(defaultComposite * 100) / 100,
        improved: true,
        mutation_notes: `Reset to defaults (champion was ${championComposite.toFixed(0)})`,
      });
      continue;
    }

    // Test each mutant
    let bestComposite = championComposite;
    let bestPnl = championPnl;
    let bestTrades = champTrades;
    let bestGenome = championGenome;
    let bestNotes = losingLive
      ? `No improvement — keeping champion (live losing, handicap ${liveHandicap.toFixed(1)} applied)`
      : "No improvement — keeping champion";
    let improved = false;
    const allZeroTradeAgent = championPnl === 0 && champTrades === 0;

    for (const mutant of mutants) {
      // Fill in other agents with defaults so the run works
      const testGenomes: Record<string, Genome> = { ...DEFAULT_GENOMES };
      testGenomes[agentId] = mutant.genome;

      const mutantFitness = await runBacktestWithGenomes(symbols, periodDays, maxDollarRisk, testGenomes, leverageTiers, paperBalance);
      const mutantFit = mutantFitness.find((f) => f.agent_id === agentId);
      const mutantPnl = mutantFit?.total_pnl ?? 0;
      const mutantTrades = mutantFit?.total_trades ?? 0;

      // Fitness for the mutant (same rule as the champion baseline)
      let mutantComposite = computeFitness(mutantPnl, mutantTrades);
      const mutantWinRate = mutantFit?.win_rate ?? 0;
      const mutantProfitFactor = mutantFit?.profit_factor ?? 0;

      // Diversity bonus: when the champion produces zero backtest trades, all mutants
      // score 0 on P&L and can never win. Prefer mutants that generate more trades so
      // evolution explores toward parameters that actually fire setups. Capped and
      // gated on profitability so a high-frequency money-loser can never be crowned.
      if (allZeroTradeAgent && mutantTrades > 0 && mutantPnl >= 0) {
        mutantComposite += Math.min(mutantTrades * 0.5, 5);
      }

      mutantsFitness.push({ genome: mutant.genome, pnl: mutantPnl, tradeCount: mutantTrades, winRate: mutantWinRate, profitFactor: mutantProfitFactor });

      // Save mutant genome to DB with composite score
      await supabase.from("agent_genomes").insert({
        agent_id: agentId,
        generation: parentGen + 1,
        genome: mutant.genome,
        fitness_score: mutantComposite,
        total_pnl: mutantPnl,
        total_trades: mutantTrades,
        win_rate: mutantFit?.win_rate ?? 0,
        profit_factor: mutantFit?.profit_factor ?? 0,
        is_champion: false,
        parent_id: parentId,
        mutation_notes: mutant.notes,
        backtest_run_id: runId,
        live_pnl: live.pnl,
        composite_score: mutantComposite,
      });

      if (mutantComposite > bestComposite) {
        bestComposite = mutantComposite;
        bestPnl = mutantPnl;
        bestTrades = mutantTrades;
        bestGenome = mutant.genome;
        bestNotes = mutant.notes;
        improved = true;
      }
    }

    // If a mutant won, crown it as new champion
    if (improved) {
      const winnerFitness = mutantsFitness.find((f) => f.genome === bestGenome);
      // Dethrone ALL existing champions for this agent
      await supabase.from("agent_genomes").update({ is_champion: false }).eq("agent_id", agentId).eq("is_champion", true);
      // Crown new champion with ITS OWN fitness data (not the old champion's)
      await supabase.from("agent_genomes").insert({
        agent_id: agentId,
        generation: parentGen + 1,
        genome: bestGenome,
        fitness_score: bestComposite,
        total_pnl: bestPnl,
        total_trades: bestTrades,
        win_rate: winnerFitness?.winRate ?? 0,
        profit_factor: winnerFitness?.profitFactor ?? 0,
        is_champion: true,
        parent_id: parentId,
        mutation_notes: bestNotes,
        backtest_run_id: runId,
        live_pnl: live.pnl,
        composite_score: bestComposite,
      });
    }

    results.push({
      agent_id: agentId,
      champion_pnl: Math.round(championComposite * 100) / 100,
      mutant_pnl: Math.round(bestComposite * 100) / 100,
      improved,
      mutation_notes: bestNotes,
    });
  }

  return {
    generation: (champions["KIBO"].row?.generation ?? 1) + 1,
    results,
  };
}

// ──────────────────────────────────────────────
// HTTP handler
// ──────────────────────────────────────────────

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    let body: { mode?: string } = {};
    try {
      body = await req.json();
    } catch {
      // empty body is fine
    }

    const { data: config } = await supabase
      .from("system_config")
      .select("*")
      .eq("id", 1)
      .maybeSingle();

    if (!config) {
      return new Response(
        JSON.stringify({ error: "System config not found" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const symbols: string[] = config.watchlist;
    const maxDollarRisk = (config.max_risk_per_trade_pct / 100) * config.paper_balance;
    const leverageTiers = (config.leverage_tiers as Record<string, number>) || {};
    const paperBalance = config.paper_balance;
    const periodDays = 30;

    // Diagnostic mode: report what the market-data fetches return from here
    if (body.mode === "diag") {
      const probe = async (label: string, url: string) => {
        try {
          const res = await fetch(url);
          const txt = await res.text();
          return { label, status: res.status, len: txt.length, head: txt.slice(0, 120) };
        } catch (e) {
          return { label, error: String(e) };
        }
      };
      const results = await Promise.all([
        probe("bybit", "https://api.bybit.com/v5/market/kline?category=linear&symbol=BTCUSDT&interval=60&limit=3"),
        probe("bytick", "https://api.bytick.com/v5/market/kline?category=linear&symbol=BTCUSDT&interval=60&limit=3"),
        probe("binance", "https://api.binance.com/api/v3/klines?symbol=BTCUSDT&interval=1h&limit=3"),
        probe("binance_vision", "https://data-api.binance.vision/api/v3/klines?symbol=BTCUSDT&interval=1h&limit=3"),
        probe("okx", "https://www.okx.com/api/v5/market/candles?instId=BTC-USDT&bar=1H&limit=3"),
        probe("kucoin", "https://api.kucoin.com/api/v1/market/candles?type=1hour&symbol=BTC-USDT"),
      ]);
      return new Response(JSON.stringify(results), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // Scenario comparison mode: baseline vs reversed vs wider stops,
    // for the agents that are losing money live. Read-only — does not
    // touch backtest_results or champion genomes.
    if (body.mode === "scenarios") {
      const champions = await loadChampionGenomes();
      const scenarioAgents = ["REKT", "APEX"] as const;
      const interval: Record<string, string> = { REKT: "1", APEX: "5" };
      const scenLeverage = 50;
      const topMovers = await fetchTopMoversPerp(50_000_000, 15);
      const out: Record<string, Array<Record<string, number | string>>> = {};

      for (const agentId of scenarioAgents) {
        const base = champions[agentId].genome;
        const scenarios: Array<{ label: string; genome: Genome; reverse: boolean }> = [
          { label: "baseline", genome: base, reverse: false },
          { label: "reversed", genome: base, reverse: true },
          {
            label: "wider_stops",
            genome: {
              ...base,
              min_stop_pct: Math.round(base.min_stop_pct * 2 * 1000) / 1000,
              max_stop_pct: Math.round(base.max_stop_pct * 2 * 1000) / 1000,
              target_rr: base.target_rr + 0.5,
              min_gap: Math.round(base.min_gap) + 2,
            },
            reverse: false,
          },
          {
            label: "reversed_wider_stops",
            genome: {
              ...base,
              min_stop_pct: Math.round(base.min_stop_pct * 2 * 1000) / 1000,
              max_stop_pct: Math.round(base.max_stop_pct * 2 * 1000) / 1000,
              target_rr: base.target_rr + 0.5,
              min_gap: Math.round(base.min_gap) + 2,
            },
            reverse: true,
          },
        ];

        const perScenario: Array<Record<string, number | string>> = [];
        for (const sc of scenarios) {
          const allTrades: BacktestTrade[] = [];
          for (const perpSymbol of topMovers) {
            const kl = await fetchKlines(perpSymbol, interval[agentId], agentId === "REKT" ? 1000 : 1000, "linear");
            if (kl.length < 60) continue;
            const { trades } = runBacktestForAgent(kl, perpSymbol, agentId, maxDollarRisk, sc.genome, scenLeverage, paperBalance, sc.reverse);
            allTrades.push(...trades);
          }
          const wins = allTrades.filter((t) => t.pnl > 0).length;
          const totalPnl = allTrades.reduce((a, b) => a + b.pnl, 0);
          perScenario.push({
            scenario: sc.label,
            trades: allTrades.length,
            wins,
            losses: allTrades.length - wins,
            win_rate: allTrades.length > 0 ? Math.round((wins / allTrades.length) * 10000) / 100 : 0,
            total_pnl: Math.round(totalPnl * 100) / 100,
            avg_pnl: allTrades.length > 0 ? Math.round((totalPnl / allTrades.length) * 100) / 100 : 0,
          });
        }
        out[agentId] = perScenario;
      }

      return new Response(JSON.stringify({ success: true, mode: "scenarios", results: out }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // Exit lab (read-only experiment): replay the exact same signals the
    // champions produced, once with the current trailing-stop exit and once
    // with fixed SL/target only. Compares which exit rule is more profitable.
    // Touches nothing — no backtest_results writes, no champion changes.
    if (body.mode === "exit-lab") {
      const champions = await loadChampionGenomes();
      const genomes: Record<string, Genome> = {};
      for (const [agentId, info] of Object.entries(champions)) {
        genomes[agentId] = info.genome;
      }

      const variants: Array<{ label: string; opts: ExitOpts }> = [
        { label: "baseline_current", opts: {} },
        { label: "no_trailing", opts: { useTrailing: false } },
        { label: "trail_tight_lock85", opts: { trailTrigger: 0.25, trailLock: 0.85 } },
        { label: "breakeven_50pct", opts: { breakevenAt: 0.5 } },
        { label: "loss_half", opts: { stopMult: 0.5 } },
        { label: "loss_third", opts: { stopMult: 0.35 } },
        { label: "loss_quarter", opts: { stopMult: 0.25 } },
        { label: "loss_half_trail", opts: { stopMult: 0.5, trailTrigger: 0.25, trailLock: 0.85 } },
        { label: "loss_third_trail", opts: { stopMult: 0.35, trailTrigger: 0.25, trailLock: 0.85 } },
        { label: "target_big_trail", opts: { targetMult: 2, trailTrigger: 0.25, trailLock: 0.85 } },
        { label: "stops_wide_1.5x", opts: { stopMult: 1.5 } },
        { label: "stops_tight_0.7x", opts: { stopMult: 0.7 } },
        { label: "target_early_0.7x", opts: { targetMult: 0.7 } },
        { label: "target_late_1.3x", opts: { targetMult: 1.3 } },
        { label: "wide_stops_trail_tight", opts: { stopMult: 1.5, trailTrigger: 0.25, trailLock: 0.85 } },
      ];

      const stats: Record<string, Record<string, { pnl: number; trades: number; wins: number }>> = {};
      const balances: Record<string, Record<string, number>> = {};

      const runAgentOnKlines = (
        agent: "KIBO" | "YUZU" | "MATTY" | "REKT" | "APEX",
        klines: Kline[],
        symbol: string,
        riskPerTrade: number,
        leverage: number
      ) => {
        if (!stats[agent]) {
          stats[agent] = {};
          balances[agent] = {};
        }
        for (const v of variants) {
          if (stats[agent][v.label] === undefined) {
            stats[agent][v.label] = { pnl: 0, trades: 0, wins: 0 };
            balances[agent][v.label] = paperBalance;
          }
          const bal = balances[agent][v.label];
          if (bal <= 0) continue;
          const riskBudget = riskPerTrade * (bal / paperBalance);
          const { trades, endingBalance } = runBacktestForAgent(klines, symbol, agent, riskBudget, genomes[agent], leverage, bal, false, false, v.opts);
          balances[agent][v.label] = endingBalance;
          stats[agent][v.label].trades += trades.length;
          stats[agent][v.label].pnl += trades.reduce((a, b) => a + b.pnl, 0);
          stats[agent][v.label].wins += trades.filter((t) => t.pnl > 0).length;
        }
      };

      const limit1h = 720;
      for (const symbol of symbols) {
        const leverage = leverageTiers[symbol] || 10;
        const k1h = await fetchKlines(symbol, "60", limit1h);
        if (k1h.length >= 60) {
          runAgentOnKlines("KIBO", k1h, symbol, maxDollarRisk, leverage);
          runAgentOnKlines("YUZU", k1h, symbol, maxDollarRisk, leverage);
        }
        const k5m = await fetchKlines(symbol, "5", 1000);
        if (k5m.length >= 60) {
          runAgentOnKlines("MATTY", k5m, symbol, maxDollarRisk, leverage);
        }
      }

      const topMovers = await fetchTopMoversPerp(50_000_000, 15);
      const yuzuBlocklist = ["SOXLUSDT", "SNDKUSDT", "DOGEUSDT", "WLDUSDT"];
      const yuzuTopMovers = topMovers.slice(5).filter((s) => !yuzuBlocklist.includes(s));
      for (const sym of yuzuTopMovers) {
        const k1h = await fetchKlines(sym, "60", limit1h, "linear");
        if (k1h.length >= 60) runAgentOnKlines("YUZU", k1h, sym, maxDollarRisk, 50);
      }
      for (const sym of topMovers) {
        const k1m = await fetchKlines(sym, "1", 1000, "linear");
        if (k1m.length >= 60) runAgentOnKlines("REKT", k1m, sym, maxDollarRisk, 50);
        const k5m = await fetchKlines(sym, "5", 1000, "linear");
        if (k5m.length >= 60) runAgentOnKlines("APEX", k5m, sym, maxDollarRisk, 50);
      }

      const results = Object.entries(stats).map(([agent, variantsMap]) => ({
        agent_id: agent,
        variants: Object.entries(variantsMap)
          .map(([label, s]) => ({
            exit_variant: label,
            total_pnl: Math.round(s.pnl * 100) / 100,
            total_trades: s.trades,
            wins: s.wins,
            win_rate: s.trades > 0 ? Math.round((s.wins / s.trades) * 10000) / 100 : 0,
          }))
          .sort((a, b) => b.total_pnl - a.total_pnl),
      }));

      return new Response(
        JSON.stringify({ success: true, mode: "exit-lab", results }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Evolution mode
    if (body.mode === "evolve") {
      const evoResult = await runEvolution(symbols, periodDays, maxDollarRisk, leverageTiers, paperBalance);

      return new Response(
        JSON.stringify({
          success: true,
          mode: "evolve",
          generation: evoResult.generation,
          results: evoResult.results,
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Normal backtest mode (uses champion genomes)
    const results = await runNormalBacktest(symbols, periodDays, maxDollarRisk, leverageTiers, paperBalance);

    // Clear old results before inserting new ones
    await supabase.from("backtest_results").delete().neq("id", "00000000-0000-0000-0000-000000000000");

    for (const result of results) {
      await supabase.from("backtest_results").insert({
        agent_id: result.agent_id,
        symbol: result.symbol,
        period_days: result.period_days,
        total_trades: result.total_trades,
        wins: result.wins,
        losses: result.losses,
        blocked: result.blocked,
        win_rate: result.win_rate,
        total_pnl: result.total_pnl,
        avg_win: result.avg_win,
        avg_loss: result.avg_loss,
        biggest_win: result.biggest_win,
        biggest_loss: result.biggest_loss,
        max_drawdown: result.max_drawdown,
        profit_factor: result.profit_factor,
        sharpe_ratio: result.sharpe_ratio,
        trades_json: result.trades_json,
      });
    }

    return new Response(
      JSON.stringify({
        success: true,
        results: results.map((r) => ({
          agent_id: r.agent_id,
          symbol: r.symbol,
          total_trades: r.total_trades,
          wins: r.wins,
          losses: r.losses,
          win_rate: r.win_rate,
          total_pnl: r.total_pnl,
          profit_factor: r.profit_factor,
          sharpe_ratio: r.sharpe_ratio,
          max_drawdown: r.max_drawdown,
        })),
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message, success: false }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
