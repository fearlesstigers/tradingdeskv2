import { useEffect, useState, useCallback } from "react";
import { supabase, EDGE_FUNCTION_URL, BACKTEST_FUNCTION_URL } from "@/lib/supabase";
import type { Agent as AgentType, AgentStats, PaperTrade, SystemConfig, RunLog, BacktestResult, AgentSymbolStat, AgentGenome, EvolutionResult, ApexStrategyStat } from "@/lib/types";
import { AGENT_META } from "@/lib/types";
import { AgentCard } from "@/components/AgentCard";
import { Leaderboard } from "@/components/Leaderboard";
import { TradeLog } from "@/components/TradeLog";
import { StatsHeader } from "@/components/StatsHeader";
import { RunHistory } from "@/components/RunHistory";
import { Backtest } from "@/components/Backtest";
import { Evolution } from "@/components/Evolution";
import { ResearchConsole } from "@/components/ResearchConsole";
import { useLivePrices } from "@/lib/useLivePrices";
import { Fish, ShieldAlert, Rocket, Target, ClipboardList, ShieldCheck, Activity, Pause, Play, RefreshCw, TrendingUp, TrendingDown, Zap, Repeat, Dna, Flame, Crown, FlipHorizontal2 } from "lucide-react";

const AGENT_ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  ShieldCheck,
  Fish,
  ShieldAlert,
  Rocket,
  Target,
  ClipboardList,
  Repeat,
  Flame,
  Crown,
  FlipHorizontal2,
};

export default function App() {
  const [agents, setAgents] = useState<AgentType[]>([]);
  const [stats, setStats] = useState<AgentStats[]>([]);
  const [trades, setTrades] = useState<PaperTrade[]>([]);
  const [config, setConfig] = useState<SystemConfig | null>(null);
  const [runLogs, setRunLogs] = useState<RunLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [triggering, setTriggering] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const [activeTab, setActiveTab] = useState<"trades" | "history" | "backtest" | "evolution">("trades");
  const [toast, setToast] = useState<{ msg: string; type: "success" | "error" | "info" } | null>(null);
  const [backtestResults, setBacktestResults] = useState<BacktestResult[]>([]);
  const [backtestRunning, setBacktestRunning] = useState(false);
  const [symbolStats, setSymbolStats] = useState<AgentSymbolStat[]>([]);
  const [genomes, setGenomes] = useState<AgentGenome[]>([]);
  const [evolving, setEvolving] = useState(false);
  const [lastEvolution, setLastEvolution] = useState<EvolutionResult[] | null>(null);
  const [evolutionGeneration, setEvolutionGeneration] = useState<number | null>(null);
  const [apexStrategies, setApexStrategies] = useState<ApexStrategyStat[]>([]);

  const fetchAll = useCallback(async () => {
    const [agentsRes, statsRes, tradesRes, configRes, logsRes, backtestRes, symbolStatsRes, genomesRes, apexRes] = await Promise.all([
      supabase.from("agents").select("*").order("id"),
      supabase.from("agent_stats").select("*").order("total_pnl", { ascending: false }),
      supabase.from("paper_trades").select("*").order("opened_at", { ascending: false }).limit(100),
      supabase.from("system_config").select("*").eq("id", 1).maybeSingle(),
      supabase.from("run_log").select("*").order("started_at", { ascending: false }).limit(20),
      supabase.from("backtest_results").select("*").order("created_at", { ascending: false }).limit(100),
      supabase.from("agent_symbol_stats").select("*").order("total_pnl", { ascending: false }),
      supabase.from("agent_genomes").select("*").order("created_at", { ascending: false }).limit(30),
      supabase.from("apex_strategy_stats").select("*").order("weight", { ascending: false }),
    ]);

    const champs = (genomesRes.data as AgentGenome[]) || [];
    if (champs.length > 0) {
      const champ = champs.find((g) => g.is_champion);
      if (champ) setEvolutionGeneration(champ.generation);
    }

    if (agentsRes.data) setAgents(agentsRes.data);
    if (statsRes.data) setStats(statsRes.data);
    setTrades((tradesRes.data as PaperTrade[]) || []);
    if (configRes.data) setConfig(configRes.data as SystemConfig);
    if (logsRes.data) setRunLogs((logsRes.data as RunLog[]) || []);
    setBacktestResults((backtestRes.data as BacktestResult[]) || []);
    setSymbolStats((symbolStatsRes.data as AgentSymbolStat[]) || []);
    setGenomes((genomesRes.data as AgentGenome[]) || []);
    setApexStrategies((apexRes.data as ApexStrategyStat[]) || []);
    setLastUpdate(new Date());
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchAll();
    const interval = setInterval(fetchAll, 30000);
    return () => clearInterval(interval);
  }, [fetchAll]);

  // Realtime subscriptions
  useEffect(() => {
    const channel = supabase
      .channel("trading-dashboard")
      .on("postgres_changes", { event: "*", schema: "public", table: "paper_trades" }, () => fetchAll())
      .on("postgres_changes", { event: "*", schema: "public", table: "agent_stats" }, () => fetchAll())
      .on("postgres_changes", { event: "*", schema: "public", table: "system_config" }, () => fetchAll())
      .on("postgres_changes", { event: "*", schema: "public", table: "run_log" }, () => fetchAll())
      .on("postgres_changes", { event: "*", schema: "public", table: "agent_symbol_stats" }, () => fetchAll())
      .on("postgres_changes", { event: "*", schema: "public", table: "agent_genomes" }, () => fetchAll())
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [fetchAll]);

  const livePrices = useLivePrices(trades);

  const unrealizedPnl = trades
    .filter((t) => t.status === "OPEN")
    .reduce((sum, t) => {
      const livePrice = livePrices[t.symbol];
      if (!livePrice || !t.entry_price || !t.simulated_size || !t.stop_price) return sum;
      const isShort = t.stop_price > t.entry_price;
      const priceDiff = isShort ? t.entry_price - livePrice : livePrice - t.entry_price;
      return sum + (priceDiff / t.entry_price) * t.simulated_size;
    }, 0);

  const showToast = (msg: string, type: "success" | "error" | "info" = "info") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 5000);
  };

  const triggerEngine = async () => {
    setTriggering(true);
    showToast("Running engine cycle...", "info");
    try {
      const res = await fetch(EDGE_FUNCTION_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ manual: true }),
      });
      if (!res.ok) {
        showToast(`Engine returned error (${res.status})`, "error");
      } else {
        const data = await res.json();
        if (data.success) {
          showToast(
            `Cycle complete: ${data.opened} opened, ${data.closed} closed, ${data.blocked} blocked`,
            data.opened > 0 ? "success" : "info"
          );
        } else {
          showToast(data.error || "Engine returned an error", "error");
        }
      }
      await fetchAll();
    } catch (err) {
      showToast(`Failed to reach engine: ${err instanceof Error ? err.message : "network error"}`, "error");
    }
    setTriggering(false);
  };

  const runEvolution = async () => {
    setEvolving(true);
    showToast("Evolving agents — mutating parameters and testing variants...", "info");
    try {
      const res = await fetch(BACKTEST_FUNCTION_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mode: "evolve" }),
      });
      if (!res.ok) {
        showToast(`Evolution returned error (${res.status})`, "error");
      } else {
        const data = await res.json();
        if (data.success && data.results) {
          const improved = data.results.filter((r: EvolutionResult) => r.improved).length;
          setLastEvolution(data.results);
          setEvolutionGeneration(data.generation);
          showToast(
            `Generation ${data.generation}: ${improved}/${data.results.length} agents evolved better parameters`,
            improved > 0 ? "success" : "info"
          );
        } else {
          showToast(data.error || "Evolution returned an error", "error");
        }
      }
      await fetchAll();
    } catch (err) {
      showToast(`Failed to run evolution: ${err instanceof Error ? err.message : "network error"}`, "error");
    }
    setEvolving(false);
  };

  const runBacktest = async () => {
    setBacktestRunning(true);
    showToast("Running 30-day backtest across all watchlist symbols...", "info");
    try {
      const res = await fetch(BACKTEST_FUNCTION_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      if (!res.ok) {
        showToast(`Backtest returned error (${res.status})`, "error");
      } else {
        const data = await res.json();
        if (data.success) {
          const totalTrades = data.results?.reduce((a: number, b: { total_trades: number }) => a + b.total_trades, 0) || 0;
          showToast(`Backtest complete: ${totalTrades} simulated trades across ${data.results?.length || 0} agent-symbol pairs`, "success");
        } else {
          showToast(data.error || "Backtest returned an error", "error");
        }
      }
      await fetchAll();
    } catch (err) {
      showToast(`Failed to run backtest: ${err instanceof Error ? err.message : "network error"}`, "error");
    }
    setBacktestRunning(false);
  };

  const toggleRunning = async () => {
    if (!config) return;
    const newState = !config.is_running;
    await supabase.from("system_config").update({ is_running: newState }).eq("id", 1);
    showToast(newState ? "Engine resumed" : "Engine paused", "info");
    await fetchAll();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0e17] flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <RefreshCw className="w-8 h-8 text-sky-400 animate-spin" />
          <p className="text-slate-400 text-sm">Loading trading desk...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0e17] text-slate-200">
      {/* Background gradient */}
      <div className="fixed inset-0 bg-gradient-to-b from-[#0a0e17] via-[#0d1220] to-[#0a0e17] pointer-events-none" />
      <div className="fixed inset-0 bg-[radial-gradient(ellipse_at_top,_rgba(56,189,248,0.08),transparent_50%)] pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 py-6">
        {/* Toast notification */}
        {toast && (
          <div
            className={`fixed top-6 right-6 z-50 px-4 py-3 rounded-lg border shadow-xl text-sm font-medium animate-in fade-in slide-in-from-top-2 duration-300 ${
              toast.type === "success"
                ? "bg-emerald-500/15 border-emerald-500/30 text-emerald-300"
                : toast.type === "error"
                ? "bg-red-500/15 border-red-500/30 text-red-300"
                : "bg-sky-500/15 border-sky-500/30 text-sky-300"
            }`}
          >
            {toast.msg}
          </div>
        )}

        {/* Header */}
        <header className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-sky-500 to-emerald-500 flex items-center justify-center shadow-lg shadow-sky-500/20">
              <Activity className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white tracking-tight">Paper Trading Desk</h1>
              <p className="text-xs text-slate-500">Trading Desk V2 · Research & Paper Mode</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-800/50 border border-slate-700/50">
              <span className={`w-2 h-2 rounded-full ${config?.is_running ? "bg-emerald-400 animate-pulse" : "bg-slate-500"}`} />
              <span className="text-xs font-medium text-slate-400">
                {config?.is_running ? "Engine Active" : "Engine Paused"}
              </span>
            </div>
            <button
              onClick={triggerEngine}
              disabled={triggering}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-sky-500/20 hover:bg-sky-500/30 border border-sky-500/30 text-sky-300 text-xs font-medium transition-colors disabled:opacity-50"
            >
              <Zap className="w-3.5 h-3.5" />
              {triggering ? "Running..." : "Run Now"}
            </button>
            <button
              onClick={toggleRunning}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800/50 hover:bg-slate-700/50 border border-slate-700/50 text-slate-300 text-xs font-medium transition-colors"
            >
              {config?.is_running ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              {config?.is_running ? "Pause" : "Resume"}
            </button>
          </div>
        </header>

        {/* Stats Header */}
        <StatsHeader config={config} lastUpdate={lastUpdate} unrealizedPnl={unrealizedPnl} />

        <ResearchConsole trades={trades} />

        {/* Agent Cards Grid */}
        <section className="mt-8">
          <div className="flex items-center gap-2 mb-4">
            <h2 className="text-sm font-semibold text-slate-400 uppercase tracking-wider">Trading Agents</h2>
            <div className="h-px flex-1 bg-gradient-to-r from-slate-700/50 to-transparent" />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {agents.map((agent) => {
              const stat = stats.find((s) => s.agent_id === agent.id);
              const meta = AGENT_META[agent.id];
              const Icon = AGENT_ICONS[meta?.icon || "Activity"];
              return (
                <AgentCard
                  key={agent.id}
                  agent={agent}
                  stats={stat}
                  icon={<Icon className="w-5 h-5" />}
                  meta={meta}
                  symbolStats={symbolStats.filter((s) => s.agent_id === agent.id)}
                  strategyStats={agent.id === "APEX" ? apexStrategies : undefined}
                />
              );
            })}
          </div>
        </section>

        {/* Leaderboard */}
        <section className="mt-8">
          <Leaderboard stats={stats} />
        </section>

        {/* Tabbed section: Trade Log / Run History */}
        <section className="mt-8 mb-12">
          <div className="flex items-center gap-2 mb-4">
            <h2 className="text-sm font-semibold text-slate-400 uppercase tracking-wider">Activity Log</h2>
            <div className="h-px flex-1 bg-gradient-to-r from-slate-700/50 to-transparent" />
          </div>

          <div className="flex gap-1 mb-4 p-1 bg-slate-800/30 rounded-lg border border-slate-700/30 w-fit">
            <button
              onClick={() => setActiveTab("trades")}
              className={`px-4 py-1.5 rounded-md text-xs font-medium transition-colors ${
                activeTab === "trades"
                  ? "bg-slate-700 text-white"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              Trade Log ({trades.length})
            </button>
            <button
              onClick={() => setActiveTab("history")}
              className={`px-4 py-1.5 rounded-md text-xs font-medium transition-colors ${
                activeTab === "history"
                  ? "bg-slate-700 text-white"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              Engine Runs ({runLogs.length})
            </button>
            <button
              onClick={() => setActiveTab("backtest")}
              className={`px-4 py-1.5 rounded-md text-xs font-medium transition-colors ${
                activeTab === "backtest"
                  ? "bg-slate-700 text-white"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              Backtest ({backtestResults.length > 0 ? "Ready" : "New"})
            </button>
            <button
              onClick={() => setActiveTab("evolution")}
              className={`px-4 py-1.5 rounded-md text-xs font-medium transition-colors flex items-center gap-1 ${
                activeTab === "evolution"
                  ? "bg-slate-700 text-white"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              <Dna className="w-3 h-3" />
              Evolution
            </button>
          </div>

          {activeTab === "trades" ? (
            <TradeLog trades={trades} livePrices={livePrices} />
          ) : activeTab === "history" ? (
            <RunHistory logs={runLogs} />
          ) : activeTab === "backtest" ? (
            <Backtest results={backtestResults} onRun={runBacktest} running={backtestRunning} />
          ) : (
            <Evolution
              genomes={genomes}
              onEvolve={runEvolution}
              evolving={evolving}
              lastEvolution={lastEvolution}
              evolutionGeneration={evolutionGeneration}
            />
          )}
        </section>

        {/* Footer */}
        <footer className="border-t border-slate-800/50 pt-6 pb-8">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs text-slate-500">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5">
                <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
                PAPER MODE — No real trades are placed
              </span>
              <span className="flex items-center gap-1.5">
                <TrendingDown className="w-3.5 h-3.5 text-slate-500" />
                Data: Bybit Public API
              </span>
            </div>
            <p className="text-slate-600">
              Runs every {config?.trade_interval_minutes || 5} min via Supabase cron — works even when your PC is off
            </p>
          </div>
        </footer>
      </div>
    </div>
  );
}
