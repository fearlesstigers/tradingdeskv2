import type { AgentStats } from "@/lib/types";
import { AGENT_META } from "@/lib/types";
import { Trophy, ArrowUp, ArrowDown, Minus } from "lucide-react";

interface Props {
  stats: AgentStats[];
}

export function Leaderboard({ stats }: Props) {
  const sorted = [...stats].sort((a, b) => b.total_pnl - a.total_pnl);

  return (
    <div className="rounded-xl bg-slate-900/40 border border-slate-800/50 overflow-hidden">
      <div className="flex items-center gap-2 px-5 py-3 border-b border-slate-800/50">
        <Trophy className="w-4 h-4 text-amber-400" />
        <h3 className="text-sm font-semibold text-slate-300">Agent Leaderboard</h3>
        <span className="text-xs text-slate-600 ml-auto">Ranked by total P&L</span>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-xs text-slate-500 border-b border-slate-800/50">
              <th className="text-left font-medium px-5 py-2">Rank</th>
              <th className="text-left font-medium px-3 py-2">Agent</th>
              <th className="text-right font-medium px-3 py-2">Trades</th>
              <th className="text-right font-medium px-3 py-2">W/L</th>
              <th className="text-right font-medium px-3 py-2">Win Rate</th>
              <th className="text-right font-medium px-3 py-2">Avg Win</th>
              <th className="text-right font-medium px-3 py-2">Avg Loss</th>
              <th className="text-right font-medium px-3 py-2">Blocked</th>
              <th className="text-right font-medium px-5 py-2">Total P&L</th>
            </tr>
          </thead>
          <tbody>
            {sorted.map((stat, idx) => {
              const meta = AGENT_META[stat.agent_id];
              const pnlPositive = stat.total_pnl >= 0;
              const rankIcon =
                idx === 0 ? <Trophy className="w-3.5 h-3.5 text-amber-400" /> :
                idx === 1 ? <span className="text-slate-300 text-xs">{idx + 1}</span> :
                <span className="text-slate-500 text-xs">{idx + 1}</span>;

              return (
                <tr
                  key={stat.agent_id}
                  className="border-b border-slate-800/30 hover:bg-slate-800/20 transition-colors"
                >
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-1.5">{rankIcon}</div>
                  </td>
                  <td className="px-3 py-3">
                    <div className="flex items-center gap-2">
                      <span className={`w-2 h-2 rounded-full ${meta ? meta.bgColor.replace("/10", "/60") : "bg-slate-600"}`} />
                      <span className={`font-semibold ${meta?.color || "text-slate-300"}`}>
                        {stat.agent_id}
                      </span>
                    </div>
                  </td>
                  <td className="px-3 py-3 text-right text-slate-400">{stat.total_trades}</td>
                  <td className="px-3 py-3 text-right">
                    <span className="text-emerald-400">{stat.wins}</span>
                    <span className="text-slate-600">/</span>
                    <span className="text-red-400">{stat.losses}</span>
                  </td>
                  <td className="px-3 py-3 text-right text-slate-300">
                    {stat.win_rate.toFixed(0)}%
                  </td>
                  <td className="px-3 py-3 text-right text-emerald-400">
                    ${stat.avg_win.toFixed(2)}
                  </td>
                  <td className="px-3 py-3 text-right text-red-400">
                    -${Math.abs(stat.avg_loss).toFixed(2)}
                  </td>
                  <td className="px-3 py-3 text-right text-amber-400">{stat.blocked}</td>
                  <td className="px-5 py-3 text-right">
                    <span
                      className={`font-bold flex items-center justify-end gap-1 ${
                        pnlPositive ? "text-emerald-400" : "text-red-400"
                      }`}
                    >
                      {pnlPositive ? <ArrowUp className="w-3 h-3" /> : stat.total_pnl === 0 ? <Minus className="w-3 h-3 text-slate-500" /> : <ArrowDown className="w-3 h-3" />}
                      {pnlPositive ? "+" : ""}${Math.abs(stat.total_pnl).toFixed(2)}
                    </span>
                  </td>
                </tr>
              );
            })}
            {sorted.length === 0 && (
              <tr>
                <td colSpan={9} className="text-center py-8 text-slate-500 text-sm">
                  No stats yet — the engine will populate this after the first cycle
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
