import { useState, useMemo } from "react";
import type { PaperTrade } from "@/lib/types";
import { AGENT_META } from "@/lib/types";
import {
  CheckCircle2,
  XCircle,
  Clock,
  Ban,
  ArrowUpRight,
  ArrowDownRight,
  TrendingUp,
  TrendingDown,
  Filter,
} from "lucide-react";

interface Props {
  trades: PaperTrade[];
  livePrices: Record<string, number>;
}

type StatusFilter = "all" | "open" | "closed" | "blocked";

export function TradeLog({ trades, livePrices }: Props) {
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");
  const [agentFilter, setAgentFilter] = useState<string>("all");

  const openTrades = trades.filter((t) => t.status === "OPEN");
  const closedTrades = trades.filter((t) => t.status === "CLOSED");
  const blockedTrades = trades.filter((t) => t.status === "BLOCKED");

  const totalUnrealized = openTrades.reduce((sum, t) => {
    const livePrice = livePrices[t.symbol];
    if (!livePrice || !t.entry_price || !t.simulated_size || !t.stop_price) return sum;
    const isShort = t.stop_price > t.entry_price;
    const priceDiff = isShort ? t.entry_price - livePrice : livePrice - t.entry_price;
    return sum + (priceDiff / t.entry_price) * t.simulated_size;
  }, 0);

  const realizedPnl = closedTrades.reduce((sum, t) => sum + (t.pnl ?? 0), 0);

  // Get unique agents that have trades
  const agentIds = useMemo(
    () => [...new Set(trades.map((t) => t.agent_id))].sort(),
    [trades]
  );

  const filteredTrades = useMemo(() => {
    return trades.filter((t) => {
      if (statusFilter !== "all" && t.status.toLowerCase() !== statusFilter) return false;
      if (agentFilter !== "all" && t.agent_id !== agentFilter) return false;
      return true;
    });
  }, [trades, statusFilter, agentFilter]);

  if (trades.length === 0) {
    return (
      <div className="rounded-xl bg-slate-900/40 border border-slate-800/50 p-12 text-center">
        <Clock className="w-8 h-8 text-slate-600 mx-auto mb-3" />
        <p className="text-slate-500 text-sm">
          No trades yet. The engine runs every 2 minutes — trades will appear here automatically.
        </p>
        <p className="text-slate-600 text-xs mt-2">
          Use the "Run Now" button above to trigger a cycle immediately.
        </p>
      </div>
    );
  }

  const filterButtons: { key: StatusFilter; label: string; count: number }[] = [
    { key: "all", label: "All", count: trades.length },
    { key: "open", label: "Open", count: openTrades.length },
    { key: "closed", label: "Closed", count: closedTrades.length },
    { key: "blocked", label: "Blocked", count: blockedTrades.length },
  ];

  return (
    <div className="rounded-xl bg-slate-900/40 border border-slate-800/50 overflow-hidden">
      {/* Summary bar */}
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-slate-800/50 bg-slate-900/60 flex-wrap gap-2">
        <div className="flex items-center gap-4">
          {openTrades.length > 0 && (
            <span className="text-xs text-slate-500 flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-sky-400 animate-pulse" />
              {openTrades.length} open ·
              <span className={totalUnrealized >= 0 ? "text-emerald-400 font-medium" : "text-red-400 font-medium"}>
                {totalUnrealized >= 0 ? "+" : "-"}${Math.abs(totalUnrealized).toFixed(2)}
              </span>
            </span>
          )}
          {closedTrades.length > 0 && (
            <span className="text-xs text-slate-500 flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-slate-500" />
              {closedTrades.length} closed ·
              <span className={realizedPnl >= 0 ? "text-emerald-400 font-medium" : "text-red-400 font-medium"}>
                {realizedPnl >= 0 ? "+" : "-"}${Math.abs(realizedPnl).toFixed(2)}
              </span>
            </span>
          )}
          {blockedTrades.length > 0 && (
            <span className="text-xs text-slate-500 flex items-center gap-1.5">
              <Ban className="w-3 h-3 text-amber-400" />
              {blockedTrades.length} blocked
            </span>
          )}
        </div>
      </div>

      {/* Filter controls */}
      <div className="flex items-center gap-3 px-4 py-2.5 border-b border-slate-800/50 bg-slate-900/30 flex-wrap">
        <div className="flex gap-1 p-0.5 bg-slate-800/30 rounded-lg border border-slate-700/30">
          {filterButtons.map((btn) => (
            <button
              key={btn.key}
              onClick={() => setStatusFilter(btn.key)}
              className={`px-3 py-1 rounded-md text-xs font-medium transition-colors ${
                statusFilter === btn.key
                  ? "bg-slate-700 text-white"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              {btn.label} ({btn.count})
            </button>
          ))}
        </div>

        <div className="flex items-center gap-1.5">
          <Filter className="w-3 h-3 text-slate-600" />
          <select
            value={agentFilter}
            onChange={(e) => setAgentFilter(e.target.value)}
            className="bg-slate-800/50 border border-slate-700/50 rounded-md text-xs text-slate-300 px-2 py-1 outline-none focus:border-sky-500/50"
          >
            <option value="all">All Agents</option>
            {agentIds.map((id) => {
              const count = trades.filter((t) => t.agent_id === id).length;
              return (
                <option key={id} value={id}>
                  {id} ({count})
                </option>
              );
            })}
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-xs text-slate-500 border-b border-slate-800/50 bg-slate-900/60">
              <th className="text-left font-medium px-4 py-2.5">Status</th>
              <th className="text-left font-medium px-3 py-2.5">Agent</th>
              <th className="text-left font-medium px-3 py-2.5">Symbol</th>
              <th className="text-right font-medium px-3 py-2.5">Entry</th>
              <th className="text-right font-medium px-3 py-2.5">Live / Exit</th>
              <th className="text-right font-medium px-3 py-2.5">Stop</th>
              <th className="text-right font-medium px-3 py-2.5">Target</th>
              <th className="text-right font-medium px-2 py-2.5">Liq</th>
              <th className="text-center font-medium px-2 py-2.5">M</th>
              <th className="text-center font-medium px-2 py-2.5">R</th>
              <th className="text-center font-medium px-2 py-2.5">S</th>
              <th className="text-right font-medium px-3 py-2.5">P&L</th>
              <th className="text-left font-medium px-3 py-2.5">Reason</th>
              <th className="text-left font-medium px-4 py-2.5">Time</th>
            </tr>
          </thead>
          <tbody>
            {filteredTrades.length === 0 ? (
              <tr>
                <td colSpan={14} className="text-center py-8 text-slate-600 text-xs">
                  No trades match this filter
                </td>
              </tr>
            ) : (
              filteredTrades.map((trade) => {
                const meta = AGENT_META[trade.agent_id];
                const isOpen = trade.status === "OPEN";
                const isBlocked = trade.status === "BLOCKED";
                const isClosed = trade.status === "CLOSED";
                const livePrice = livePrices[trade.symbol];

                let pnl: number | null = null;
                let pnlPct: number | null = null;
                let isUnrealized = false;

                if (isClosed) {
                  pnl = trade.pnl ?? 0;
                  pnlPct = trade.pnl_pct ?? 0;
                } else if (isOpen && livePrice && trade.entry_price && trade.simulated_size && trade.stop_price) {
                  const isShort = trade.stop_price > trade.entry_price;
                  const priceDiff = isShort ? trade.entry_price - livePrice : livePrice - trade.entry_price;
                  pnl = (priceDiff / trade.entry_price) * trade.simulated_size;
                  pnlPct = trade.entry_price > 0 ? (priceDiff / trade.entry_price) * 100 : 0;
                  isUnrealized = true;
                }

                const pnlPositive = (pnl ?? 0) >= 0;

                let progressPct: number | null = null;
                if (isOpen && livePrice && trade.entry_price && trade.stop_price && trade.target_price) {
                  const isShort = trade.stop_price > trade.entry_price;
                  const totalRange = Math.abs(trade.target_price - trade.stop_price);
                  if (totalRange > 0) {
                    const progress = isShort
                      ? ((trade.stop_price - livePrice) / totalRange) * 100
                      : ((livePrice - trade.stop_price) / totalRange) * 100;
                    progressPct = Math.max(0, Math.min(100, progress));
                  }
                }

                const closeReasonLabel = getCloseReasonLabel(trade.close_reason);

                return (
                  <tr
                    key={trade.id}
                    className={`border-b border-slate-800/30 hover:bg-slate-800/20 transition-colors ${
                      isClosed && pnl !== null && pnl < 0 ? "bg-red-950/10" : ""
                    } ${isClosed && pnl !== null && pnl > 0 ? "bg-emerald-950/10" : ""}`}
                  >
                    <td className="px-4 py-2.5">
                      <StatusBadge status={trade.status} />
                    </td>
                    <td className="px-3 py-2.5">
                      <span className={`font-semibold text-xs ${meta?.color || "text-slate-400"}`}>
                        {trade.agent_id}
                      </span>
                    </td>
                    <td className="px-3 py-2.5 text-slate-300 font-medium text-xs">
                      {trade.symbol}
                    </td>
                    <td className="px-3 py-2.5 text-right text-slate-400 text-xs">
                      {trade.entry_price ? formatPrice(trade.entry_price) : "—"}
                    </td>
                    <td className="px-3 py-2.5 text-right text-xs">
                      {isOpen && livePrice ? (
                        <span className="text-sky-300 font-medium">{formatPrice(livePrice)}</span>
                      ) : isOpen ? (
                        <span className="text-slate-600 animate-pulse">...</span>
                      ) : isClosed && trade.exit_price ? (
                        <span className="text-slate-300 font-medium">{formatPrice(trade.exit_price)}</span>
                      ) : (
                        <span className="text-slate-700">—</span>
                      )}
                    </td>
                    <td className="px-3 py-2.5 text-right text-red-400/70 text-xs">
                      {trade.stop_price ? formatPrice(trade.stop_price) : "—"}
                    </td>
                    <td className="px-3 py-2.5 text-right text-emerald-400/70 text-xs">
                      {trade.target_price ? formatPrice(trade.target_price) : "—"}
                    </td>
                    <td className="px-2 py-2.5 text-right text-orange-400/60 text-xs">
                      {trade.liquidation_price ? formatPrice(trade.liquidation_price) : "—"}
                    </td>
                    <td className="px-2 py-2.5 text-center">
                      <PassFail value={trade.momo_pass} />
                    </td>
                    <td className="px-2 py-2.5 text-center">
                      {trade.rin_pass !== null ? (
                        <PassFail value={trade.rin_pass} />
                      ) : (
                        <span className="text-slate-700 text-xs">—</span>
                      )}
                    </td>
                    <td className="px-2 py-2.5 text-center">
                      {trade.sora_decision ? (
                        <span
                          className={`text-xs font-medium ${
                            trade.sora_decision === "APPROVE" ? "text-emerald-400" : "text-red-400"
                          }`}
                        >
                          {trade.sora_decision === "APPROVE" ? "✓" : "✗"}
                        </span>
                      ) : (
                        <span className="text-slate-700 text-xs">—</span>
                      )}
                    </td>
                    <td className="px-3 py-2.5 text-right">
                      {isBlocked ? (
                        <span className="text-slate-600 text-xs">—</span>
                      ) : pnl !== null ? (
                        <div className="flex flex-col items-end gap-1">
                          <span
                            className={`text-xs font-bold flex items-center justify-end gap-0.5 ${
                              pnlPositive ? "text-emerald-400" : "text-red-400"
                            }`}
                          >
                            {pnlPositive ? (
                              <ArrowUpRight className="w-3 h-3" />
                            ) : (
                              <ArrowDownRight className="w-3 h-3" />
                            )}
                            {pnlPositive ? "+" : "-"}${Math.abs(pnl).toFixed(2)}
                          </span>
                          {pnlPct !== null && (
                            <span
                              className={`text-[10px] ${
                                pnlPositive ? "text-emerald-500/60" : "text-red-500/60"
                              }`}
                            >
                              {pnlPositive ? "+" : ""}
                              {pnlPct.toFixed(2)}%
                            </span>
                          )}
                          {isUnrealized && (
                            <span className="text-[10px] text-slate-600 font-normal">unrealized</span>
                          )}
                          {isOpen && progressPct !== null && (
                            <div className="w-20 h-1 bg-slate-800 rounded-full overflow-hidden">
                              <div
                                className={`h-full rounded-full transition-all duration-500 ${
                                  pnlPositive
                                    ? "bg-gradient-to-r from-emerald-500 to-emerald-400"
                                    : "bg-gradient-to-r from-red-500 to-red-400"
                                }`}
                                style={{ width: `${progressPct}%` }}
                              />
                            </div>
                          )}
                        </div>
                      ) : (
                        <span className="text-slate-600 text-xs">—</span>
                      )}
                    </td>
                    <td className="px-3 py-2.5 text-xs">
                      {isBlocked && trade.block_reason ? (
                        <span className="text-amber-400/70 text-[11px] leading-tight block max-w-[180px] truncate" title={trade.block_reason}>
                          {trade.block_reason.split("|")[0].trim()}
                        </span>
                      ) : isClosed && closeReasonLabel ? (
                        <span
                          className={`text-[11px] font-medium flex items-center gap-1 ${
                            closeReasonLabel.type === "win"
                              ? "text-emerald-400"
                              : closeReasonLabel.type === "loss"
                              ? "text-red-400"
                              : "text-slate-400"
                            }`}
                        >
                          {closeReasonLabel.type === "win" ? (
                            <TrendingUp className="w-3 h-3" />
                          ) : closeReasonLabel.type === "loss" ? (
                            <TrendingDown className="w-3 h-3" />
                          ) : null}
                          {closeReasonLabel.label}
                        </span>
                      ) : (
                        <span className="text-slate-700 text-xs">—</span>
                      )}
                    </td>
                    <td className="px-4 py-2.5 text-xs text-slate-600 whitespace-nowrap">
                      {formatTime(trade.opened_at)}
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function getCloseReasonLabel(
  reason: string | null
): { label: string; type: "win" | "loss" | "neutral" } | null {
  if (!reason) return null;
  switch (reason) {
    case "TARGET_HIT":
      return { label: "Target hit", type: "win" };
    case "STOP_HIT":
      return { label: "Stop hit", type: "loss" };
    case "LIQUIDATION":
      return { label: "Liquidated", type: "loss" };
    case "TRAILING_STOP_HIT":
      return { label: "Trailing stop", type: "win" };
    case "TIMEOUT":
      return { label: "Timeout", type: "neutral" };
    case "BLOCKED":
      return { label: "Blocked", type: "neutral" };
    default:
      return { label: reason, type: "neutral" };
  }
}

function StatusBadge({ status }: { status: string }) {
  if (status === "OPEN") {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-sky-500/10 text-sky-400 text-xs font-medium border border-sky-500/20">
        <span className="w-1.5 h-1.5 rounded-full bg-sky-400 animate-pulse" />
        OPEN
      </span>
    );
  }
  if (status === "BLOCKED") {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 text-xs font-medium border border-amber-500/20">
        <Ban className="w-3 h-3" />
        BLOCKED
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium border bg-slate-500/10 text-slate-400 border-slate-500/20">
      CLOSED
    </span>
  );
}

function PassFail({ value }: { value: boolean }) {
  return value ? (
    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 inline" />
  ) : (
    <XCircle className="w-3.5 h-3.5 text-red-400 inline" />
  );
}

function formatPrice(price: number): string {
  if (price >= 1000) return price.toLocaleString("en-US", { maximumFractionDigits: 2 });
  if (price >= 1) return price.toFixed(3);
  if (price >= 0.01) return price.toFixed(4);
  return price.toFixed(6);
}

function formatTime(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}
