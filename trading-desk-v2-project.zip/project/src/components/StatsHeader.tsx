import type { SystemConfig } from "@/lib/types";
import { TrendingUp, TrendingDown, DollarSign, BarChart3, AlertOctagon, Wallet, Clock, Layers, Flame, Crown, FlipHorizontal2 } from "lucide-react";

interface Props {
  config: SystemConfig | null;
  lastUpdate: Date | null;
  unrealizedPnl?: number;
}

export function StatsHeader({ config, lastUpdate, unrealizedPnl = 0 }: Props) {
  if (!config) return null;

  const pnl = config.total_team_pnl;
  const pnlPositive = pnl >= 0;
  const winRate = config.total_trades > 0
    ? ((config.total_trades - 0) / (config.total_trades + config.total_blocked) * 100).toFixed(0)
    : "0";

  const apexBalance = config.apex_compound_balance ?? config.apex_start_balance ?? 50;
  const apexStart = config.apex_start_balance ?? 50;
  const apexTarget = config.apex_target_balance ?? 5000;
  const apexPnl = apexBalance - apexStart;
  const apexPnlPositive = apexPnl >= 0;
  const apexProgress = Math.min(100, Math.max(0, ((apexBalance - apexStart) / (apexTarget - apexStart)) * 100));

  const mirageBalance = config.mirage_balance ?? 100;
  const miragePnl = mirageBalance - 100;
  const miragePnlPositive = miragePnl >= 0;

  const stats = [
    {
      label: "Paper Balance",
      value: `${config.paper_balance.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
      sublabel: "Shared team bankroll",
      icon: Wallet,
      color: "text-sky-400",
      bgColor: "bg-sky-500/10",
      borderColor: "border-sky-500/20",
    },
    {
      label: "Team P&L",
      value: `${pnlPositive ? "+" : ""}${pnl.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
      sublabel: unrealizedPnl !== 0
        ? `${unrealizedPnl >= 0 ? "+" : "-"}${Math.abs(unrealizedPnl).toFixed(2)} unrealized`
        : "All agents combined",
      icon: pnlPositive ? TrendingUp : TrendingDown,
      color: pnlPositive ? "text-emerald-400" : "text-red-400",
      bgColor: pnlPositive ? "bg-emerald-500/10" : "bg-red-500/10",
      borderColor: pnlPositive ? "border-emerald-500/20" : "border-red-500/20",
    },
    {
      label: "APEX Balance",
      value: `${apexBalance.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
      sublabel: `${apexPnlPositive ? "+" : ""}${apexPnl.toFixed(2)} | Mission: ${apexProgress.toFixed(1)}% to ${apexTarget.toLocaleString()}`,
      icon: Crown,
      color: "text-rose-400",
      bgColor: "bg-rose-500/10",
      borderColor: "border-rose-500/20",
    },
    {
      label: "MIRAGE Fund",
      value: `${mirageBalance.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
      sublabel: `${miragePnlPositive ? "+" : ""}${miragePnl.toFixed(2)} | Mirror of REKT (reversed)`,
      icon: FlipHorizontal2,
      color: miragePnlPositive ? "text-fuchsia-400" : "text-amber-400",
      bgColor: miragePnlPositive ? "bg-fuchsia-500/10" : "bg-amber-500/10",
      borderColor: miragePnlPositive ? "border-fuchsia-500/20" : "border-amber-500/20",
    },
    {
      label: "Total Trades",
      value: config.total_trades.toString(),
      sublabel: `${config.total_blocked} blocked`,
      icon: BarChart3,
      color: "text-violet-400",
      bgColor: "bg-violet-500/10",
      borderColor: "border-violet-500/20",
    },
    {
      label: "Max Risk / Trade",
      value: `${config.max_risk_per_trade_pct}%`,
      sublabel: `Team cap: ${config.max_total_risk_pct}%`,
      icon: DollarSign,
      color: "text-amber-400",
      bgColor: "bg-amber-500/10",
      borderColor: "border-amber-500/20",
    },
    {
      label: "Positions / Agent",
      value: (config.max_positions_per_agent || 3).toString(),
      sublabel: `Cycle: every ${config.trade_interval_minutes} min`,
      icon: Layers,
      color: "text-fuchsia-400",
      bgColor: "bg-fuchsia-500/10",
      borderColor: "border-fuchsia-500/20",
    },
    {
      label: "Leverage",
      value: `${config.leverage || 10}x`,
      sublabel: `All symbols: ${config.leverage_tiers?.["BTCUSDT"] || 50}x max`,
      icon: Flame,
      color: "text-orange-400",
      bgColor: "bg-orange-500/10",
      borderColor: "border-orange-500/20",
    },
    {
      label: "Watchlist",
      value: `${config.watchlist.length} symbols`,
      sublabel: config.watchlist.slice(0, 3).join(", ") + (config.watchlist.length > 3 ? "..." : ""),
      icon: AlertOctagon,
      color: "text-cyan-400",
      bgColor: "bg-cyan-500/10",
      borderColor: "border-cyan-500/20",
    },
  ];

  return (
    <div>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-8 gap-3">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div
              key={stat.label}
              className={`rounded-xl ${stat.bgColor} border ${stat.borderColor} p-4 transition-all hover:scale-[1.02] hover:shadow-lg`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-medium text-slate-400">{stat.label}</span>
                <Icon className={`w-4 h-4 ${stat.color}`} />
              </div>
              <div className={`text-lg font-bold ${stat.color}`}>{stat.value}</div>
              {stat.sublabel && (
                <div className="text-xs text-slate-500 mt-1">{stat.sublabel}</div>
              )}
            </div>
          );
        })}
      </div>
      {lastUpdate && (
        <div className="mt-2 text-xs text-slate-600 flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          Live · Last updated {lastUpdate.toLocaleTimeString()}
        </div>
      )}
    </div>
  );
}
