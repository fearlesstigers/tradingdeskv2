import { useState } from "react";
import type { BacktestResult, BacktestTrade } from "@/lib/types";
import { AGENT_META } from "@/lib/types";
import {
  FlaskConical,
  Play,
  ArrowUpRight,
  ArrowDownRight,
  TrendingUp,
  TrendingDown,
  Clock,
  ChevronDown,
  ChevronRight,
  BarChart3,
} from "lucide-react";

interface Props {
  results: BacktestResult[];
  onRun: () => void;
  running: boolean;
}

export function Backtest({ results, onRun, running }: Props) {
  const [expandedRun, setExpandedRun] = useState<string | null>(null);
  const [expandedAgent, setExpandedAgent] = useState<string | null>(null);

  // Group by created_at (each backtest run)
  const runs = results.reduce<Record<string, BacktestResult[]>>((acc, r) => {
    const key = r.created_at;
    if (!acc[key]) acc[key] = [];
    acc[key].push(r);
    return acc;
  }, {});

  const runKeys = Object.keys(runs).sort((a, b) => b.localeCompare(a));

  return (
    <div className="rounded-xl bg-slate-900/40 border border-slate-800/50 overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800/50 bg-slate-900/60">
        <div className="flex items-center gap-2">
          <FlaskConical className="w-4 h-4 text-sky-400" />
          <span className="text-sm font-medium text-slate-300">Strategy Backtest</span>
          <span className="text-xs text-slate-600">30-day historical replay</span>
        </div>
        <button
          onClick={onRun}
          disabled={running}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-sky-500/20 hover:bg-sky-500/30 border border-sky-500/30 text-sky-300 text-xs font-medium transition-colors disabled:opacity-50"
        >
          <Play className="w-3.5 h-3.5" />
          {running ? "Running..." : "Run Backtest"}
        </button>
      </div>

      {running && (
        <div className="px-4 py-8 text-center">
          <div className="inline-flex items-center gap-2 text-sm text-slate-400">
            <BarChart3 className="w-4 h-4 animate-pulse text-sky-400" />
            Fetching 30 days of hourly candles and replaying through all agents...
          </div>
        </div>
      )}

      {!running && runKeys.length === 0 && (
        <div className="px-4 py-12 text-center">
          <FlaskConical className="w-8 h-8 text-slate-600 mx-auto mb-3" />
          <p className="text-slate-500 text-sm">
            No backtests yet. Run a backtest to replay 30 days of historical data through the RIN, KIBO, and YUZU strategies.
          </p>
        </div>
      )}

      {/* Backtest runs */}
      {!running && runKeys.length > 0 && (
        <div className="divide-y divide-slate-800/30">
          {runKeys.map((runKey) => {
            const runResults = runs[runKey];
            const isExpanded = expandedRun === runKey;
            const totalTrades = runResults.reduce((a, b) => a + b.total_trades, 0);
            const totalPnl = runResults.reduce((a, b) => a + b.total_pnl, 0);
            const totalWins = runResults.reduce((a, b) => a + b.wins, 0);
            const totalLosses = runResults.reduce((a, b) => a + b.losses, 0);
            const overallWinRate = totalTrades > 0 ? (totalWins / totalTrades) * 100 : 0;
            const runDate = new Date(runKey);

            return (
              <div key={runKey}>
                {/* Run summary header */}
                <button
                  onClick={() => setExpandedRun(isExpanded ? null : runKey)}
                  className="w-full flex items-center justify-between px-4 py-3 hover:bg-slate-800/20 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    {isExpanded ? (
                      <ChevronDown className="w-4 h-4 text-slate-500" />
                    ) : (
                      <ChevronRight className="w-4 h-4 text-slate-500" />
                    )}
                    <div className="text-left">
                      <div className="text-sm text-slate-300 font-medium">
                        {runDate.toLocaleString("en-US", {
                          month: "short",
                          day: "numeric",
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </div>
                      <div className="text-xs text-slate-600">
                        {runResults.length} agent-symbol pairs · {totalTrades} simulated trades
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="text-xs text-slate-500">
                      {totalWins}W / {totalLosses}L · {overallWinRate.toFixed(1)}%
                    </span>
                    <span
                      className={`text-sm font-bold flex items-center gap-0.5 ${
                        totalPnl >= 0 ? "text-emerald-400" : "text-red-400"
                      }`}
                    >
                      {totalPnl >= 0 ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
                      {totalPnl >= 0 ? "+" : "-"}${Math.abs(totalPnl).toFixed(2)}
                    </span>
                  </div>
                </button>

                {/* Expanded results */}
                {isExpanded && (
                  <div className="px-4 pb-4 space-y-2">
                    {runResults.map((result) => {
                      const meta = AGENT_META[result.agent_id];
                      const agentKey = `${runKey}-${result.agent_id}-${result.symbol}`;
                      const isAgentExpanded = expandedAgent === agentKey;
                      const pnlPositive = result.total_pnl >= 0;

                      return (
                        <div
                          key={agentKey}
                          className="rounded-lg bg-slate-800/20 border border-slate-700/30 overflow-hidden"
                        >
                          {/* Agent-symbol summary */}
                          <button
                            onClick={() => setExpandedAgent(isAgentExpanded ? null : agentKey)}
                            className="w-full flex items-center justify-between px-3 py-2.5 hover:bg-slate-800/40 transition-colors"
                          >
                            <div className="flex items-center gap-2">
                              {isAgentExpanded ? (
                                <ChevronDown className="w-3.5 h-3.5 text-slate-600" />
                              ) : (
                                <ChevronRight className="w-3.5 h-3.5 text-slate-600" />
                              )}
                              <span className={`text-xs font-bold ${meta?.color || "text-slate-400"}`}>
                                {result.agent_id}
                              </span>
                              <span className="text-xs text-slate-500">·</span>
                              <span className="text-xs text-slate-300 font-medium">{result.symbol}</span>
                              <span className="text-xs text-slate-600">{result.total_trades} trades</span>
                            </div>
                            <div className="flex items-center gap-3">
                              <MetricChip label="Win" value={`${result.win_rate.toFixed(1)}%`} positive={result.win_rate >= 50} />
                              <MetricChip label="PF" value={result.profit_factor.toFixed(2)} positive={result.profit_factor >= 1} />
                              <MetricChip label="Sharpe" value={result.sharpe_ratio.toFixed(2)} positive={result.sharpe_ratio >= 0} />
                              <MetricChip label="MaxDD" value={`$${result.max_drawdown.toFixed(0)}`} negative />
                              <span
                                className={`text-sm font-bold flex items-center gap-0.5 ${
                                  pnlPositive ? "text-emerald-400" : "text-red-400"
                                }`}
                              >
                                {pnlPositive ? <ArrowUpRight className="w-3.5 h-3.5" /> : <ArrowDownRight className="w-3.5 h-3.5" />}
                                {pnlPositive ? "+" : "-"}${Math.abs(result.total_pnl).toFixed(2)}
                              </span>
                            </div>
                          </button>

                          {/* Trade detail table */}
                          {isAgentExpanded && (
                            <div className="border-t border-slate-700/30">
                              {/* Stat grid */}
                              <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-2 px-3 py-2.5 bg-slate-900/30">
                                <StatCell label="Wins" value={result.wins.toString()} color="text-emerald-400" />
                                <StatCell label="Losses" value={result.losses.toString()} color="text-red-400" />
                                <StatCell label="Avg Win" value={`$${result.avg_win.toFixed(2)}`} color="text-emerald-400" />
                                <StatCell label="Avg Loss" value={`$${result.avg_loss.toFixed(2)}`} color="text-red-400" />
                                <StatCell label="Biggest Win" value={`$${result.biggest_win.toFixed(2)}`} color="text-emerald-400" />
                                <StatCell label="Biggest Loss" value={`$${result.biggest_loss.toFixed(2)}`} color="text-red-400" />
                              </div>

                              {/* Individual trades */}
                              {result.trades_json && result.trades_json.length > 0 ? (
                                <div className="overflow-x-auto max-h-64 overflow-y-auto">
                                  <table className="w-full text-xs">
                                    <thead className="sticky top-0 bg-slate-900/90 backdrop-blur">
                                      <tr className="text-slate-500 border-b border-slate-800/50">
                                        <th className="text-left font-medium px-3 py-2">Result</th>
                                        <th className="text-right font-medium px-2 py-2">Entry</th>
                                        <th className="text-right font-medium px-2 py-2">Exit</th>
                                        <th className="text-right font-medium px-2 py-2">Stop</th>
                                        <th className="text-right font-medium px-2 py-2">Target</th>
                                        <th className="text-center font-medium px-2 py-2">R/R</th>
                                        <th className="text-right font-medium px-2 py-2">P&L</th>
                                        <th className="text-left font-medium px-2 py-2">Entry Time</th>
                                        <th className="text-left font-medium px-3 py-2">Reason</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                      {result.trades_json.map((trade, idx) => (
                                        <TradeRow key={idx} trade={trade} />
                                      ))}
                                    </tbody>
                                  </table>
                                </div>
                              ) : (
                                <div className="px-3 py-6 text-center text-xs text-slate-600">
                                  No trades generated for this agent-symbol combination
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function MetricChip({ label, value, positive, negative }: { label: string; value: string; positive?: boolean; negative?: boolean }) {
  const color = negative
    ? "text-amber-400"
    : positive
    ? "text-emerald-400"
    : "text-slate-400";
  return (
    <div className="flex flex-col items-end">
      <span className="text-[9px] text-slate-600 uppercase tracking-wider">{label}</span>
      <span className={`text-xs font-medium ${color}`}>{value}</span>
    </div>
  );
}

function StatCell({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <div className="flex flex-col">
      <span className="text-[10px] text-slate-600 uppercase tracking-wider">{label}</span>
      <span className={`text-sm font-medium ${color}`}>{value}</span>
    </div>
  );
}

function TradeRow({ trade }: { trade: BacktestTrade }) {
  const isWin = trade.result === "WIN";
  const isLoss = trade.result === "LOSS";
  const pnlPositive = trade.pnl >= 0;
  const entryDate = new Date(trade.entryTime);

  return (
    <tr className={`border-b border-slate-800/20 hover:bg-slate-800/20 ${isWin ? "bg-emerald-950/10" : ""} ${isLoss ? "bg-red-950/10" : ""}`}>
      <td className="px-3 py-1.5">
        {isWin ? (
          <span className="inline-flex items-center gap-1 text-emerald-400">
            <TrendingUp className="w-3 h-3" /> WIN
          </span>
        ) : isLoss ? (
          <span className="inline-flex items-center gap-1 text-red-400">
            <TrendingDown className="w-3 h-3" /> LOSS
          </span>
        ) : (
          <span className="inline-flex items-center gap-1 text-slate-400">
            <Clock className="w-3 h-3" /> TIMEOUT
          </span>
        )}
      </td>
      <td className="px-2 py-1.5 text-right text-slate-400">{formatPrice(trade.entry)}</td>
      <td className="px-2 py-1.5 text-right text-slate-300">{formatPrice(trade.exit)}</td>
      <td className="px-2 py-1.5 text-right text-red-400/60">{formatPrice(trade.stop)}</td>
      <td className="px-2 py-1.5 text-right text-emerald-400/60">{formatPrice(trade.target)}</td>
      <td className="px-2 py-1.5 text-center text-slate-500">{trade.rr.toFixed(2)}</td>
      <td className="px-2 py-1.5 text-right">
        <span className={`font-medium ${pnlPositive ? "text-emerald-400" : "text-red-400"}`}>
          {pnlPositive ? "+" : "-"}${Math.abs(trade.pnl).toFixed(2)}
        </span>
        <span className={`ml-1 text-[10px] ${pnlPositive ? "text-emerald-500/50" : "text-red-500/50"}`}>
          ({pnlPositive ? "+" : ""}{trade.pnlPct.toFixed(2)}%)
        </span>
      </td>
      <td className="px-2 py-1.5 text-slate-600 whitespace-nowrap">
        {entryDate.toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
      </td>
      <td className="px-3 py-1.5 text-slate-600 max-w-[200px] truncate" title={trade.reason}>
        {trade.reason}
      </td>
    </tr>
  );
}

function formatPrice(price: number): string {
  if (price >= 1000) return price.toLocaleString("en-US", { maximumFractionDigits: 2 });
  if (price >= 1) return price.toFixed(3);
  if (price >= 0.01) return price.toFixed(4);
  return price.toFixed(6);
}
