import { useMemo } from 'react';
import { AlertTriangle, ArrowDownRight, ArrowUpRight, BarChart3, ShieldCheck } from 'lucide-react';
import type { PaperTrade } from '@/lib/types';

type Summary = { name: string; count: number; wins: number; pnl: number; gross: number; drag: number; winners: number; losers: number; mismatch: number };
const fmt = (n: number) => `${n >= 0 ? '+' : '−'}$${Math.abs(n).toFixed(2)}`;
const side = (t: PaperTrade): 'LONG' | 'SHORT' | null => t.entry_price != null && t.stop_price != null && t.target_price != null
  ? (t.stop_price < t.entry_price && t.target_price > t.entry_price ? 'LONG' : t.stop_price > t.entry_price && t.target_price < t.entry_price ? 'SHORT' : null) : null;
const parseSignal = (t: PaperTrade): string | null => {
  const reason = (t.market_data?.reason as string | undefined) || '';
  const explicit = reason.match(/\b(?:signal|strategy|trend)\s*(?:direction)?\s*[:=]\s*(LONG|SHORT)\b/i);
  if (explicit) return explicit[1].toUpperCase();
  if (/\b(bullish|trend LONG|reversion LONG|breakout LONG|rider LONG)\b/i.test(reason)) return 'LONG';
  if (/\b(bearish|trend SHORT|reversion SHORT|breakout SHORT|rider SHORT)\b/i.test(reason)) return 'SHORT';
  return null;
};
function grossPnl(t: PaperTrade): number | null {
  if (t.entry_price == null || t.exit_price == null || t.simulated_size == null || t.entry_price <= 0) return null;
  const direction = side(t);
  if (!direction) return null;
  return (direction === 'LONG' ? 1 : -1) * (t.exit_price - t.entry_price) / t.entry_price * t.simulated_size;
}
export function ResearchConsole({trades}: {trades: PaperTrade[]}) {
  const result = useMemo(() => {
    const completed = trades.filter(t => t.status === 'CLOSED' && typeof t.pnl === 'number');
    const summaries = new Map<string, Summary>();
    let flagged = 0; let costDrag = 0; let costSamples = 0;
    for (const t of completed) {
      const item = summaries.get(t.agent_id) || {name:t.agent_id,count:0,wins:0,pnl:0,gross:0,drag:0,winners:0,losers:0,mismatch:0};
      const net = t.pnl || 0;
      item.count++; item.pnl += net;
      if (net > 0) {item.wins++;item.winners += net;} else if (net < 0) item.losers += net;
      const g = grossPnl(t);
      if (g != null) { item.gross += g; item.drag += g - net; costDrag += g-net; costSamples++; }
      const signal = parseSignal(t), finalSide = side(t);
      if (signal && finalSide && signal !== finalSide) {item.mismatch++; flagged++;}
      summaries.set(t.agent_id,item);
    }
    const rows = [...summaries.values()].sort((a,b)=>b.pnl-a.pnl);
    const total = completed.reduce((n,t)=>n+(t.pnl||0),0);
    const wins = completed.filter(t=>(t.pnl||0)>0).length;
    const losses = completed.filter(t=>(t.pnl||0)<0).length;
    const profit = completed.reduce((n,t)=>n+Math.max(t.pnl||0,0),0);
    const loss = -completed.reduce((n,t)=>n+Math.min(t.pnl||0,0),0);
    const byClose = new Map<string,{count:number,pnl:number}>();
    for (const t of completed) {
      const reason=t.close_reason || 'OTHER';const r=byClose.get(reason)||{count:0,pnl:0};r.count++;r.pnl+=t.pnl||0;byClose.set(reason,r);
    }
    return {rows,completed:completed.length, open:trades.filter(t=>t.status==='OPEN').length,total,wins,losses,profitFactor:loss>0?profit/loss:null,avg:completed.length?total/completed.length:0,flagged,costDrag,costSamples,byClose:[...byClose.entries()].sort((a,b)=>b[1].count-a[1].count)};
  },[trades]);
  return <section className="research-console mt-7 space-y-5">
    <div className="flex flex-wrap items-start justify-between gap-3">
      <div><p className="text-[11px] uppercase tracking-[0.25em] text-cyan-400 font-bold">Strategy intelligence</p><h2 className="text-2xl font-bold text-white mt-1">Research command center</h2><p className="text-sm text-slate-400 mt-1">Calculations from the most recent {trades.length} loaded records. Not a full account history.</p></div>
      <div className="flex items-center gap-2 text-xs text-amber-200 bg-amber-400/10 border border-amber-400/20 rounded-full px-3 py-2"><ShieldCheck className="h-4 w-4"/> PAPER RESEARCH ONLY</div>
    </div>
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
      {[{name:'Recorded net P&L',value:fmt(result.total),sub:`${result.completed} closed trades`,bad:result.total<0},{name:'Win rate',value:`${result.completed?(100*result.wins/result.completed).toFixed(1):'—'}%`,sub:`${result.wins} wins / ${result.losses} losses`},{name:'Profit factor',value:result.profitFactor==null?'—':result.profitFactor.toFixed(2),sub:'Gross winning P&L / gross losing P&L',bad:result.profitFactor!=null&&result.profitFactor<1},{name:'Mean net / trade',value:fmt(result.avg),sub:`${result.open} open positions`,bad:result.avg<0}].map(metric=><div key={metric.name} className="rounded-2xl bg-[#121d2b] border border-white/10 p-4"><p className="text-xs text-slate-400">{metric.name}</p><p className={`text-2xl font-semibold mt-2 tabular-nums ${metric.bad?'text-rose-400':'text-white'}`}>{metric.value}</p><p className="text-[11px] text-slate-500 mt-2">{metric.sub}</p></div>)}
    </div>
    <div className="grid lg:grid-cols-[1.5fr_1fr] gap-4">
      <div className="bg-[#121d2b] rounded-2xl border border-white/10 overflow-hidden"><div className="p-4 flex gap-2 items-center border-b border-white/10"><BarChart3 className="h-4 w-4 text-cyan-400"/><h3 className="font-semibold text-white">Agent scoreboard</h3><span className="text-xs text-slate-500 ml-auto">Net performance, not win rate ranking</span></div><div className="overflow-x-auto"><table className="w-full text-sm"><thead><tr className="text-left text-xs text-slate-500 border-b border-white/5"><th className="py-3 pl-4">Agent</th><th>Trades</th><th>Win %</th><th>Net</th><th>Avg/trade</th></tr></thead><tbody>{result.rows.map(r=><tr key={r.name} className="border-b border-white/5"><td className="pl-4 py-3 font-semibold text-white">{r.name}</td><td>{r.count}</td><td>{(r.wins/r.count*100).toFixed(0)}%</td><td className={r.pnl>=0?'text-emerald-400':'text-rose-400'}>{fmt(r.pnl)}</td><td className={r.pnl>=0?'text-emerald-400':'text-rose-400'}>{fmt(r.pnl/r.count)}</td></tr>)}</tbody></table></div><p className="px-4 pb-4 pt-3 text-[11px] text-slate-500">Small samples are not proof of a profitable strategy. Fees and slippage depend on your existing simulator.</p></div>
      <div className="bg-[#121d2b] rounded-2xl border border-white/10 p-4 space-y-4"><h3 className="text-white font-semibold flex gap-2 items-center"><AlertTriangle className="h-4 w-4 text-amber-400"/>Execution quality checks</h3><div className="border-b border-white/10 pb-3"><p className="text-xs text-slate-400">Possible signal/position conflicts</p><p className="text-2xl text-amber-300 font-semibold mt-1">{result.flagged}</p><p className="text-xs text-slate-500 mt-1">Keyword-based diagnostic; intentional APEX reversal genes can generate valid conflicts. Review trade metadata before changing direction.</p></div><div><p className="text-xs text-slate-400">Gross-to-net difference (where measurable)</p><p className="text-xl text-white font-semibold mt-1">{fmt(-result.costDrag)}</p><p className="text-xs text-slate-500 mt-1">Calculated across {result.costSamples} trades; estimate only, not an itemized fee audit.</p></div><div className="flex gap-2 text-xs text-slate-300"><ArrowUpRight className="h-4 w-4 text-emerald-400"/>{result.wins} profitable exits <ArrowDownRight className="h-4 w-4 text-rose-400 ml-2"/>{result.losses} losing exits</div></div>
    </div>
    <div className="bg-[#121d2b] rounded-2xl border border-white/10 p-4"><h3 className="text-white font-semibold mb-3">Exit-type breakdown</h3><div className="grid grid-cols-2 lg:grid-cols-4 gap-3">{result.byClose.map(([reason,v])=><div key={reason} className="rounded-xl bg-[#0a101b] p-3"><div className="text-[11px] text-slate-400 break-words">{reason.replaceAll('_',' ')}</div><div className={`mt-2 text-lg font-semibold ${v.pnl>=0?'text-emerald-400':'text-rose-400'}`}>{fmt(v.pnl)}</div><div className="text-xs text-slate-500">{v.count} trades · {fmt(v.pnl/v.count)} avg</div></div>)}</div></div>
  </section>;
}
