import { useState } from "react";
import type { AgentGenome, EvolutionResult } from "@/lib/types";
import { AGENT_META } from "@/lib/types";
import { Dna, Play, Trophy, ArrowUpRight, ArrowDownRight, Sparkles, ChevronDown, ChevronRight } from "lucide-react";

interface Props {
  genomes: AgentGenome[];
  onEvolve: () => void;
  evolving: boolean;
  lastEvolution: EvolutionResult[] | null;
  evolutionGeneration: number | null;
}

const GENOME_LABELS: Record<string, string> = {
  trend_threshold: "Trend Threshold",
  long_stop_sma50_mult: "Long Stop SMA50",
  long_stop_low_mult: "Long Stop Low",
  long_target_rr: "Long Target R/R",
  short_rsi_max: "Short RSI Max",
  short_stop_pct: "Short Stop %",
  short_target_rr: "Short Target R/R",
  min_rr: "Min R/R",
  max_hold_bars: "Max Hold Bars",
  min_gap: "Min Gap",
  ema_fast: "EMA Fast",
  ema_slow: "EMA Slow",
  trend_strength_max: "Trend Strength Max",
  bb_period: "BB Period",
  bb_std_dev: "BB Std Dev",
  rsi_oversold: "RSI Oversold",
  rsi_overbought: "RSI Overbought",
  vol_ratio_min: "Vol Ratio Min",
  stop_band_buffer: "Stop Band Buffer",
  min_momentum: "Min Momentum %",
  min_rsi_long: "Min RSI Long",
  max_rsi_long: "Max RSI Long",
  min_rsi_short: "Min RSI Short",
  max_rsi_short: "Max RSI Short",
  min_stop_pct: "Min Stop %",
  max_stop_pct: "Max Stop %",
  target_rr: "Target R/R",
  pattern_lookback: "Pattern Lookback",
  pattern_tolerance: "Pattern Tolerance %",
  stop_buffer_pct: "Stop Buffer %",
};

export function Evolution({ genomes, onEvolve, evolving, lastEvolution, evolutionGeneration }: Props) {
  const [expandedAgent, setExpandedAgent] = useState<string | null>(null);

  const champions = genomes.filter((g) => g.is_champion);
  const recentMutants = genomes
    .filter((g) => !g.is_champion)
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
    .slice(0, 12);

  const tradingAgents = ["KIBO", "YUZU", "MATTY", "REKT", "APEX"];
  const championAgents = tradingAgents
    .map((id) => champions.find((g) => g.agent_id === id))
    .filter((g): g is AgentGenome => !!g)
    .sort((a, b) => {
      const aScore = a.composite_score != null ? a.composite_score : a.total_pnl;
      const bScore = b.composite_score != null ? b.composite_score : b.total_pnl;
      return bScore - aScore;
    });

  return (
    <div className="space-y-4">
      {/* Evolution Control Panel */}
      <div className="rounded-xl bg-slate-900/40 border border-slate-800/50 overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800/50 bg-slate-900/60">
          <div className="flex items-center gap-2">
            <Dna className="w-4 h-4 text-emerald-400" />
            <span className="text-sm font-medium text-slate-300">Evolution Lab</span>
            {evolutionGeneration !== null && (
              <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                Gen {evolutionGeneration}
              </span>
            )}
          </div>
          <button
            onClick={onEvolve}
            disabled={evolving}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/30 text-emerald-300 text-xs font-medium transition-colors disabled:opacity-50"
          >
            <Play className="w-3.5 h-3.5" />
            {evolving ? "Evolving..." : "Evolve Generation"}
          </button>
        </div>

        {evolving && (
          <div className="px-4 py-8 text-center">
            <div className="inline-flex items-center gap-2 text-sm text-slate-400">
              <Sparkles className="w-4 h-4 animate-pulse text-emerald-400" />
              Mutating parameters, testing 3 variants per agent across 10 watchlist symbols + 15 volatile perps for REKT...
            </div>
          </div>
        )}

        {!evolving && lastEvolution && lastEvolution.length > 0 && (
          <div className="px-4 py-3 space-y-2">
            <div className="text-xs text-slate-500 uppercase tracking-wider mb-2">Latest Evolution Results</div>
            {lastEvolution.map((r) => {
              const meta = AGENT_META[r.agent_id];
              const improved = r.improved;
              return (
                <div
                  key={r.agent_id}
                  className={`flex items-center justify-between px-3 py-2 rounded-lg border ${
                    improved
                      ? "bg-emerald-950/20 border-emerald-800/30"
                      : "bg-slate-900/30 border-slate-800/40"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className={`text-xs font-bold ${meta?.color || "text-slate-400"}`}>
                      {r.agent_id}
                    </span>
                    {improved ? (
                      <span className="inline-flex items-center gap-0.5 text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/20">
                        <ArrowUpRight className="w-2.5 h-2.5" /> Evolved
                      </span>
                    ) : (
                      <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-slate-700/30 text-slate-500 border border-slate-700/30">
                        No change
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-3 text-xs">
                    <span className="text-slate-500">
                      Champion: <span className="text-slate-300">${r.champion_pnl.toFixed(0)}</span>
                    </span>
                    <span className="text-slate-500">
                      Best mutant:{" "}
                      <span className={improved ? "text-emerald-400 font-medium" : "text-slate-300"}>
                        ${r.mutant_pnl.toFixed(0)}
                      </span>
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {!evolving && (!lastEvolution || lastEvolution.length === 0) && (
          <div className="px-4 py-8 text-center">
            <Dna className="w-8 h-8 text-slate-600 mx-auto mb-3" />
            <p className="text-slate-500 text-sm mb-1">
              Agents have fixed strategy parameters. Run evolution to mutate them and find better configurations.
            </p>
            <p className="text-slate-600 text-xs">
              Each evolution cycle creates 3 mutated variants per agent, backtests them, and crowns the winner. Fitness blends 70% backtest P&L with 30% live P&L.
            </p>
          </div>
        )}
      </div>

      {/* Champion Genomes */}
      <div className="rounded-xl bg-slate-900/40 border border-slate-800/50 overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-800/50 bg-slate-900/60">
          <div className="flex items-center gap-2">
            <Trophy className="w-4 h-4 text-amber-400" />
            <span className="text-sm font-medium text-slate-300">Champion Genomes</span>
            <span className="text-xs text-slate-600">Current best-known parameters per agent</span>
          </div>
        </div>

        <div className="divide-y divide-slate-800/30">
          {championAgents.map((champion) => {
            const agentId = champion.agent_id;
            const meta = AGENT_META[agentId];
            const isExpanded = expandedAgent === agentId;
            const genomeEntries = Object.entries(champion.genome);
            const score = champion.composite_score != null ? champion.composite_score : champion.total_pnl;
            const isNegative = score < 0;

            return (
              <div key={agentId}>
                <button
                  onClick={() => setExpandedAgent(isExpanded ? null : agentId)}
                  className="w-full flex items-center justify-between px-4 py-3 hover:bg-slate-800/20 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    {isExpanded ? (
                      <ChevronDown className="w-4 h-4 text-slate-500" />
                    ) : (
                      <ChevronRight className="w-4 h-4 text-slate-500" />
                    )}
                    <div className="flex items-center gap-2">
                      <span className={`text-sm font-bold ${meta?.color || "text-slate-400"}`}>
                        {agentId}
                      </span>
                      <span className="text-xs text-slate-600">
                        Gen {champion.generation} · {genomeEntries.length} genes
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-xs text-slate-500">
                      {champion.total_trades} trades · {champion.win_rate.toFixed(0)}% WR
                    </span>
                    {champion.live_pnl != null && champion.live_pnl !== 0 && (
                      <span className="text-xs text-slate-500">
                        Live: <span className={champion.live_pnl >= 0 ? "text-emerald-400" : "text-red-400"}>
                          ${champion.live_pnl.toFixed(2)}
                        </span>
                      </span>
                    )}
                    <span className={`text-sm font-bold flex items-center gap-0.5 ${isNegative ? "text-red-400" : "text-emerald-400"}`}>
                      {isNegative ? <ArrowDownRight className="w-3.5 h-3.5" /> : <ArrowUpRight className="w-3.5 h-3.5" />}
                      ${Math.abs(score).toFixed(2)}
                    </span>
                  </div>
                </button>

                {isExpanded && (
                  <div className="px-4 pb-4">
                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
                      {genomeEntries.map(([key, value]) => (
                        <div key={key} className="rounded-lg bg-slate-800/20 border border-slate-700/30 px-2.5 py-2">
                          <div className="text-[10px] text-slate-600 uppercase tracking-wider truncate">
                            {GENOME_LABELS[key] || key}
                          </div>
                          <div className="text-sm font-medium text-slate-200">
                            {typeof value === "number" && value < 1 && value > 0
                              ? value.toFixed(4)
                              : value.toFixed(2)}
                          </div>
                        </div>
                      ))}
                    </div>
                    {champion.mutation_notes && champion.mutation_notes !== "Initial baseline parameters" && (
                      <div className="mt-3 px-3 py-2 rounded-lg bg-emerald-950/10 border border-emerald-800/20 text-xs text-emerald-300/70">
                        <Sparkles className="w-3 h-3 inline mr-1" />
                        {champion.mutation_notes}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Recent Mutants */}
      {recentMutants.length > 0 && (
        <div className="rounded-xl bg-slate-900/40 border border-slate-800/50 overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-800/50 bg-slate-900/60">
            <div className="flex items-center gap-2">
              <Dna className="w-4 h-4 text-sky-400" />
              <span className="text-sm font-medium text-slate-300">Recent Mutants</span>
              <span className="text-xs text-slate-600">Tested but not crowned</span>
            </div>
          </div>
          <div className="divide-y divide-slate-800/20 max-h-64 overflow-y-auto">
            {recentMutants.map((m) => {
              const meta = AGENT_META[m.agent_id];
              return (
                <div key={m.id} className="flex items-center justify-between px-4 py-2 hover:bg-slate-800/20 transition-colors">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className={`text-xs font-bold ${meta?.color || "text-slate-400"}`}>
                      {m.agent_id}
                    </span>
                    <span className="text-xs text-slate-600">Gen {m.generation}</span>
                    <span className="text-xs text-slate-600 truncate max-w-[300px]" title={m.mutation_notes || ""}>
                      {m.mutation_notes || "—"}
                    </span>
                  </div>
                  <span className={`text-xs font-medium ${m.total_pnl >= 0 ? "text-emerald-400" : "text-red-400"} flex items-center gap-0.5 shrink-0`}>
                    {m.total_pnl >= 0 ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                    ${Math.abs(m.total_pnl).toFixed(0)}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
