import type { RunLog } from "@/lib/types";
import { CheckCircle2, XCircle, Loader2, Clock } from "lucide-react";

interface Props {
  logs: RunLog[];
}

export function RunHistory({ logs }: Props) {
  if (logs.length === 0) {
    return (
      <div className="rounded-xl bg-slate-900/40 border border-slate-800/50 p-12 text-center">
        <Clock className="w-8 h-8 text-slate-600 mx-auto mb-3" />
        <p className="text-slate-500 text-sm">No engine runs yet. The first run will appear here automatically.</p>
      </div>
    );
  }

  return (
    <div className="rounded-xl bg-slate-900/40 border border-slate-800/50 overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-xs text-slate-500 border-b border-slate-800/50 bg-slate-900/60">
              <th className="text-left font-medium px-4 py-2.5">Status</th>
              <th className="text-left font-medium px-3 py-2.5">Started</th>
              <th className="text-left font-medium px-3 py-2.5">Duration</th>
              <th className="text-right font-medium px-3 py-2.5">Opened</th>
              <th className="text-right font-medium px-3 py-2.5">Closed</th>
              <th className="text-right font-medium px-3 py-2.5">Blocked</th>
              <th className="text-left font-medium px-4 py-2.5">Error</th>
            </tr>
          </thead>
          <tbody>
            {logs.map((log) => {
              const duration = log.completed_at
                ? Math.round((new Date(log.completed_at).getTime() - new Date(log.started_at).getTime()) / 1000)
                : null;

              return (
                <tr
                  key={log.id}
                  className="border-b border-slate-800/30 hover:bg-slate-800/20 transition-colors"
                >
                  <td className="px-4 py-2.5">
                    {log.status === "SUCCESS" ? (
                      <span className="inline-flex items-center gap-1 text-emerald-400 text-xs font-medium">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Success
                      </span>
                    ) : log.status === "ERROR" ? (
                      <span className="inline-flex items-center gap-1 text-red-400 text-xs font-medium">
                        <XCircle className="w-3.5 h-3.5" /> Error
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-sky-400 text-xs font-medium">
                        <Loader2 className="w-3.5 h-3.5 animate-spin" /> Running
                      </span>
                    )}
                  </td>
                  <td className="px-3 py-2.5 text-xs text-slate-400 whitespace-nowrap">
                    {new Date(log.started_at).toLocaleString("en-US", {
                      month: "short", day: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit",
                    })}
                  </td>
                  <td className="px-3 py-2.5 text-xs text-slate-500">
                    {duration !== null ? `${duration}s` : "—"}
                  </td>
                  <td className="px-3 py-2.5 text-right">
                    <span className="text-sky-400 text-xs font-medium">{log.trades_opened}</span>
                  </td>
                  <td className="px-3 py-2.5 text-right">
                    <span className="text-slate-300 text-xs">{log.trades_closed}</span>
                  </td>
                  <td className="px-3 py-2.5 text-right">
                    <span className="text-amber-400 text-xs">{log.trades_blocked}</span>
                  </td>
                  <td className="px-4 py-2.5 text-xs text-red-400/70 max-w-[200px] truncate">
                    {log.error_message || "—"}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
