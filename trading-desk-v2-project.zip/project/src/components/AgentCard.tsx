import type { Agent, AgentStats, AgentSymbolStat, ApexStrategyStat } from "@/lib/types";
import { Brain, TrendingUp, TrendingDown, Ban, Clock, Crown } from "lucide-react";

interface Props {
  agent: Agent;
  stats?: AgentStats;
  icon: React.ReactNode;
  meta?: { color: string; bgColor: string; borderColor: string; icon: string };
  symbolStats?: AgentSymbolStat[];
  strategyStats?: ApexStrategyStat[];
}

export function AgentCard({ agent, stats, icon, meta, symbolStats, strategyStats }: Props) {
  const color = meta?.color || "text-slate-400";
  const bgColor = meta?.bgColor || "bg-slate-800/30";
  const borderColor = meta?.borderColor || "border-slate-700/50";

  const totalTrades = stats?.total_trades ?? 0;
  const wins = stats?.wins ?? 0;
  const losses = stats?.losses ?? 0;
  const blocked = stats?.blocked ?? 0;
  const pnl = stats?.total_pnl ?? 0;
  const winRate = stats?.win_rate ?? 0;
  const pnlPositive = pnl >= 0;

  const bayesAlpha = stats?.bayesian_alpha ?? 2;
  const bayesBeta = stats?.bayesian_beta ?? 2;
  const winProb = bayesAlpha / (bayesAlpha + bayesBeta);
  const confidence = stats?.edge_confidence ?? 0;
  const shouldTrade = stats?.should_trade ?? true;
  const isTrader = agent.id === "KIBO" || agent.id === "YUZU" || agent.id === "MATTY" || agent.id === "REKT" || agent.id === "APEX";

  return (
    <div
      className={`rounded-xl ${bgColor} border ${borderColor} p-5 transition-all hover:shadow-xl hover:-translate-y-0.5 group`}
    >
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className={`w-9 h-9 rounded-lg ${bgColor} border ${borderColor} flex items-center justify-center ${color}`}>
            {icon}
          </div>
          <div>
            <h3 className={`font-bold text-sm ${color}`}>{agent.id}</h3>
            <p className="text-xs text-slate-500">{agent.role}</p>
          </div>
        </div>
        <span
          className={`text-xs px-2 py-0.5 rounded-full ${
            agent.enabled
              ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
              : "bg-slate-700/30 text-slate-500 border border-slate-700/30"
          }`}
        >
          {agent.enabled ? "Active" : "Off"}
        </span>
      </div>

      {/* Description */}
      <p className="text-xs text-slate-500 leading-relaxed mb-4 min-h-[2.5rem]">
        {agent.description}
      </p>

      {/* Bayesian confidence section for trading agents */}
      {isTrader && stats && totalTrades > 0 && (
        <div className="mb-4 p-3 rounded-lg bg-slate-900/40 border border-slate-800/50">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-500 flex items-center gap-1">
              <Brain className="w-3 h-3" />
              Bayesian Edge
            </span>
            {!shouldTrade && (
              <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-red-500/10 text-red-400 border border-red-500/20 flex items-center gap-0.5">
                <Ban className="w-2.5 h-2.5" />
                Halted
              </span>
            )}
          </div>
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-1">
              {winProb >= 0.5 ? (
                <TrendingUp className="w-3 h-3 text-emerald-400" />
              ) : (
                <TrendingDown className="w-3 h-3 text-red-400" />
              )}
              <span className={winProb >= 0.5 ? "text-emerald-400" : "text-red-400"}>
                {(winProb * 100).toFixed(0)}% win est.
              </span>
            </div>
            <span className="text-slate-500">
              {confidence.toFixed(0)}% confidence
            </span>
          </div>
          {/* Confidence bar */}
          <div className="mt-2 h-1 bg-slate-800/50 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all ${
                winProb >= 0.5
                  ? "bg-gradient-to-r from-emerald-500 to-emerald-400"
                  : "bg-gradient-to-r from-red-500 to-red-400"
              }`}
              style={{ width: `${confidence}%` }}
            />
          </div>
        </div>
      )}

      {/* Per-symbol learning section for trading agents */}
      {isTrader && symbolStats && symbolStats.length > 0 && (
        <div className="mb-4 space-y-1.5">
          <div className="text-xs text-slate-600 uppercase tracking-wider mb-1">Per-Symbol Performance</div>
          {symbolStats.slice(0, 6).map((ss) => {
            const symPnlPositive = ss.total_pnl >= 0;
            const onCooldown = ss.cooldown_until && new Date(ss.cooldown_until) > new Date();
            return (
              <div
                key={ss.symbol}
                className={`flex items-center justify-between px-2 py-1.5 rounded-md border text-xs ${
                  !ss.should_trade
                    ? "bg-red-950/20 border-red-800/30"
                    : onCooldown
                    ? "bg-amber-950/20 border-amber-800/30"
                    : "bg-slate-900/30 border-slate-800/40"
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className="font-medium text-slate-300">{ss.symbol.replace("USDT", "")}</span>
                  <span className="text-slate-600">{ss.wins}W/{ss.losses}L</span>
                  {!ss.should_trade && (
                    <span className="text-[9px] px-1 py-0.5 rounded bg-red-500/20 text-red-400 flex items-center gap-0.5">
                      <Ban className="w-2 h-2" /> Banned
                    </span>
                  )}
                  {onCooldown && (
                    <span className="text-[9px] px-1 py-0.5 rounded bg-amber-500/20 text-amber-400 flex items-center gap-0.5">
                      <Clock className="w-2 h-2" /> Cooldown
                    </span>
                  )}
                </div>
                <span
                  className={`font-medium ${
                    !ss.should_trade ? "text-red-400" : onCooldown ? "text-amber-400" : symPnlPositive ? "text-emerald-400" : "text-red-400"
                  }`}
                >
                  {symPnlPositive ? "+" : ""}${ss.total_pnl.toFixed(0)}
                </span>
              </div>
            );
          })}
        </div>
      )}

      {/* APEX Strategy Registry — shows which strategies are winning */}
      {agent.id === "APEX" && strategyStats && strategyStats.length > 0 && (
        <div className="mb-4 space-y-1.5">
          <div className="text-xs text-slate-600 uppercase tracking-wider mb-1 flex items-center gap-1">
            <Crown className="w-3 h-3" />
            Strategy Registry
          </div>
          {strategyStats.slice(0, 8).map((ss) => {
            const stratPnlPositive = ss.total_pnl >= 0;
            const onCooldown = ss.cooldown_until && new Date(ss.cooldown_until) > new Date();
            return (
              <div
                key={ss.strategy}
                className={`flex items-center justify-between px-2 py-1.5 rounded-md border text-xs ${
                  !ss.enabled
                    ? "bg-red-950/20 border-red-800/30"
                    : onCooldown
                    ? "bg-amber-950/20 border-amber-800/30"
                    : "bg-slate-900/30 border-slate-800/40"
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className="font-medium text-slate-300">{ss.strategy.replace(/_/g, " ")}</span>
                  <span className="text-slate-600">{ss.wins}W/{ss.losses}L</span>
                  {!ss.enabled && (
                    <span className="text-[9px] px-1 py-0.5 rounded bg-red-500/20 text-red-400">Disabled</span>
                  )}
                  {onCooldown && (
                    <span className="text-[9px] px-1 py-0.5 rounded bg-amber-500/20 text-amber-400 flex items-center gap-0.5">
                      <Clock className="w-2 h-2" /> Cooldown
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-slate-600 text-[10px]">W:{ss.weight.toFixed(1)}x</span>
                  <span className={`font-medium ${stratPnlPositive ? "text-emerald-400" : "text-red-400"}`}>
                    {stratPnlPositive ? "+" : ""}${ss.total_pnl.toFixed(0)}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Stats grid */}
      <div className="grid grid-cols-3 gap-2">
        <Stat label="Trades" value={totalTrades.toString()} />
        <Stat label="Wins" value={wins.toString()} valueColor="text-emerald-400" />
        <Stat label="Losses" value={losses.toString()} valueColor="text-red-400" />
        <Stat label="Blocked" value={blocked.toString()} valueColor="text-amber-400" />
        <Stat label="Win Rate" value={`${winRate.toFixed(0)}%`} />
        <Stat
          label="P&L"
          value={`${pnlPositive ? "+" : ""}$${pnl.toFixed(2)}`}
          valueColor={pnlPositive ? "text-emerald-400" : "text-red-400"}
        />
      </div>

      {/* Drawdown bar */}
      {stats && stats.max_drawdown > 0 && (
        <div className="mt-4">
          <div className="flex justify-between text-xs text-slate-500 mb-1">
            <span>Max Drawdown</span>
            <span className="text-red-400">${stats.max_drawdown.toFixed(2)}</span>
          </div>
          <div className="h-1.5 bg-slate-800/50 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-amber-500 to-red-500 rounded-full transition-all"
              style={{ width: `${Math.min(100, (stats.max_drawdown / 100) * 100)}%` }}
            />
          </div>
        </div>
      )}
    </div>
  );
}

function Stat({
  label,
  value,
  valueColor = "text-slate-200",
}: {
  label: string;
  value: string;
  valueColor?: string;
}) {
  return (
    <div className="bg-slate-900/40 rounded-lg p-2 border border-slate-800/50">
      <div className="text-xs text-slate-500 mb-0.5">{label}</div>
      <div className={`text-sm font-bold ${valueColor}`}>{value}</div>
    </div>
  );
}
