export interface Agent {
  id: string;
  role: string;
  description: string;
  enabled: boolean;
  created_at: string;
}

export interface AgentStats {
  agent_id: string;
  total_trades: number;
  wins: number;
  losses: number;
  blocked: number;
  win_rate: number;
  avg_win: number;
  avg_loss: number;
  biggest_win: number;
  biggest_loss: number;
  total_pnl: number;
  max_drawdown: number;
  current_drawdown: number;
  bayesian_alpha: number;
  bayesian_beta: number;
  edge_confidence: number;
  should_trade: boolean;
  updated_at: string;
}

export interface PaperTrade {
  id: string;
  agent_id: string;
  symbol: string;
  status: "OPEN" | "CLOSED" | "BLOCKED";
  entry_price: number | null;
  exit_price: number | null;
  stop_price: number | null;
  target_price: number | null;
  simulated_size: number | null;
  max_dollar_risk: number | null;
  pnl: number | null;
  pnl_pct: number | null;
  momo_pass: boolean;
  rin_pass: boolean | null;
  sora_decision: string | null;
  kibo_decision: string | null;
  yuzu_decision: string | null;
  matty_decision: string | null;
  rekt_decision: string | null;
  apex_decision: string | null;
  block_reason: string | null;
  opened_at: string;
  closed_at: string | null;
  close_reason: string | null;
  market_data: Record<string, unknown>;
  notes: string | null;
  liquidation_price: number | null;
}

export interface SystemConfig {
  id: number;
  paper_balance: number;
  max_risk_per_trade_pct: number;
  max_total_risk_pct: number;
  trade_interval_minutes: number;
  max_positions_per_agent: number;
  watchlist: string[];
  total_team_pnl: number;
  total_trades: number;
  total_blocked: number;
  is_running: boolean;
  updated_at: string;
  leverage: number;
  compounding_mode: boolean;
  leverage_tiers: Record<string, number>;
  apex_risk_pct?: number;
  apex_start_date?: string;
  apex_start_balance?: number;
  apex_target_balance?: number;
  apex_end_date?: string;
  apex_compound_balance?: number;
  mirage_balance?: number;
  mirage_risk_pct?: number;
}

export interface RunLog {
  id: string;
  started_at: string;
  completed_at: string | null;
  status: string;
  cycles_completed: number;
  trades_opened: number;
  trades_closed: number;
  trades_blocked: number;
  error_message: string | null;
  summary: Record<string, unknown>;
}

export interface BacktestTrade {
  agent: string;
  symbol: string;
  entry: number;
  stop: number;
  target: number;
  exit: number;
  pnl: number;
  pnlPct: number;
  result: "WIN" | "LOSS" | "TIMEOUT";
  entryTime: number;
  exitTime: number;
  reason: string;
  rr: number;
}

export interface AgentSymbolStat {
  id: string;
  agent_id: string;
  symbol: string;
  total_trades: number;
  wins: number;
  losses: number;
  consecutive_losses: number;
  max_consecutive_losses: number;
  win_rate: number;
  total_pnl: number;
  bayesian_alpha: number;
  bayesian_beta: number;
  should_trade: boolean;
  last_trade_at: string | null;
  cooldown_until: string | null;
  updated_at: string;
}

export interface BacktestResult {
  id: string;
  agent_id: string;
  symbol: string;
  period_days: number;
  total_trades: number;
  wins: number;
  losses: number;
  blocked: number;
  win_rate: number;
  total_pnl: number;
  avg_win: number;
  avg_loss: number;
  biggest_win: number;
  biggest_loss: number;
  max_drawdown: number;
  profit_factor: number;
  sharpe_ratio: number;
  trades_json: BacktestTrade[];
  created_at: string;
}

export interface AgentGenome {
  id: string;
  agent_id: string;
  generation: number;
  genome: Record<string, number>;
  fitness_score: number;
  total_pnl: number;
  total_trades: number;
  win_rate: number;
  profit_factor: number;
  is_champion: boolean;
  parent_id: string | null;
  mutation_notes: string | null;
  backtest_run_id: string | null;
  created_at: string;
  live_pnl: number;
  composite_score: number;
}

export interface EvolutionResult {
  agent_id: string;
  champion_pnl: number;
  mutant_pnl: number;
  improved: boolean;
  mutation_notes: string;
}

export interface ApexStrategyStat {
  strategy: string;
  total_trades: number;
  wins: number;
  losses: number;
  total_pnl: number;
  win_rate: number;
  weight: number;
  enabled: boolean;
  cooldown_until: string | null;
  last_used_at: string | null;
  updated_at: string;
}

export const AGENT_META: Record<string, { color: string; bgColor: string; borderColor: string; icon: string }> = {
  MOMO: { color: "text-amber-400", bgColor: "bg-amber-500/10", borderColor: "border-amber-500/30", icon: "ShieldCheck" },
  RIN: { color: "text-cyan-400", bgColor: "bg-cyan-500/10", borderColor: "border-cyan-500/30", icon: "Fish" },
  SORA: { color: "text-red-400", bgColor: "bg-red-500/10", borderColor: "border-red-500/30", icon: "ShieldAlert" },
  KIBO: { color: "text-emerald-400", bgColor: "bg-emerald-500/10", borderColor: "border-emerald-500/30", icon: "Rocket" },
  YUZU: { color: "text-lime-400", bgColor: "bg-lime-500/10", borderColor: "border-lime-500/30", icon: "Target" },
  MATTY: { color: "text-violet-400", bgColor: "bg-violet-500/10", borderColor: "border-violet-500/30", icon: "Repeat" },
  REKT: { color: "text-orange-400", bgColor: "bg-orange-500/10", borderColor: "border-orange-500/30", icon: "Flame" },
  APEX: { color: "text-rose-400", bgColor: "bg-rose-500/10", borderColor: "border-rose-500/30", icon: "Crown" },
  MIRAGE: { color: "text-fuchsia-400", bgColor: "bg-fuchsia-500/10", borderColor: "border-fuchsia-500/30", icon: "FlipHorizontal2" },
  AKI: { color: "text-sky-400", bgColor: "bg-sky-500/10", borderColor: "border-sky-500/30", icon: "ClipboardList" },
};
