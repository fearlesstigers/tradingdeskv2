import { useEffect, useState } from "react";
import type { PaperTrade } from "@/lib/types";

type PriceMap = Record<string, number>;

async function fetchPrices(symbols: string[]): Promise<PriceMap> {
  const results: PriceMap = {};
  const unique = [...new Set(symbols)];

  await Promise.all(
    unique.map(async (symbol) => {
      try {
        let res = await fetch(
          `https://api.bybit.com/v5/market/tickers?category=spot&symbol=${symbol}`
        );
        if (res.ok) {
          const json = await res.json();
          const t = json?.result?.list?.[0];
          if (t) results[symbol] = parseFloat(t.lastPrice);
        }
        if (results[symbol] === undefined) {
          res = await fetch(
            `https://api.bybit.com/v5/market/tickers?category=linear&symbol=${symbol}`
          );
          if (res.ok) {
            const json = await res.json();
            const t = json?.result?.list?.[0];
            if (t) results[symbol] = parseFloat(t.lastPrice);
          }
        }
      } catch {
        // ignore individual failures
      }
    })
  );

  return results;
}

export function useLivePrices(trades: PaperTrade[]): PriceMap {
  const [prices, setPrices] = useState<PriceMap>({});

  useEffect(() => {
    const openSymbols = trades
      .filter((t) => t.status === "OPEN" && t.symbol)
      .map((t) => t.symbol);

    if (openSymbols.length === 0) {
      setPrices({});
      return;
    }

    let cancelled = false;

    const update = async () => {
      const result = await fetchPrices(openSymbols);
      if (!cancelled) setPrices(result);
    };

    update();
    const interval = setInterval(update, 15000);

    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, [trades]);

  return prices;
}
